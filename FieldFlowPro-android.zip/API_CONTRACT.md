# Sync API contract

The app speaks a tiny two-endpoint HTTP API. Implement it in anything (see
`server/reference-server.js` for a working Node version) or point `SYNC_BASE_URL` at a service that
matches this document. Everything is JSON over HTTPS, authenticated with a bearer token.

Base URL comes from `BuildConfig.SYNC_BASE_URL` (blank ⇒ the app uses its on-device mirror and never
opens a socket). API key comes from `BuildConfig.SYNC_API_KEY` and is sent as
`Authorization: Bearer <key>` when non-blank.

## Envelope types

```jsonc
// ChangeRecord — one entity mutation
{
  "entityType": "job",            // "job" | "client" | "quote" | "photo" | "signature"
  "entityId":   "job-8f3…",       // client-generated stable id
  "op":         "upsert",         // "upsert" | "delete"
  "payload":    "{…}",            // the entity as a JSON *string* (kotlinx.serialization output)
  "updatedAt":  1737000000000,    // client clock, epoch ms
  "version":    4                 // client-side version counter
}

// PushRequest
{ "deviceId": "dev-…", "cursor": "41", "changes": [ /* ChangeRecord… */ ] }

// PushResponse
{ "accepted": ["job:job-8f3…"],   // "entityType:entityId" the server stored
  "rejected": ["quote:qte-1a2…"], // server had a newer version; client should re-pull
  "cursor":    "57",              // server sequence after applying this batch
  "serverTime": 1737000000123 }

// PullResponse
{ "changes": [ /* ChangeRecord… */ ],
  "cursor":  "57",
  "hasMore": false,
  "serverTime": 1737000000123 }
```

The cursor is an **opaque string**. The reference server uses a monotonically increasing integer
sequence; any scheme works as long as it totally orders changes and can round-trip through the app
(it stores it verbatim in `SyncCursorState`).

## POST /v1/sync/push

Request body: `PushRequest`. Response `200` with `PushResponse`.

Semantics the client relies on:

* **Dedup by key.** `entityType:entityId` is the unit of identity. If the stored record's
  `updatedAt` is newer than the incoming change, put the key in `rejected` and change nothing.
  Otherwise store (insert or replace), bump the server sequence, and put the key in `accepted`.
* **Deletes are not special.** `op == "delete"` stores a tombstone payload exactly like an upsert;
  the client already sends soft-deleted records and filters them from the UI.
* **`cursor` in the response** must be the server's current sequence so the client can pull
  immediately without a round trip.
* Anything accepted must be visible to a subsequent pull from a *different* device.

Errors:

| Status | Client behaviour |
| --- | --- |
| 200 | apply `accepted`/`rejected` |
| 401 / 403 | surfaces `AppError.Auth`, operation marked failed (`retryable = false` in practice: the queue keeps it but the message tells the user the key is wrong) |
| 429 | treated as retryable network failure with exponential backoff |
| 5xx | retryable, exponential backoff `min(30s·2^attempts, 1h)` |
| network/timeout | retryable; changes stay queued and the app stays fully usable |

## GET /v1/sync/pull?cursor=<cursor>&limit=200

Returns `PullResponse` with every change whose sequence is **strictly greater** than `cursor`,
ordered ascending by sequence. `limit` is a hint; the client requests 200. `hasMore` is informational
(the app simply pulls again on the next sync cycle).

The app's client also sends its own last cursor as the `cursor` query parameter; a server may ignore
it and return from the beginning, but that wastes bandwidth.

## Peer isolation (optional)

The reference server namespaces records by an optional shared "workspace" derived from the API key
(`sha256(key).slice(0,16)`). Two keys therefore never see each other's jobs. Implement strictly
stronger isolation (per-account auth, per-user workspaces) if you expose this publicly; the contract
above does not require more than a bearer token, so **treat the API key as a secret and rotate it**
if it leaks. `SYNC_API_KEY` lives in `local.properties` / CI secrets, never in source.

## Conflict policy (client side)

`JobRepository.applyRemote` (and siblings):

```
if (local exists && local.updatedAt > remote.updatedAt && local.syncState == PENDING) keep local
else store remote and mark it SYNCED
```

So a same-device edit that has not been uploaded wins ties, and otherwise newest-write-wins. Rejected
pushes are re-pulled on the next cycle, which converges both devices on the server's record.

## Payload compatibility

`payload` is the full serialized entity from the app. Every field has a default value, and the client
decodes with `ignoreUnknownKeys = true`, so older and newer app versions can coexist against the same
server. Store it as an opaque string server-side and you never need to track the entity schema.

## Minimal example (curl)

```bash
curl -X POST "$SYNC_BASE_URL/v1/sync/push" \
  -H "Authorization: Bearer $SYNC_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"deviceId":"dev-test","cursor":"0","changes":[
        {"entityType":"client","entityId":"cli-1","op":"upsert",
         "payload":"{\"id\":\"cli-1\",\"name\":\"Dana Whitfield\",\"updatedAt\":1737000000000}",
         "updatedAt":1737000000000,"version":1}]}'

curl "$SYNC_BASE_URL/v1/sync/pull?cursor=0&limit=200" \
  -H "Authorization: Bearer $SYNC_API_KEY"
```
