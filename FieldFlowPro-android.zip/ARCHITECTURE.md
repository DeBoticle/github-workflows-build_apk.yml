# Architecture

A map of the codebase for whoever works on it next. Roughly 6,000 lines of Kotlin across 52 files,
Kotlin + Jetpack Compose, single-activity, no XML layouts (Compose only), no annotation processors.

## Module layout

```
com.fieldflow.pro
├── FieldFlowApp.kt          Application: builds AppContainer, installs a crash logger, start()
├── MainActivity.kt          Single activity: splash screen, edge-to-edge, sets FieldFlowRoot()
├── core/
│   ├── AppContainer.kt      Manual DI graph: tables → repositories → engines. Also backup/restore
│   ├── CryptoBox.kt         Android Keystore AES-256-GCM encrypt/decrypt, SHA-256, PBKDF2, tokens
│   ├── EncryptedJsonStore.kt Encrypted file store + JsonTable<T> (list-of-T persistence + StateFlow)
│   ├── AppResult.kt         AppError sealed class + AppResult<T> + map/valueOrNull/errorOrNull
│   ├── AppLogger.kt         logcat + 400-line in-memory ring buffer (surfaced in Diagnostics)
│   ├── Util.kt              Ids, Money, Dates, Bytes, String helpers
│   ├── net/ConnectivityMonitor.kt   Default-network callback → StateFlow<Boolean>
│   └── analytics/Analytics.kt       Analytics interface + LocalAnalytics (opt-in batched upload)
├── data/
│   ├── model/Models.kt      Job, Quote, QuoteLine, Client, Photo, Signature, SyncOperation, enums
│   ├── model/Settings.kt    AppSettings (all preferences), TradeTemplate, SyncCursorState
│   ├── local/*.kt           JobRepository, ClientRepository, QuoteRepository, PhotoRepository,
│   │                        SignatureRepository, SettingsRepository, AuthRepository,
│   │                        SyncQueueRepository — all read/write JsonTable<T>
│   ├── auth/GoogleSignInClient.kt   Credential Manager + optional online tokeninfo verification
│   ├── photo/PhotoStore.kt  Encrypted media vault: import/normalize/thumbnail/display/wipe
│   ├── templates/TemplateRepository.kt  assets/templates.json + user-saved custom templates
│   ├── sync/CloudApi.kt     CloudApi interface, LocalMirrorApi, HttpCloudApi, DTOs, SyncEntities
│   ├── sync/SyncEngine.kt   push/pull loop, conflict policy, backoff, SyncUiState
│   ├── sync/SyncWorker.kt   CoroutineWorker + SyncScheduler (WorkManager)
│   └── pdf/PacketExporter.kt Hand-drawn PDF (PdfDocument + Canvas), share/open intents
├── ui/
│   ├── AppRoot.kt           Boot gate → login → onboarding → AppNav, wrapped in FieldFlowTheme
│   ├── theme/Theme.kt       Light/dark schemes, typography, FfDimens (standard vs glove mode)
│   ├── nav/AppNav.kt        Routes + NavHost
│   ├── components/          FfScreen, BigButton, SectionCard, FfTextField, JobRow, SignaturePad,
│   │                        MarkupCanvas, BeforeAfterSlider, PhotoThumb, banners, dialogs
│   └── screens/             One file per screen (see the feature map in README.md)
└── (assets) templates.json
```

## Persistence model

One JSON file per entity type inside `filesDir/vault`, each written as
`version(1 byte) | ivLen(1 byte) | iv | AES-GCM ciphertext`:

```
vault/jobs.json.enc          vault/clients.json.enc        vault/quotes.json.enc
vault/photos.json.enc        vault/signatures.json.enc     vault/sync-queue.json.enc
vault/accounts.json.enc      vault/templates-custom.json.enc
vault/settings.json.enc      vault/device.json.enc         vault/sync-cursor.json.enc
vault/analytics.json.enc     vault/session.json.enc
```

`JsonTable<T>` is the only writer: it keeps a `MutableStateFlow<List<T>>` for the UI, persists the
whole list on every mutation, and exposes `upsert/upsertAll/deleteById/replaceAll/ensureLoaded`.
Deliberately no ORM: the data sets are small (hundreds of records), the whole-list rewrite is cheap,
and the whole file is encrypted as one unit.

Encrypted media lives beside the vault:

```
filesDir/photos/<id>.enc         encrypted JPEGs (originals + marked-up copies)
filesDir/signatures/<id>.enc     encrypted PNGs
filesDir/exports/*.pdf           plain PDFs (must be readable by other apps)
filesDir/backups/*.ffbackup      zip: manifest.json + plain media (re-encrypted on restore)
cacheDir/previews/…              decrypted copies, regenerated on demand, wipeable
```

The keystore key (`fieldflow_master_v1`) is created lazily on first use. If it is ever invalidated
(device restore, lock-screen change on some OEMs), vault reads fail loudly and the repository layer
logs the failure and falls back to an empty list rather than crashing the app.

## Write path (offline-first)

```
UI event → Repository.save(entity)
        → JsonTable.upsert  (StateFlow updates immediately → UI recomposes)
        → SyncQueueRepository.enqueue(entityType, entityId, op, jsonPayload)
        → analytics.log(...)  (local ring, uploaded only if opted in)
```

Nothing in that chain touches the network, so every feature works with the radio off. A save that
fails on disk throws and surfaces through `AppResult.Failure` → snackbar/banner; there is no silent
data loss path.

## Sync model

* **Queue**: one row per entity (last write wins locally, so a single pending op per entity).
  `dueBatch(now, 200)` returns ops whose `nextAttemptAt` has passed.
* **Push**: `POST /v1/sync/push` with `{deviceId, cursor, changes[]}`. The server answers with
  `accepted[]`, `rejected[]` (server has newer data) and a new `cursor`. Accepted ops are removed
  from the queue and their entities marked `SYNCED`; rejected ops are marked failed and will be
  overwritten by the pull.
* **Pull**: `GET /v1/sync/pull?cursor=…&limit=200` returns changes with sequence ordering.
  `applyRemote()` keeps the local copy when it is newer **and** still pending, otherwise the remote
  wins and is stored as `SYNCED`. That is the entire conflict policy: newest write wins, with a bias
  to un-synced local edits so a contractor's on-site edit is never silently discarded.
* **Triggers**: manual (any screen), connectivity regained (`ConnectivityMonitor` → one-shot work),
  and periodic WorkManager work every 30 minutes (optionally Wi-Fi only). Backoff is
  `min(30s · 2^attempts, 1h)` per operation.
* **Default backend**: with `SYNC_BASE_URL` blank, `LocalMirrorApi` stands in — a real
  file-backed push/pull server running on the device, used for demos and offline testing, and it
  lets `SyncEngine` be exercised without any network. `SyncUiState`/`modeLabel` make the active mode
  visible in Home, Settings and Diagnostics.

## Media pipeline

1. Capture: CameraX writes a JPEG into `cacheDir/camera`.
2. Import: `PhotoStore.importPhoto` reads EXIF orientation, bakes the rotation in, hashes (SHA-256),
   encrypts into `filesDir/photos/<id>.enc`, and returns a `Photo` metadata record (dimensions,
   size, hash).
3. Display: `displayFile` decrypts into `cacheDir/previews` and `thumbnailFile` downsamples it.
   Coil renders the plain file. Nothing decrypted is ever written outside the cache.
4. Markup: `renderMarkupBitmap` burns annotations into a **new** bitmap, which is imported as a new
   `Photo` with `parentId` pointing at the original. Originals are never overwritten.
5. Packet: `PacketExporter` decrypts what it needs, lays out an A4 PDF (cover, scope, materials,
   quote, photo grid, before/after page, signature page with hash), then recycles bitmaps.

## UI conventions

* `FfScreen` is the standard scaffold: title, subtitle, optional back arrow, optional actions/bottom
  bar/snackbar. Every screen uses it, so errors and loading states look identical everywhere.
* Screens are plain composables that take `container: AppContainer` — no ViewModels. State comes
  from repository `StateFlow`s via `collectAsState()`, form fields from `remember { mutableStateOf }`.
* Sizes come from `LocalFfDimens.current`, which swaps between a 60dp standard set and an 84dp glove
  set. Never hardcode a touch target; use the dimens.
* Glove mode, theme mode and haptics are settings, so the theme wrapper sits above the navigation
  graph and can rebuild the entire tree.
* Errors are user-facing *sentences* (`AppError.userMessage()`), never stack traces. The full detail
  goes to the log ring buffer, which Diagnostics can copy or share.

## Invariants worth preserving

1. Any new entity type must be added to `SyncEntities.ALL`, the repository's `ENTITY`, the
   `BackupManifest`, and the `applyRemote` when-branch — otherwise it silently stops syncing.
2. Any new persisted model must be `@Serializable` with **default values for every field**, or
   backups and sync payloads from an older version will fail to decode.
3. `AppContainer.wipeLocalData()` must clear every table you add.
4. Keep encrypted-at-rest the default for anything customer-identifying. Plaintext is only for
   exported artefacts the user explicitly asked for (PDF packets, backups).
5. Never log job content, addresses or signatures to analytics; keep to the `AnalyticsEvents`
   vocabulary already in use.
