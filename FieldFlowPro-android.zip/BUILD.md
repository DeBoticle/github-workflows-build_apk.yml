# Building FieldFlow Pro

Everything you need to produce an installable APK and a Play-ready AAB. No cloud services, no
remote build farm — a laptop with Android Studio or a JDK 17 + Android SDK is enough.

## 0. Requirements

| Tool | Version | Notes |
| --- | --- | --- |
| JDK | 17 | Android Studio ships one (`jbr`) |
| Android SDK | Platform 35 + Build-Tools 35 | `sdkmanager "platforms;android-35" "build-tools;35.0.0"` |
| Gradle | **not needed separately** | the wrapper (`./gradlew`) pins Gradle 8.11.1 |
| Android Studio | Koala (2024.1) or newer | optional but recommended |

`minSdk` is 26 (Android 8.0) and `targetSdk`/`compileSdk` are 35, so the app runs on a Samsung S23
(Android 13/14/15) and every device back to 2017.

## 1. One-time setup

1. **Point Gradle at the SDK.** Create `local.properties` in the project root:

   ```properties
   sdk.dir=/Users/you/Library/Android/sdk      # macOS
   # sdk.dir=C\:\\Users\\you\\AppData\\Local\\Android\\Sdk   # Windows
   ```

   `local.properties` is machine-specific and already listed in `.gitignore`.

2. **(Optional) configure feature keys** in the same file — see the README table. A completely
   empty `local.properties` still produces a fully working offline-first app.

3. **(Optional) Google Sign-In.** To make "Continue with Google" work you need an OAuth *Web*
   client id once for the whole app (Play Console ▸ your app ▸ Setup ▸ App signing, or Google Cloud
   Console ▸ Credentials ▸ OAuth client ID ▸ Web application). Paste it into `GOOGLE_WEB_CLIENT_ID`.
   Add both the app-signing SHA-1 and your debug SHA-1 to the same OAuth client:

   ```bash
   keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey \
           -storepass android -keypass android | grep SHA1
   ```

   Without this key the button renders disabled with the hint "Set GOOGLE_WEB_CLIENT_ID to enable";
   email sign-in and offline sign-in keep working.

## 2. Run it on a phone

```bash
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Or in Android Studio: press ▶ with the `app` configuration selected. The debug variant installs as
`com.fieldflow.pro.debug` so it can live next to a Play-installed copy.

First launch flow: sign in (email or Google) → 6-step onboarding (business details, rates,
appearance, offline rules, camera permission) → Home.

## 3. Signed release build

1. **Create an upload key** (keep it out of the repo; lose it and Play support has to reset your
   upload key for you):

   ```bash
   keytool -genkeypair -v -keystore fieldflow-upload.jks -alias fieldflow \
           -keyalg RSA -keysize 4096 -validity 10000
   ```

2. **Create `keystore.properties`** in the project root (copy `keystore.properties.example`):

   ```properties
   storeFile=fieldflow-upload.jks
   storePassword=…
   keyAlias=fieldflow
   keyPassword=…
   ```

   `storeFile` is resolved relative to the project root, so a relative path is fine.

3. **Build the bundle Play actually wants:**

   ```bash
   ./gradlew clean bundleRelease
   # → app/build/outputs/bundle/release/app-release.aab
   ```

   Also useful:

   ```bash
   ./gradlew assembleRelease   # app-release.apk, for sideloading
   ./gradlew signingReport     # confirm which key signed what
   ```

   Release builds are minified (`R8`) with `proguard-rules.pro`; kotlinx.serialization and the
   Credential Manager keep-rules are already in place. If you add a reflection-based library, add a
   keep rule for it.

4. **Sanity-check the release build on a real device before uploading** — R8 only runs in release
   mode, so this is the first time it is exercised:

   ```bash
   adb install -r app/build/outputs/apk/release/app-release.apk
   ```

## 4. Upload to Google Play

1. Play Console ▸ **Create app** ▸ name "FieldFlow Pro", App, Free.
2. Complete **App content**: privacy policy URL (host `PRIVACY_POLICY.md` — GitHub Pages, Notion,
   your own site), data safety form (answers are in `PLAY_STORE_LISTING.md`), ads = No, content
   rating questionnaire (Business/Utility, no objectionable content).
3. **Internal testing** ▸ create a release ▸ upload `app-release.aab` ▸ add your Google account as
   a tester ▸ install from the Play link and click through every screen once.
4. Fill in the **Store listing** from `PLAY_STORE_LISTING.md` and upload the promo images from
   `assets/promo/` (1920×1080), the icon from `assets/play/icon-512.png`, and the feature graphic
   from `assets/play/feature-graphic-1024x500.png`.
5. Promote to **Production** when the internal test passes.

Play App Signing: let Google manage the app signing key (default) and keep only the upload keystore.

## 5. Post-launch housekeeping

* Bump `versionCode` (integer, always increases) and `versionName` in `app/build.gradle.kts` for each
  upload. They are currently `1` and `1.0.0`.
* A staged rollout of 10–20% is worth it for the first update, since the only telemetry is the
  optional anonymous analytics log.
* If you set `SYNC_BASE_URL`, deploy `server/reference-server.js` (or your own implementation of
  `API_CONTRACT.md`) and keep `SYNC_API_KEY` out of screenshots and public repos.

## 6. Troubleshooting

| Symptom | Fix |
| --- | --- |
| `SDK location not found` | create `local.properties` with `sdk.dir` (step 1) |
| `Unsupported class file major version` | use JDK 17, not 11 or 21 |
| Google button disabled | `GOOGLE_WEB_CLIENT_ID` is blank — see step 1.3 |
| Google sign-in returns "No Google account is available" | device has no Google account, or the OAuth client is missing this build's SHA-1 |
| Camera preview stays black in the emulator | use a real device, or an emulator with a virtual scene camera enabled |
| "Sign in" fails after clearing app data | local accounts live in the encrypted vault; create the account again or restore a backup |
| PDF share fails | some OEM builds ship no PDF viewer; use Share and send it to Drive/Gmail instead |
