# Google Play listing kit — FieldFlow Pro

Copy/paste-ready store copy, Play Console answers, and the image requirements. Character limits are
the real Play limits (title 30, short description 80, full description 4000).

## App title (30 max)

```
FieldFlow Pro: Job & Quotes
```

(27 characters. Alternatives: `FieldFlow Pro – Contractor CRM` · `FieldFlow Pro Job Book`.)

## Short description (80 max)

```
Jobs, photo proof, quotes, signatures and PDF packets for trades. Works fully offline.
```

## Full description (4000 max)

```
FieldFlow Pro is the job book for one-truck contractors. Create the job on site, capture before and
after photo evidence, price it with a quote that adds itself up, get the customer's signature, and
send a professional PDF packet — all without a signal.

Built for HVAC, plumbing, electrical and handyman work, and tested with gloves on.

WHY CONTRACTORS KEEP IT ON THE HOME SCREEN

• Create a job in under a minute — title, client, address, materials, cost.
• Per-trade templates fill in the labour, materials, fees and checklist so you are not retyping.
• Camera capture with EXIF fix-up, annotations and a before/after slider that actually proves the work.
• Quote builder with labour, materials, fees and discounts; totals and tax recalculate as you type.
• Client signs on screen; the signature image plus a SHA-256 hash is stored with the job.
• Export a PDF job packet: cover, scope, materials, quote, photo grid, before/after page, signed
  acceptance page — ready to text, email or print.
• Dark mode and Glove Mode: 84dp touch targets, larger type, high contrast.

WORKS WHERE THE WORK IS

• Offline-first: every job, photo, quote and signature is written to encrypted storage on the phone
  first. No signal in a basement, a plant room or a rural service call? Everything still works.
• Auto-sync: when you get bars again, queued changes upload in the background and failed uploads
  retry with backoff. Nothing is lost and nothing blocks your day.
• Sync is optional and can be limited to Wi-Fi.

BUILT FOR DIRTY HANDS

• Big buttons, big type, high contrast, one-hand reach.
• Client and site details auto-fill on new jobs and quotes.
• Job checklist with per-item notes, progress visible from the job list.
• Everything is one tap from the job: photos, quote, signature, packet.

PRIVACY WITHOUT SMALL PRINT

• Jobs, clients, photos and signatures live in an encrypted vault on your device
  (Android Keystore, AES-256-GCM). The vault key never leaves the phone's secure hardware.
• Nothing is uploaded unless you configure sync. Analytics is opt-in, anonymous, and never includes
  job content, customer names, photos or signatures.
• Export a full encrypted backup (jobs, photos, signatures) at any time in Settings, and delete all
  local data with one confirmed action.

WHO IT IS FOR

• HVAC service and install • plumbing service and repair • electrical service and panel work •
  handyman, drywall, doors and hardware.

FieldFlow Pro is not affiliated with Google LLC.
```

## Category, tags, contact

* **App category:** Business
* **Tags:** Business, Productivity, Tools
* **Contact email:** your support address (`SUPPORT_EMAIL`)
* **Website / support URL:** your site (optional but improves the listing)

## Graphics required (and provided)

| Asset | Requirement | Where |
| --- | --- | --- |
| Phone screenshots | 2–8, PNG/JPEG, 16:9 or 9:16, min 320px, max 3840px | `assets/promo/01-job-creation.png` … `05-signature.png` (1920×1080) |
| App icon | 512×512 PNG, 32-bit, no alpha rounding needed | `assets/play/icon-512.png` |
| Feature graphic | 1024×500 PNG/JPEG, no transparency | `assets/play/feature-graphic-1024x500.png` |
| 7" / 10" tablet screenshots | optional, but improves tablet ranking | reuse the promo images |

All seven files are checked in and can be regenerated (or re-branded) with
`assets/promo-src/generate-promos.js` — see README ▸ Store artwork.

The five 1920×1080 promo images map to the requested scenes: job creation, quote builder, photo
markup, offline mode, signature capture. If Play's uploader rejects a 1920×1080 image for a phone
slot (it accepts 16:9 within the size limits), crop to 1080×1920 for a portrait set — the layout is
centred so a centre crop keeps the phone mock and headline intact.

## App content questionnaire (Play Console)

| Question | Answer |
| --- | --- |
| Ads | No ads |
| In-app purchases | No |
| Content rating | Business / Utility app, no user-generated content shared between users |
| Target audience | 18+ (business tool) |
| News app | No |
| COVID-19 contact tracing | No |
| Data collected / shared — personal info (name, email) | **Collected** (account, stored encrypted on device; email used only to sign in) |
| Data collected — photos/videos | **Collected** (job photos, stored on device, uploaded only if sync is enabled by the user) |
| Data collected — financial info (job costs) | **Collected** (invoices/quotes generated on device) |
| Data shared with third parties | None by default. If `ANALYTICS_ENDPOINT` is configured, anonymous feature-usage events only. |
| Is data encrypted in transit? | Yes (HTTPS only, when sync/analytics endpoints are configured) |
| Can users request deletion? | Yes — Settings ▸ Delete account and data |
| Data collection is optional? | Yes — the app is fully usable offline with no account upload |

Keep those answers consistent with `PRIVACY_POLICY.md`; Play cross-checks them.

## Release notes template (max 500)

```
First release.

• Create a job in under a minute with client, site address, materials and cost
• Per-trade templates for HVAC, plumbing, electrical and handyman work
• Photo capture, photo markup and a before/after comparison slider
• Quote builder with automatic totals, tax and discounts
• Client signature capture with a stored SHA-256 hash
• Export job packets as PDF and share them straight from the phone
• Offline-first with automatic background sync when you get signal
• Dark mode and Glove Mode for large-button use with gloves on
```

## Internal testing checklist before production

1. Fresh install → sign in → complete onboarding.
2. Airplane mode ON → create a job, add materials, build a quote, sign, export the PDF → all succeed.
3. Airplane mode OFF → confirm the queue drains (Settings ▸ Offline sync ▸ Waiting goes to 0).
4. Rotate and use Glove Mode on every main screen.
5. Force-stop mid-capture and reopen: no lost job, vault still decrypts.
6. Settings ▸ Export backup, wipe local data, restore backup → all jobs/photos/signatures return.
