# Privacy Policy — FieldFlow Pro

_Last updated: 15 September 2026_

FieldFlow Pro ("the app") is a job-management tool for contractors. This policy explains what the
app stores, where it goes, and how you delete it. It is written to match what the shipped code
actually does — see `ARCHITECTURE.md` if you want to verify it against the source.

**Replace the bracketed contact details before publishing, then host this document at a public URL
and paste that URL into the Play Console (App content ▸ Privacy policy).**

## Summary

* Job data, clients, photos, quotes and signatures are stored **encrypted on your device**.
* There is **no advertising, no tracking and no third-party analytics SDK**.
* Data leaves the device only when **you** configure a sync server, or opt in to analytics — and then
  only what is described below.
* You can export everything and delete everything at any time from **Settings**.

## What the app stores on your device

| Data | Purpose | Storage |
| --- | --- | --- |
| Account email, display name, business profile | Sign-in and to label your own quotes | Encrypted vault (AES-256-GCM) |
| Password (email accounts) | Sign-in on this device only | PBKDF2-HMAC-SHA256 (120,000 iterations), random per-account salt |
| Client name, company, phone, email, site address, notes | Filling out jobs and quotes | Encrypted vault |
| Jobs, materials, checklists, costs, schedules | Core app function | Encrypted vault |
| Job photos and marked-up copies | Work evidence, job packets | Encrypted files in app-private storage |
| Customer signature image, signer name, role, SHA-256 hash | Proof of acceptance | Encrypted files + encrypted vault |
| App settings and theme preferences | Your configuration | Encrypted vault |
| On-device analytics events (feature usage only) | Optional usage insight | Encrypted log, capped at 1,500 events |

The encryption key is generated inside the **Android Keystore** (hardware-backed where the device
supports it) and cannot be exported. Nothing in the vault is readable without that key, and the key
is bound to the app on that device.

Decrypted copies of photos are written to the app's private cache only while you are viewing them.
**Settings ▸ Clear image cache** removes them; Android also clears the cache under storage pressure.

## What leaves the device

**Sync (only if a sync server is configured).** When `SYNC_BASE_URL` is set, the app uploads your
records — jobs, clients, quotes, photo and signature metadata — to the server you configured, over
HTTPS, authenticated with your `SYNC_API_KEY`. Photos and signature images stay on the device in the
default configuration; only their metadata records sync. If you do not configure a sync server, the
app uses an on-device mirror and **nothing is uploaded at all**.

**Analytics (opt-in, off-switchable).** If `ANALYTICS_ENDPOINT` is configured and you leave
"Share anonymous analytics" on, the app uploads anonymous feature-usage events: event name, a small
set of non-identifying parameters (for example `trade=HVAC`, `photo_count=3`), and a timestamp.
Events never include job titles, addresses, client names, notes, photo contents, signatures, or your
email. You can switch this off in Settings and reset the local log.

**Google Sign-In (only if you use that button).** If you sign in with Google, Google's credential
library returns your Google account email, display name and an ID token. The app stores the email,
name and a truncated token reference in the encrypted vault. If the device is offline, the app
records the sign-in as unverified and does not attempt to validate the token until you are online.

**Map and dialler intents.** Tapping "Maps" or "Call" hands an address or phone number to your
device's map or dialler app. What that app then does is governed by its own privacy policy.

The app does not sell data, does not use advertising identifiers, and contains no crash-reporting or
attribution SDK.

## Permissions and why

| Permission | Reason | When it is used |
| --- | --- | --- |
| `CAMERA` | Capture job photos | Only while you are on the photo screen; you can refuse and import from the gallery instead |
| `INTERNET` | Sync and optional analytics | Only for the endpoints you configure |
| `ACCESS_NETWORK_STATE` | Know whether you are online so the queue can hold changes | Read-only, never transmitted |
| `WRITE_EXTERNAL_STORAGE` (API ≤ 28 only) | Older devices when saving exports | Legacy compatibility only |

## Retention and deletion

* Data stays on your device until you delete it. Nothing expires automatically.
* **Settings ▸ Data and storage ▸ Delete all local data** erases jobs, clients, quotes, photos,
  signatures, templates and settings from the device.
* **Settings ▸ Account ▸ Delete account and data** additionally removes your account from the device.
* If a sync server is configured, deleting on the device queues a deletion operation that propagates
  to the server on the next successful sync. You can also ask your server operator (or us, at the
  contact below) to erase server-side copies.
* Backups: **Settings ▸ Export backup** produces a self-contained encrypted `.ffbackup` file that you
  control. Deleting that file in your chosen storage location is your responsibility.

## Children

The app is a business tool and is not directed at children under 13. We do not knowingly collect
personal information from children.

## Security

* Local storage: AES-256-GCM with keys held in the Android Keystore; vault files are written
  atomically and are not readable by other apps.
* Transport: HTTPS only for sync and analytics endpoints that you configure.
* Signatures and photos are hashed (SHA-256) so tampering is detectable in exported packets.
* No security measure is perfect: a rooted or compromised device, or a device whose screen lock is
  removed, reduces the protection the operating system provides.

## Changes

Material changes to this policy will be published in the app's store listing and reflected in the
"last updated" date above, with a new app version.

## Contact

FieldFlow Pro — [your legal entity]
Email: [support@your-domain.example]
Address: [postal address if you want one listed]
