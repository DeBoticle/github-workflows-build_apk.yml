# FieldFlow Pro — user guide

A one-page guide you can ship as in-app help, print for the truck, or paste into a support page.

## First run

1. **Sign in.** Email + password, or *Continue with Google*. On a phone with no signal, use
   *Use a saved account* — the app signs you in locally and syncs later.
2. **Onboarding** takes you through six screens: what the app does, your business details (these
   print on every quote and PDF), your default trade and rates, dark mode and **Glove Mode**,
   offline/sync rules, and the camera permission.
3. You land on **Home**. That is the whole setup — about two minutes.

## Create a job (under a minute)

1. **Home ▸ New job** (the big orange button).
2. Type a **title** — "Replace capacitor, rooftop unit #3" is plenty.
3. Tap the **trade**, or tap **Start from a template** and pick e.g. *AC service call*. The template
   fills in the scope, materials, labour hours, rate and a site checklist.
4. Pick a **saved client** (or type a new name and phone). The address auto-fills from the client.
5. Add **materials**: description, qty, unit, unit price. Line totals appear as you type.
6. Set **labour hours**, **rate**, **tax %** and any **discount**. The total bar at the bottom is
   always live.
7. **Save job.** It is stored encrypted on the phone immediately — no signal needed.

## Capture evidence

**Job ▸ Photos, camera and markup**

* Choose the tag first: **Before**, **After** or **Detail**. Before/after pairs power the comparison
  slider and a dedicated page in the PDF packet.
* **Capture photo** (or *Import from gallery*). Photos are encrypted the moment they are saved and
  the originals are never modified.
* **Markup** any photo: pen, highlighter, arrow, box or a text label. Saving creates a *new*
  marked-up copy linked to the original.
* **Compare** shows the before/after slider — drag it, or use the slider under the image.

## Quote

**Job ▸ Build a quote**

* Start from a trade template or a blank quote.
* Line kinds: **Labour**, **Material**, **Fee**, **Discount**. Discount lines are subtracted and are
  never taxed.
* Quantities, unit prices, tax rate and totals recalculate live. Tick/untick **Taxable** per line.
* Set the status (Draft / Sent / Accepted / Declined / Expired) and how long the price is valid.
* Add customer notes and your terms. **Save as a custom template** to reuse the lines on the next job.

## Signature

**Job ▸ Capture signature**

1. Enter the signer's name and role (Customer, Property manager, Tenant, Site supervisor).
2. Hand the phone over; the customer signs with a finger. *Undo* removes the last stroke.
3. Confirm the terms checkbox and **Save signature**.
4. The signature image plus a SHA-256 hash is stored with the job and printed on the packet's
   acceptance page.

## Send the job packet

**Job ▸ Export PDF packet ▸ Build PDF packet**

* The packet contains: cover with job and customer details, scope of work and checklist, materials
  and labour with totals, the full quote with terms, a photo grid, a before/after page per pair, and
  the signed acceptance page.
* **Open** to view or print, **Share** to send by text, Gmail, Drive or a print app.
* Works offline — the PDF is assembled on the phone.

## Working offline (the normal case)

* Everything works with no signal: jobs, photos, quotes, signatures, PDFs.
* When you are offline, Home shows an amber banner with the number of changes waiting.
* When you get signal, changes upload automatically in the background (every 30 minutes, or
  immediately on reconnect). Settings ▸ **Sync now** forces it.
* Anything that fails to upload retries with a growing delay. Nothing is lost and nothing blocks you.

## Settings worth knowing

| Setting | What it does |
| --- | --- |
| **Glove mode** | 84dp buttons, larger type, higher contrast. Turn it on in the truck, off at the desk. |
| **Theme** | Follow system / Light / Dark. Dark is easier in a plant room. |
| **Only sync on Wi-Fi** | Stops large photo batches eating mobile data. |
| **Export / Restore backup** | One encrypted file with jobs, photos and signatures. Move it to a new phone. |
| **Clear image cache** | Deletes decrypted preview copies (the encrypted originals stay). |
| **Delete all local data** | Erases everything on this device after a confirmation. |
| **Share anonymous analytics** | Off-switchable feature-usage log. Never includes customer data. |

## Troubleshooting

| Problem | Fix |
| --- | --- |
| "Camera is still starting up" | Give it a second after opening the photos screen, or import from the gallery. |
| Camera permission denied | Photos ▸ Allow camera, or Settings ▸ Apps ▸ FieldFlow Pro ▸ Permissions. |
| PDF share opens nothing | Use **Share** and send it to Drive/Gmail — some phones ship no PDF viewer. |
| Job not on the other phone | Both devices need the same sync endpoint and API key, then Settings ▸ Sync now. |
| Forgot the password | Sign in with Google, or restore a backup on a fresh install. Local passwords cannot be recovered by design. |
