-keepattributes *Annotation*, InnerClasses, Signature, SourceFile, LineNumberTable
-keep class kotlinx.serialization.** { *; }
-keepclassmembers class **$$serializer { *; }
-keepclasseswithmembers class com.fieldflow.pro.data.model.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keepclassmembers class com.fieldflow.pro.data.model.** {
    *** Companion;
}
-keepclasseswithmembers class com.fieldflow.pro.data.model.** {
    *** Companion;
}
-dontwarn org.jetbrains.annotations.**
-keep class androidx.credentials.** { *; }
-keep class com.google.android.libraries.identity.googleid.** { *; }
