package com.fieldflow.pro

import android.app.Application
import com.fieldflow.pro.core.AppContainer

class FieldFlowApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        val created = AppContainer(this)
        container = created
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching { created.logger.e(TAG, "Uncaught exception on ${thread.name}", throwable) }
            previous?.uncaughtException(thread, throwable)
        }
        created.start()
    }

    private companion object {
        const val TAG = "FieldFlowApp"
    }
}
