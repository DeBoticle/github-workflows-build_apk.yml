package com.fieldflow.pro.core

import android.content.Context
import com.fieldflow.pro.BuildConfig
import com.fieldflow.pro.core.analytics.Analytics
import com.fieldflow.pro.core.analytics.AnalyticsEvents
import com.fieldflow.pro.core.analytics.LocalAnalytics
import com.fieldflow.pro.core.net.ConnectivityMonitor
import com.fieldflow.pro.data.auth.GoogleSignInClient
import com.fieldflow.pro.data.local.AuthRepository
import com.fieldflow.pro.data.local.ClientRepository
import com.fieldflow.pro.data.local.JobRepository
import com.fieldflow.pro.data.local.PhotoRepository
import com.fieldflow.pro.data.local.QuoteRepository
import com.fieldflow.pro.data.local.SettingsRepository
import com.fieldflow.pro.data.local.SignatureRepository
import com.fieldflow.pro.data.local.SyncQueueRepository
import com.fieldflow.pro.data.model.AppSettings
import com.fieldflow.pro.data.model.Client
import com.fieldflow.pro.data.model.Job
import com.fieldflow.pro.data.model.Photo
import com.fieldflow.pro.data.model.Quote
import com.fieldflow.pro.data.model.Signature
import com.fieldflow.pro.data.model.TradeTemplate
import com.fieldflow.pro.data.pdf.PacketExporter
import com.fieldflow.pro.data.photo.PhotoStore
import com.fieldflow.pro.data.sync.CloudApi
import com.fieldflow.pro.data.sync.HttpCloudApi
import com.fieldflow.pro.data.sync.LocalMirrorApi
import com.fieldflow.pro.data.sync.SyncEngine
import com.fieldflow.pro.data.sync.SyncOutcome
import com.fieldflow.pro.data.sync.SyncScheduler
import com.fieldflow.pro.data.templates.TemplateRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.serialization.KSerializer
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

@Serializable
data class BackupManifest(
    val format: String = BACKUP_FORMAT,
    val appVersion: String = "",
    val exportedAt: Long = 0L,
    val settings: AppSettings = AppSettings(),
    val jobs: List<Job> = emptyList(),
    val clients: List<Client> = emptyList(),
    val quotes: List<Quote> = emptyList(),
    val photos: List<Photo> = emptyList(),
    val signatures: List<Signature> = emptyList(),
    val templates: List<TradeTemplate> = emptyList(),
) {
    companion object {
        const val BACKUP_FORMAT = "fieldflow-backup-1"
    }
}

class AppContainer(private val appContext: Context) {

    val logger = AppLogger()

    val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        explicitNulls = false
    }

    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val crypto = CryptoBox()

    val vault = EncryptedJsonStore(File(appContext.filesDir, "vault"), crypto, logger)

    private fun <T : Any> table(
        name: String,
        serializer: KSerializer<T>,
        idOf: (T) -> String,
    ): JsonTable<T> = JsonTable(name, vault, json, serializer, idOf, logger)

    private val jobTable = table("jobs", Job.serializer()) { it.id }
    private val clientTable = table("clients", Client.serializer()) { it.id }
    private val quoteTable = table("quotes", Quote.serializer()) { it.id }
    private val photoTable = table("photos", Photo.serializer()) { it.id }
    private val signatureTable = table("signatures", Signature.serializer()) { it.id }
    private val queueTable = table("sync-queue", com.fieldflow.pro.data.model.SyncOperation.serializer()) { it.id }
    private val accountTable = table("accounts", com.fieldflow.pro.data.model.UserAccount.serializer()) { it.id }
    private val templateTable = table("templates-custom", TradeTemplate.serializer()) { it.id }

    val connectivity = ConnectivityMonitor(appContext)

    val analytics: LocalAnalytics = LocalAnalytics(
        store = vault,
        json = json,
        scope = scope,
        logger = logger,
        endpoint = BuildConfig.ANALYTICS_ENDPOINT,
    )

    private val analyticsSink: Analytics get() = analytics

    val queue = SyncQueueRepository(queueTable, logger, scope)
    val jobs = JobRepository(jobTable, queue, analyticsSink, logger, json, scope)
    val clients = ClientRepository(clientTable, queue, logger, json, scope)
    val quotes = QuoteRepository(quoteTable, queue, analyticsSink, logger, json, scope)
    val photos = PhotoRepository(photoTable, queue, analyticsSink, logger, json, scope)
    val signatures = SignatureRepository(signatureTable, queue, analyticsSink, logger, json, scope)
    val settings = SettingsRepository(vault, json, logger)
    val auth = AuthRepository(accountTable, vault, crypto, json, analyticsSink, logger)
    val photoStore = PhotoStore(appContext, crypto, logger)
    val templates = TemplateRepository(appContext, templateTable, json, logger)
    val packetExporter = PacketExporter(appContext, photoStore, logger)
    val googleSignIn = GoogleSignInClient(logger)

    private val photosVaultDir = File(appContext.filesDir, "photos").apply { mkdirs() }
    private val signaturesVaultDir = File(appContext.filesDir, "signatures").apply { mkdirs() }
    private val backupsDir = File(appContext.filesDir, "backups").apply { mkdirs() }

    val cloudApi: CloudApi = if (BuildConfig.SYNC_BASE_URL.isBlank()) {
        LocalMirrorApi(appContext, json, logger)
    } else {
        HttpCloudApi(BuildConfig.SYNC_BASE_URL, BuildConfig.SYNC_API_KEY, json, logger)
    }

    val sync = SyncEngine(
        queue = queue,
        jobs = jobs,
        clients = clients,
        quotes = quotes,
        photos = photos,
        signatures = signatures,
        settings = settings,
        connectivity = connectivity,
        api = cloudApi,
        analytics = analyticsSink,
        logger = logger,
        json = json,
        scope = scope,
    )

    val syncEndpointConfigured: Boolean get() = cloudApi.isConfigured
    val syncModeLabel: String get() = cloudApi.modeLabel

    private var bootstrapped = false

    suspend fun bootstrap() {
        if (bootstrapped) return
        bootstrapped = true
        settings.load()
        auth.load()
        queue.load()
        jobs.load()
        clients.load()
        quotes.load()
        photos.load()
        signatures.load()
        templates.load()
        analytics.setOptIn(settings.settings.value.analyticsOptIn)
        applySyncPolicy()
        logger.i(TAG, "Bootstrap complete (${jobs.jobs.value.size} jobs, ${clients.clients.value.size} clients)")
    }

    fun start() {
        scope.launch {
            runCatching { bootstrap() }.onFailure { logger.e(TAG, "Bootstrap failed", it) }
            analytics.log(
                AnalyticsEvents.APP_OPEN,
                mapOf(
                    "version" to BuildConfig.VERSION_NAME,
                    "sync_mode" to cloudApi.modeLabel,
                    "online" to connectivity.isCurrentlyOnline(),
                ),
            )
            var wasOnline = connectivity.online.value
            connectivity.online.collect { online ->
                if (online && !wasOnline) {
                    analytics.log(AnalyticsEvents.ONLINE_RESTORED)
                    if (settings.settings.value.autoSync) {
                        SyncScheduler.requestImmediateSync(appContext, "connectivity")
                    }
                } else if (!online && wasOnline) {
                    analytics.log(AnalyticsEvents.OFFLINE_MODE_ENTERED)
                }
                wasOnline = online
            }
        }
    }

    fun applySyncPolicy() {
        val current = settings.settings.value
        analytics.setOptIn(current.analyticsOptIn)
        if (current.autoSync) {
            SyncScheduler.schedulePeriodic(appContext, current.syncOnWifiOnly)
        } else {
            SyncScheduler.cancelPeriodic(appContext)
        }
    }

    suspend fun syncNow(trigger: String = "manual"): SyncOutcome {
        val outcome = sync.syncNow(trigger)
        if (outcome is SyncOutcome.Success) settings.recordSync(outcome.cursor, outcome.pulled, outcome.pushed)
        return outcome
    }

    suspend fun signOut() {
        auth.signOut()
        applySyncPolicy()
    }

    suspend fun wipeLocalData() {
        queue.clear()
        jobTable.replaceAll(emptyList())
        clientTable.replaceAll(emptyList())
        quoteTable.replaceAll(emptyList())
        photoTable.replaceAll(emptyList())
        signatureTable.replaceAll(emptyList())
        templateTable.replaceAll(emptyList())
        photoStore.wipeAll()
        logger.w(TAG, "Local job data wiped at user request")
    }

    suspend fun deleteAllUserData() {
        wipeLocalData()
        auth.deleteAccountAndData()
        analytics.reset()
        settings.reset()
        applySyncPolicy()
        logger.w(TAG, "All local data deleted at user request")
    }

    suspend fun exportBackup(): AppResult<File> {
        return try {
            val settingsValue = settings.current()
            val manifest = BackupManifest(
                appVersion = BuildConfig.VERSION_NAME,
                exportedAt = System.currentTimeMillis(),
                settings = settingsValue,
                jobs = jobTable.ensureLoaded(),
                clients = clientTable.ensureLoaded(),
                quotes = quoteTable.ensureLoaded(),
                photos = photoTable.ensureLoaded(),
                signatures = signatureTable.ensureLoaded(),
                templates = templateTable.ensureLoaded(),
            )
            val stamp = Dates.formatDate(System.currentTimeMillis()).replace(" ", "-")
            val target = File(backupsDir, "fieldflow-backup-$stamp.ffbackup")
            ZipOutputStream(target.outputStream().buffered()).use { zip ->
                zip.putNextEntry(ZipEntry(MANIFEST_ENTRY))
                zip.write(json.encodeToString(BackupManifest.serializer(), manifest).toByteArray(Charsets.UTF_8))
                zip.closeEntry()
                manifest.photos.forEach { photo -> addMedia(zip, "photos", photo.fileName) }
                manifest.signatures.forEach { signature -> addMedia(zip, "signatures", signature.fileName) }
            }
            analytics.log(
                AnalyticsEvents.DATA_EXPORTED,
                mapOf("jobs" to manifest.jobs.size, "photos" to manifest.photos.size),
            )
            logger.i(TAG, "Backup written: ${target.name} (${target.length()} bytes)")
            AppResult.Success(target)
        } catch (t: Throwable) {
            logger.e(TAG, "Backup export failed", t)
            AppResult.Failure(AppError.Storage(t.message ?: "Could not create the backup"))
        }
    }

    suspend fun importBackup(file: File): AppResult<Int> {
        return try {
            var manifest: BackupManifest? = null
            ZipInputStream(file.inputStream().buffered()).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name
                    when {
                        name == MANIFEST_ENTRY -> {
                            val text = zip.readBytes().toString(Charsets.UTF_8)
                            manifest = json.decodeFromString(BackupManifest.serializer(), text)
                        }
                        name.startsWith("photos/") -> writeMedia(zip, photosVaultDir, name.removePrefix("photos/"))
                        name.startsWith("signatures/") -> writeMedia(zip, signaturesVaultDir, name.removePrefix("signatures/"))
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
            val loaded = manifest ?: return AppResult.Failure(AppError.Storage("That file isn't a FieldFlow backup."))
            jobTable.replaceAll(loaded.jobs)
            clientTable.replaceAll(loaded.clients)
            quoteTable.replaceAll(loaded.quotes)
            photoTable.replaceAll(loaded.photos)
            signatureTable.replaceAll(loaded.signatures)
            templateTable.replaceAll(loaded.templates)
            photoStore.clearPreviews()
            settings.update { current ->
                loaded.settings.copy(
                    onboardingComplete = current.onboardingComplete || loaded.settings.onboardingComplete,
                    createdAt = current.createdAt,
                )
            }
            applySyncPolicy()
            analytics.log(
                AnalyticsEvents.DATA_IMPORTED,
                mapOf("jobs" to loaded.jobs.size, "photos" to loaded.photos.size),
            )
            AppResult.Success(loaded.jobs.size)
        } catch (t: Throwable) {
            logger.e(TAG, "Backup import failed", t)
            AppResult.Failure(AppError.Storage(t.message ?: "Could not read that backup"))
        }
    }

    fun backupsDirectory(): File = backupsDir

    private fun addMedia(zip: ZipOutputStream, folder: String, fileName: String) {
        if (fileName.isBlank()) return
        val source = File(if (folder == "photos") photosVaultDir else signaturesVaultDir, fileName)
        if (!source.exists()) return
        val plain = runCatching { crypto.decrypt(source.readBytes()) }.getOrNull() ?: return
        zip.putNextEntry(ZipEntry("$folder/$fileName"))
        zip.write(plain)
        zip.closeEntry()
    }

    private fun writeMedia(zip: ZipInputStream, dir: File, fileName: String) {
        if (fileName.isBlank() || fileName.contains("..")) return
        val bytes = zip.readBytes()
        if (bytes.isEmpty()) return
        File(dir, fileName).writeBytes(crypto.encrypt(bytes))
    }

    private companion object {
        const val TAG = "AppContainer"
        const val MANIFEST_ENTRY = "manifest.json"
    }
}
