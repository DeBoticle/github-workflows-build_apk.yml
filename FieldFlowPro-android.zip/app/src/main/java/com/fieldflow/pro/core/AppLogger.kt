package com.fieldflow.pro.core

import android.util.Log
import com.fieldflow.pro.BuildConfig

class AppLogger {

    private val ring = ArrayDeque<String>()
    private val lock = Any()
    private val maxRing = 400

    fun d(tag: String, message: String) {
        if (BuildConfig.DEBUG) Log.d(tag, message)
        add("D", tag, message)
    }

    fun i(tag: String, message: String) {
        Log.i(tag, message)
        add("I", tag, message)
    }

    fun w(tag: String, message: String, throwable: Throwable? = null) {
        Log.w(tag, message, throwable)
        add("W", tag, message + (throwable?.let { " :: ${it.javaClass.simpleName}: ${it.message}" } ?: ""))
    }

    fun e(tag: String, message: String, throwable: Throwable? = null) {
        Log.e(tag, message, throwable)
        add("E", tag, message + (throwable?.let { " :: ${it.javaClass.simpleName}: ${it.message}" } ?: ""))
    }

    fun recent(limit: Int = 200): List<String> = synchronized(lock) { ring.takeLast(limit) }

    fun asText(): String = synchronized(lock) { ring.joinToString("\n") }

    fun clear() = synchronized(lock) { ring.clear() }

    private fun add(level: String, tag: String, message: String) {
        val line = "$level/$tag: $message"
        synchronized(lock) {
            ring.addLast(line)
            while (ring.size > maxRing) ring.removeFirst()
        }
    }
}
