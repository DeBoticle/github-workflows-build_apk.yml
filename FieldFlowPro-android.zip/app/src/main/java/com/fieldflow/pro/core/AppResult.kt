package com.fieldflow.pro.core

sealed class AppError {

    data class Validation(val field: String, val message: String) : AppError()

    data class Auth(val message: String) : AppError()

    data class Network(val message: String, val retryable: Boolean = true) : AppError()

    data class Storage(val message: String) : AppError()

    data class Crypto(val message: String) : AppError()

    data class ConfigMissing(val key: String) : AppError()

    data class NotConfigured(val feature: String) : AppError()

    data class Permission(val permission: String) : AppError()

    data class Unknown(val message: String) : AppError()

    fun userMessage(): String = when (this) {
        is Validation -> message
        is Auth -> message
        is Network -> message
        is Storage -> "Couldn't save on this device: $message"
        is Crypto -> "Encrypted storage problem: $message"
        is ConfigMissing -> "$key isn't configured yet. Add it to local.properties and rebuild."
        is NotConfigured -> "$feature isn't set up yet."
        is Permission -> "Permission needed: $permission"
        is Unknown -> message
    }
}

sealed interface AppResult<out T> {
    data class Success<T>(val value: T) : AppResult<T>
    data class Failure(val error: AppError) : AppResult<Nothing>

    val isSuccess: Boolean get() = this is Success
}

fun <T> AppResult<T>.valueOrNull(): T? = (this as? AppResult.Success)?.value

fun AppResult<*>.errorOrNull(): AppError? = (this as? AppResult.Failure)?.error

inline fun <T, R> AppResult<T>.map(transform: (T) -> R): AppResult<R> = when (this) {
    is AppResult.Success -> AppResult.Success(transform(value))
    is AppResult.Failure -> this
}

inline fun <T> appRunCatching(block: () -> T): AppResult<T> = try {
    AppResult.Success(block())
} catch (t: Throwable) {
    AppResult.Failure(AppError.Unknown(t.message ?: t.javaClass.simpleName))
}
