package com.fieldflow.pro.core

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class CryptoException(message: String, cause: Throwable? = null) : Exception(message, cause)

class CryptoBox {

    private val random = SecureRandom()

    private fun keyStore(): KeyStore = KeyStore.getInstance(KEYSTORE).apply { load(null) }

    private fun masterKey(): SecretKey {
        val store = keyStore()
        (store.getEntry(MASTER_ALIAS, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                MASTER_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build(),
        )
        return generator.generateKey()
    }

    fun encrypt(plain: ByteArray): ByteArray {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, masterKey())
        val iv = cipher.iv
        val cipherText = cipher.doFinal(plain)
        val out = ByteArray(2 + iv.size + cipherText.size)
        out[0] = FORMAT_VERSION
        out[1] = iv.size.toByte()
        System.arraycopy(iv, 0, out, 2, iv.size)
        System.arraycopy(cipherText, 0, out, 2 + iv.size, cipherText.size)
        return out
    }

    fun decrypt(data: ByteArray): ByteArray {
        if (data.size < 3 || data[0] != FORMAT_VERSION) throw CryptoException("Unsupported ciphertext header")
        val ivLength = data[1].toInt()
        if (ivLength <= 0 || data.size < 2 + ivLength + 16) throw CryptoException("Truncated ciphertext")
        return try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(
                Cipher.DECRYPT_MODE,
                masterKey(),
                GCMParameterSpec(GCM_TAG_BITS, data, 2, ivLength),
            )
            cipher.doFinal(data, 2 + ivLength, data.size - 2 - ivLength)
        } catch (t: Throwable) {
            throw CryptoException("Decryption failed — encryption key unavailable on this device", t)
        }
    }

    fun encryptToFile(plainFile: File, target: File) {
        val payload = encrypt(plainFile.readBytes())
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.parentFile?.mkdirs()
        tmp.writeBytes(payload)
        if (target.exists()) target.delete()
        if (!tmp.renameTo(target)) {
            target.writeBytes(payload)
            tmp.delete()
        }
    }

    fun decryptToFile(cipherFile: File, target: File) {
        val plain = decrypt(cipherFile.readBytes())
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.parentFile?.mkdirs()
        tmp.writeBytes(plain)
        if (target.exists()) target.delete()
        if (!tmp.renameTo(target)) {
            target.writeBytes(plain)
            tmp.delete()
        }
    }

    fun sha256Hex(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun randomBytes(size: Int): ByteArray = ByteArray(size).also { random.nextBytes(it) }

    fun randomToken(size: Int = 32): String = randomBytes(size).joinToString("") { "%02x".format(it) }

    fun hashPassword(password: String, saltBase64: String, iterations: Int = PBKDF2_ITERATIONS): String {
        val salt = android.util.Base64.decode(saltBase64, android.util.Base64.NO_WRAP)
        return pbkdf2(password, salt, iterations)
    }

    fun newSaltBase64(): String =
        android.util.Base64.encodeToString(randomBytes(16), android.util.Base64.NO_WRAP)

    private fun pbkdf2(password: String, salt: ByteArray, iterations: Int): String {
        val spec = PBEKeySpec(password.toCharArray(), salt, iterations, 256)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val key = factory.generateSecret(spec)
        spec.clearPassword()
        return android.util.Base64.encodeToString(key.encoded, android.util.Base64.NO_WRAP)
    }

    fun constantTimeEquals(a: String, b: String): Boolean {
        val x = a.toByteArray()
        val y = b.toByteArray()
        if (x.size != y.size) return false
        var diff = 0
        for (i in x.indices) diff = diff or (x[i].toInt() xor y[i].toInt())
        return diff == 0
    }

    fun deriveLocalKey(passphrase: String, salt: String): SecretKey {
        val keyBytes = android.util.Base64.decode(
            pbkdf2(passphrase, salt.toByteArray(), PBKDF2_ITERATIONS),
            android.util.Base64.NO_WRAP,
        )
        return SecretKeySpec(keyBytes, "AES")
    }

    private companion object {
        const val KEYSTORE = "AndroidKeyStore"
        const val MASTER_ALIAS = "fieldflow_master_v1"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val GCM_TAG_BITS = 128
        const val FORMAT_VERSION: Byte = 1
        const val PBKDF2_ITERATIONS = 120_000
    }
}
