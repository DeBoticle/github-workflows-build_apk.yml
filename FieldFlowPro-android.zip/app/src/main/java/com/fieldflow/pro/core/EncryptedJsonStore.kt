package com.fieldflow.pro.core

import kotlinx.serialization.KSerializer
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class EncryptedJsonStore(
    private val dir: File,
    private val crypto: CryptoBox,
    private val logger: AppLogger,
) {

    private val mutex = Mutex()

    init {
        if (!dir.exists()) dir.mkdirs()
    }

    suspend fun read(name: String): String? = withContext(Dispatchers.IO) {
        mutex.withLock {
            val file = File(dir, name)
            if (!file.exists() || file.length() == 0L) return@withLock null
            try {
                String(crypto.decrypt(file.readBytes()), Charsets.UTF_8)
            } catch (t: Throwable) {
                logger.e(TAG, "Failed to read $name", t)
                throw t
            }
        }
    }

    suspend fun write(name: String, text: String): Unit = withContext(Dispatchers.IO) {
        mutex.withLock {
            val payload = crypto.encrypt(text.toByteArray(Charsets.UTF_8))
            val target = File(dir, name)
            val tmp = File(dir, "$name.tmp")
            tmp.writeBytes(payload)
            if (target.exists()) target.delete()
            if (!tmp.renameTo(target)) {
                target.writeBytes(payload)
                tmp.delete()
            }
        }
    }

    suspend fun delete(name: String): Unit = withContext(Dispatchers.IO) {
        mutex.withLock { File(dir, name).delete() }
    }

    suspend fun wipe(): Unit = withContext(Dispatchers.IO) {
        mutex.withLock {
            dir.listFiles()?.forEach { it.delete() }
            dir.mkdirs()
        }
    }

    fun files(): List<String> = dir.listFiles()?.filter { it.isFile }?.map { it.name }?.sorted() ?: emptyList()

    fun sizeBytes(): Long = dir.listFiles()?.sumOf { it.length() } ?: 0L

    private companion object {
        const val TAG = "EncryptedJsonStore"
    }
}

class JsonTable<T : Any>(
    val name: String,
    private val store: EncryptedJsonStore,
    private val json: Json,
    private val itemSerializer: KSerializer<T>,
    private val idOf: (T) -> String,
    private val logger: AppLogger,
) {

    private val listSerializer = ListSerializer(itemSerializer)
    private val _items = MutableStateFlow<List<T>>(emptyList())
    val items: StateFlow<List<T>> = _items.asStateFlow()
    private val loaded = AtomicBoolean(false)

    val fileName: String get() = "$name.json.enc"

    suspend fun load(): List<T> {
        val raw = try {
            store.read(fileName)
        } catch (t: Throwable) {
            logger.w(TAG, "Vault entry $name could not be decrypted; starting empty", t)
            null
        }
        val list = raw?.let {
            runCatching { json.decodeFromString(listSerializer, it) }.getOrElse { e ->
                logger.e(TAG, "Corrupt $name payload", e)
                emptyList()
            }
        } ?: emptyList()
        _items.value = list
        loaded.set(true)
        return list
    }

    suspend fun ensureLoaded(): List<T> = if (loaded.get()) _items.value else load()

    fun snapshot(): List<T> = _items.value

    fun find(id: String): T? = _items.value.firstOrNull { idOf(it) == id }

    suspend fun persist() {
        val payload = json.encodeToString(listSerializer, _items.value)
        store.write(fileName, payload)
    }

    suspend fun upsert(item: T) {
        ensureLoaded()
        _items.update { current ->
            val index = current.indexOfFirst { idOf(it) == idOf(item) }
            if (index >= 0) current.toMutableList().also { it[index] = item } else current + item
        }
        persist()
    }

    suspend fun upsertAll(newItems: List<T>) {
        ensureLoaded()
        if (newItems.isEmpty()) return
        _items.update { current ->
            val map = LinkedHashMap<String, T>(current.size + newItems.size)
            current.forEach { map[idOf(it)] = it }
            newItems.forEach { map[idOf(it)] = it }
            map.values.toList()
        }
        persist()
    }

    suspend fun deleteById(id: String) {
        ensureLoaded()
        _items.update { current -> current.filterNot { idOf(it) == id } }
        persist()
    }

    suspend fun replaceAll(newItems: List<T>) {
        loaded.set(true)
        _items.value = newItems
        persist()
    }

    private companion object {
        const val TAG = "JsonTable"
    }
}
