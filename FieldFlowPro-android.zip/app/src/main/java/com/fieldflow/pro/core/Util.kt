package com.fieldflow.pro.core

import java.text.NumberFormat
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Currency
import java.util.Locale
import java.util.UUID

object Ids {
    fun new(prefix: String = ""): String {
        val raw = UUID.randomUUID().toString().replace("-", "").lowercase()
        return if (prefix.isEmpty()) raw else "$prefix-$raw"
    }

    fun jobNumber(sequence: Int, year: Int = java.time.LocalDate.now().year): String =
        "JOB-$year-" + sequence.toString().padStart(4, '0')

    fun quoteNumber(sequence: Int, year: Int = java.time.LocalDate.now().year): String =
        "QTE-$year-" + sequence.toString().padStart(4, '0')
}

object Money {
    fun format(cents: Long, currencyCode: String = "USD"): String {
        val currency = runCatching { Currency.getInstance(currencyCode) }.getOrNull() ?: Currency.getInstance("USD")
        val format = NumberFormat.getCurrencyInstance(Locale.getDefault()).apply { this.currency = currency }
        return format.format(cents / 100.0)
    }

    fun formatPlain(cents: Long): String {
        val negative = cents < 0
        val abs = kotlin.math.abs(cents)
        val text = "${abs / 100}.${(abs % 100).toString().padStart(2, '0')}"
        return if (negative) "-$text" else text
    }

    fun parseToCents(input: String): Long? {
        val cleaned = input.trim().replace(",", "").replace("$", "").replace(" ", "")
        if (cleaned.isEmpty()) return null
        val value = cleaned.toDoubleOrNull() ?: return null
        if (value.isNaN() || value.isInfinite()) return null
        return Math.round(value * 100.0)
    }

    fun parseQty(input: String): Double? = input.trim().replace(",", "").toDoubleOrNull()
}

object Dates {
    private val zone: ZoneId get() = ZoneId.systemDefault()

    fun formatDate(epochMs: Long): String =
        Instant.ofEpochMilli(epochMs).atZone(zone).format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.getDefault()))

    fun formatDateTime(epochMs: Long): String =
        Instant.ofEpochMilli(epochMs).atZone(zone).format(DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm", Locale.getDefault()))

    fun formatTime(epochMs: Long): String =
        Instant.ofEpochMilli(epochMs).atZone(zone).format(DateTimeFormatter.ofPattern("HH:mm", Locale.getDefault()))

    fun relative(epochMs: Long, now: Long = System.currentTimeMillis()): String {
        if (epochMs <= 0L) return "never"
        val delta = now - epochMs
        return when {
            delta < 60_000 -> "just now"
            delta < 3_600_000 -> "${delta / 60_000} min ago"
            delta < 86_400_000 -> "${delta / 3_600_000} h ago"
            delta < 7 * 86_400_000L -> "${delta / 86_400_000} d ago"
            else -> formatDate(epochMs)
        }
    }

    fun todayStart(now: Long = System.currentTimeMillis()): Long =
        Instant.ofEpochMilli(now).atZone(zone).toLocalDate().atStartOfDay(zone).toInstant().toEpochMilli()

    fun endOfDay(dayStartMs: Long): Long = dayStartMs + 86_400_000L - 1
}

object Bytes {
    fun human(size: Long): String = when {
        size < 1024 -> "$size B"
        size < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", size / 1024.0)
        size < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", size / (1024.0 * 1024))
        else -> String.format(Locale.US, "%.2f GB", size / (1024.0 * 1024 * 1024))
    }
}

fun String.orDash(): String = ifBlank { "—" }

fun String.initials(): String =
    trim().split(" ").filter { it.isNotBlank() }.take(2).map { it.first().uppercaseChar() }.joinToString("").ifBlank { "?" }
