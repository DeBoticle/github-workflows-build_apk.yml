package com.fieldflow.pro.core.analytics

import com.fieldflow.pro.core.AppLogger
import com.fieldflow.pro.core.EncryptedJsonStore
import com.fieldflow.pro.data.model.AnalyticsEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

object AnalyticsEvents {
    const val APP_OPEN = "app_open"
    const val ONBOARDING_START = "onboarding_start"
    const val ONBOARDING_STEP = "onboarding_step"
    const val ONBOARDING_COMPLETE = "onboarding_complete"
    const val SIGN_IN = "sign_in"
    const val SIGN_UP = "sign_up"
    const val SIGN_IN_FAILED = "sign_in_failed"
    const val SIGN_OUT = "sign_out"
    const val JOB_CREATED = "job_created"
    const val JOB_UPDATED = "job_updated"
    const val JOB_COMPLETED = "job_completed"
    const val TEMPLATE_APPLIED = "template_applied"
    const val PHOTO_ADDED = "photo_added"
    const val PHOTO_MARKED_UP = "photo_marked_up"
    const val SIGNATURE_CAPTURED = "signature_captured"
    const val QUOTE_CREATED = "quote_created"
    const val QUOTE_UPDATED = "quote_updated"
    const val QUOTE_STATUS_CHANGED = "quote_status_changed"
    const val PDF_EXPORTED = "pdf_exported"
    const val SYNC_STARTED = "sync_started"
    const val SYNC_SUCCEEDED = "sync_succeeded"
    const val SYNC_FAILED = "sync_failed"
    const val SYNC_OFFLINE = "sync_skipped_offline"
    const val OFFLINE_MODE_ENTERED = "offline_mode_entered"
    const val ONLINE_RESTORED = "online_restored"
    const val SETTINGS_CHANGED = "settings_changed"
    const val DATA_EXPORTED = "data_exported"
    const val DATA_IMPORTED = "data_imported"
    const val ACCOUNT_DELETED = "account_deleted"
    const val ERROR = "error"
}

interface Analytics {
    val events: StateFlow<List<AnalyticsEvent>>
    val queueSize: Int
    val endpointConfigured: Boolean
    fun log(name: String, params: Map<String, Any?> = emptyMap())
    suspend fun flush(): Int
    suspend fun clearUploaded()
    suspend fun reset()
}

class LocalAnalytics(
    private val store: EncryptedJsonStore,
    private val json: Json,
    private val scope: CoroutineScope,
    private val logger: AppLogger,
    private val endpoint: String,
) : Analytics {

    private val _events = MutableStateFlow<List<AnalyticsEvent>>(emptyList())
    override val events: StateFlow<List<AnalyticsEvent>> = _events.asStateFlow()

    private val loaded = AtomicBoolean(false)
    private var optedIn: Boolean = true

    override val endpointConfigured: Boolean get() = endpoint.isNotBlank()

    override val queueSize: Int get() = _events.value.count { !it.uploaded }

    fun setOptIn(enabled: Boolean) {
        optedIn = enabled
        if (!enabled) scope.launch { persist() }
    }

    private suspend fun ensureLoaded() {
        if (loaded.getAndSet(true)) return
        val raw = runCatching { store.read(FILE) }.getOrNull()
        val parsed = raw?.let { text ->
            runCatching { json.decodeFromString(ListSerializer(AnalyticsEvent.serializer()), text) }.getOrElse {
                logger.w(TAG, "Analytics log unreadable, starting fresh", it)
                emptyList()
            }
        } ?: emptyList()
        _events.value = parsed
    }

    override fun log(name: String, params: Map<String, Any?>) {
        scope.launch {
            ensureLoaded()
            val event = AnalyticsEvent(
                name = name,
                params = params.entries.filter { it.value != null }
                    .associate { it.key to it.value.toString().take(200) },
                at = System.currentTimeMillis(),
            )
            val next = (_events.value + event).let { list ->
                if (list.size > MAX_EVENTS) list.takeLast(MAX_EVENTS) else list
            }
            _events.value = next
            persist()
            if (optedIn && endpointConfigured) runCatching { flush() }
        }
    }

    override suspend fun flush(): Int = withContext(Dispatchers.IO) {
        ensureLoaded()
        if (endpoint.isBlank()) return@withContext 0
        if (!optedIn) return@withContext 0
        val pending = _events.value.filter { !it.uploaded }
        if (pending.isEmpty()) return@withContext 0
        val batch = pending.take(MAX_BATCH)
        val body = json.encodeToString(
            ListSerializer(AnalyticsEvent.serializer()),
            batch,
        )
        val sent = try {
            postJson(endpoint, body)
        } catch (t: Throwable) {
            logger.w(TAG, "Analytics flush failed", t)
            0
        }
        if (sent) {
            val ids = batch.map { it.id }.toSet()
            _events.value = _events.value.map { if (it.id in ids) it.copy(uploaded = true) else it }
            persist()
            batch.size
        } else {
            0
        }
    }

    private fun postJson(url: String, body: String): Boolean {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 8_000
            readTimeout = 12_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        return try {
            DataOutputStream(connection.outputStream).use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            logger.d(TAG, "Analytics flush -> HTTP $code")
            code in 200..299
        } finally {
            connection.disconnect()
        }
    }

    override suspend fun clearUploaded() {
        ensureLoaded()
        _events.value = _events.value.filterNot { it.uploaded }
        persist()
    }

    override suspend fun reset() {
        _events.value = emptyList()
        store.delete(FILE)
        loaded.set(false)
    }

    private suspend fun persist() {
        runCatching { store.write(FILE, json.encodeToString(ListSerializer(AnalyticsEvent.serializer()), _events.value)) }
            .onFailure { logger.w(TAG, "Analytics persist failed", it) }
    }

    private companion object {
        const val TAG = "Analytics"
        const val FILE = "analytics.json.enc"
        const val MAX_EVENTS = 1500
        const val MAX_BATCH = 100
    }
}
