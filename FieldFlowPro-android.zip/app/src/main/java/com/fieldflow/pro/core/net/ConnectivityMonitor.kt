package com.fieldflow.pro.core.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ConnectivityMonitor(context: Context) {

    private val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val _online = MutableStateFlow(isCurrentlyOnline())
    val online: StateFlow<Boolean> = _online.asStateFlow()
    private val _metered = MutableStateFlow(isMetered())

    val metered: StateFlow<Boolean> = _metered.asStateFlow()

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) = refresh()
        override fun onLost(network: Network) = refresh()
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) = refresh()
        override fun onUnavailable() = refresh()
    }

    init {
        runCatching { manager.registerDefaultNetworkCallback(callback) }
            .onFailure { _online.value = isCurrentlyOnline() }
    }

    fun isCurrentlyOnline(): Boolean {
        val caps = runCatching { manager.getNetworkCapabilities(manager.activeNetwork) }.getOrNull() ?: return false
        val hasInternet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        val validated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        return hasInternet && validated
    }

    fun isMetered(): Boolean {
        val caps = runCatching { manager.getNetworkCapabilities(manager.activeNetwork) }.getOrNull() ?: return true
        return !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }

    fun refresh() {
        _online.value = isCurrentlyOnline()
        _metered.value = isMetered()
    }

    fun describe(): String = when {
        !_online.value -> "Offline"
        _metered.value -> "Online (mobile data)"
        else -> "Online (Wi-Fi)"
    }
}
