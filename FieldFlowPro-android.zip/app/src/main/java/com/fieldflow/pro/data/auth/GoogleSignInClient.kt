package com.fieldflow.pro.data.auth

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.fieldflow.pro.BuildConfig
import com.fieldflow.pro.core.AppError
import com.fieldflow.pro.core.AppLogger
import com.fieldflow.pro.core.AppResult
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class GoogleIdentity(
    val subject: String,
    val email: String,
    val displayName: String,
    val idToken: String,
    val verifiedOnline: Boolean,
)

class GoogleSignInClient(private val logger: AppLogger) {

    val isConfigured: Boolean get() = BuildConfig.GOOGLE_WEB_CLIENT_ID.isNotBlank()

    suspend fun signIn(context: Context): AppResult<GoogleIdentity> {
        if (!isConfigured) {
            return AppResult.Failure(AppError.ConfigMissing("GOOGLE_WEB_CLIENT_ID"))
        }
        val manager = CredentialManager.create(context)
        val option = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(BuildConfig.GOOGLE_WEB_CLIENT_ID)
            .setAutoSelectEnabled(false)
            .build()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(option)
            .build()

        return try {
            val response = manager.getCredential(context, request)
            val credential = response.credential
            if (credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                return AppResult.Failure(AppError.Auth("Google returned an unexpected credential type."))
            }
            val google = GoogleIdTokenCredential.createFrom(credential.data)
            val verified = verifyTokenOnline(google.idToken)
            AppResult.Success(
                GoogleIdentity(
                    subject = google.id,
                    email = google.email.orEmpty(),
                    displayName = google.displayName.orEmpty(),
                    idToken = google.idToken,
                    verifiedOnline = verified,
                ),
            )
        } catch (e: GetCredentialCancellationException) {
            AppResult.Failure(AppError.Auth("Google sign-in was cancelled."))
        } catch (e: NoCredentialException) {
            AppResult.Failure(AppError.Auth("No Google account is available on this device."))
        } catch (e: GetCredentialException) {
            logger.w(TAG, "Google credential failure", e)
            AppResult.Failure(AppError.Auth(e.message ?: "Google sign-in failed."))
        } catch (t: Throwable) {
            logger.e(TAG, "Google sign-in crashed", t)
            AppResult.Failure(AppError.Unknown(t.message ?: "Google sign-in failed."))
        }
    }

    private suspend fun verifyTokenOnline(idToken: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val encoded = URLEncoder.encode(idToken, "UTF-8")
            val connection = (URL("https://oauth2.googleapis.com/tokeninfo?id_token=$encoded").openConnection() as HttpURLConnection).apply {
                connectTimeout = 8_000
                readTimeout = 8_000
                requestMethod = "GET"
            }
            if (connection.responseCode != 200) {
                connection.disconnect()
                return@withContext false
            }
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()
            val json = JSONObject(body)
            val audienceMatches = json.optString("aud") == BuildConfig.GOOGLE_WEB_CLIENT_ID
            val emailVerified = json.optString("email_verified").equals("true", ignoreCase = true)
            audienceMatches && emailVerified
        } catch (t: Throwable) {
            logger.w(TAG, "Google token verification unavailable (offline?)", t)
            false
        }
    }

    private companion object {
        const val TAG = "GoogleSignIn"
    }
}
