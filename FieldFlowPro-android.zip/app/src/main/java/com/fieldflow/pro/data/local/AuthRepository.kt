package com.fieldflow.pro.data.local

import com.fieldflow.pro.core.AppError
import com.fieldflow.pro.core.AppLogger
import com.fieldflow.pro.core.AppResult
import com.fieldflow.pro.core.CryptoBox
import com.fieldflow.pro.core.EncryptedJsonStore
import com.fieldflow.pro.core.JsonTable
import com.fieldflow.pro.core.analytics.Analytics
import com.fieldflow.pro.core.analytics.AnalyticsEvents
import com.fieldflow.pro.data.model.AuthProvider
import com.fieldflow.pro.data.model.Session
import com.fieldflow.pro.data.model.UserAccount
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.Json

class AuthRepository(
    private val table: JsonTable<UserAccount>,
    private val store: EncryptedJsonStore,
    private val crypto: CryptoBox,
    private val json: Json,
    private val analytics: Analytics,
    private val logger: AppLogger,
) {

    private val mutex = Mutex()
    private val _session = MutableStateFlow<Session?>(null)
    val session: StateFlow<Session?> = _session.asStateFlow()

    val isSignedIn: Boolean get() = _session.value != null

    suspend fun load() {
        table.load()
        val raw = runCatching { store.read(FILE_SESSION) }.getOrNull() ?: return
        runCatching { json.decodeFromString(Session.serializer(), raw) }
            .onSuccess { _session.value = it }
            .onFailure { logger.w(TAG, "Session unreadable; signing out", it) }
    }

    suspend fun accounts(): List<UserAccount> = table.ensureLoaded()

    suspend fun signInAsStoredAccount(userId: String, offlineOnly: Boolean = true): AppResult<Session> = mutex.withLock {
        val account = table.find(userId)
            ?: return@withLock AppResult.Failure(AppError.Auth("That account isn't stored on this device."))
        val now = System.currentTimeMillis()
        table.upsert(account.copy(lastLoginAt = now))
        val session = Session(
            userId = account.id,
            email = account.email,
            displayName = account.displayName,
            provider = account.provider,
            signedInAt = now,
            token = crypto.randomToken(16),
            offlineOnly = offlineOnly,
        )
        persistSession(session)
        analytics.log(
            AnalyticsEvents.SIGN_IN,
            mapOf("provider" to account.provider.name.lowercase(), "offline" to offlineOnly),
        )
        AppResult.Success(session)
    }

    suspend fun signUpWithEmail(
        email: String,
        password: String,
        displayName: String,
        businessName: String,
    ): AppResult<Session> = mutex.withLock {
        val cleanEmail = email.trim().lowercase()
        validateEmail(cleanEmail)?.let { return@withLock AppResult.Failure(it) }
        validatePassword(password)?.let { return@withLock AppResult.Failure(it) }
        if (table.ensureLoaded().any { it.email == cleanEmail }) {
            return@withLock AppResult.Failure(AppError.Auth("That email already has an account on this device."))
        }
        val now = System.currentTimeMillis()
        val salt = crypto.newSaltBase64()
        val account = UserAccount(
            email = cleanEmail,
            displayName = displayName.trim().ifBlank { cleanEmail.substringBefore("@") },
            provider = AuthProvider.EMAIL,
            passwordHash = crypto.hashPassword(password, salt),
            passwordSalt = salt,
            businessName = businessName.trim(),
            createdAt = now,
            lastLoginAt = now,
        )
        table.upsert(account)
        val session = Session(
            userId = account.id,
            email = account.email,
            displayName = account.displayName,
            provider = AuthProvider.EMAIL,
            signedInAt = now,
            token = crypto.randomToken(24),
        )
        persistSession(session)
        analytics.log(AnalyticsEvents.SIGN_UP, mapOf("provider" to "email"))
        AppResult.Success(session)
    }

    suspend fun signInWithEmail(email: String, password: String): AppResult<Session> = mutex.withLock {
        val cleanEmail = email.trim().lowercase()
        val account = table.ensureLoaded().firstOrNull { it.email == cleanEmail }
        if (account == null || account.provider != AuthProvider.EMAIL) {
            analytics.log(AnalyticsEvents.SIGN_IN_FAILED, mapOf("provider" to "email", "reason" to "no_account"))
            return@withLock AppResult.Failure(AppError.Auth("No account found for that email. Create one first."))
        }
        val candidate = crypto.hashPassword(password, account.passwordSalt)
        if (!crypto.constantTimeEquals(candidate, account.passwordHash)) {
            analytics.log(AnalyticsEvents.SIGN_IN_FAILED, mapOf("provider" to "email", "reason" to "bad_password"))
            return@withLock AppResult.Failure(AppError.Auth("That password doesn't match."))
        }
        val now = System.currentTimeMillis()
        table.upsert(account.copy(lastLoginAt = now))
        val session = Session(
            userId = account.id,
            email = account.email,
            displayName = account.displayName,
            provider = AuthProvider.EMAIL,
            signedInAt = now,
            token = crypto.randomToken(24),
        )
        persistSession(session)
        analytics.log(AnalyticsEvents.SIGN_IN, mapOf("provider" to "email"))
        AppResult.Success(session)
    }

    suspend fun signInWithGoogleIdentity(
        subject: String,
        email: String,
        displayName: String,
        idToken: String,
        verifiedOnline: Boolean,
    ): AppResult<Session> = mutex.withLock {
        val cleanEmail = email.trim().lowercase()
        if (cleanEmail.isBlank()) {
            return@withLock AppResult.Failure(AppError.Auth("Google didn't return an email address for this account."))
        }
        val now = System.currentTimeMillis()
        val existing = table.ensureLoaded().firstOrNull { it.email == cleanEmail }
        val account = (existing ?: UserAccount(
            email = cleanEmail,
            displayName = displayName.ifBlank { cleanEmail.substringBefore("@") },
            provider = AuthProvider.GOOGLE,
            createdAt = now,
        )).copy(
            displayName = displayName.ifBlank { existing?.displayName ?: cleanEmail.substringBefore("@") },
            provider = AuthProvider.GOOGLE,
            remoteVerified = verifiedOnline,
            lastLoginAt = now,
        )
        table.upsert(account)
        val session = Session(
            userId = account.id,
            email = cleanEmail,
            displayName = account.displayName,
            provider = AuthProvider.GOOGLE,
            signedInAt = now,
            token = idToken.take(512),
            offlineOnly = !verifiedOnline,
        )
        persistSession(session)
        analytics.log(
            AnalyticsEvents.SIGN_IN,
            mapOf("provider" to "google", "verified_online" to verifiedOnline, "subject" to subject.take(16)),
        )
        AppResult.Success(session)
    }

    suspend fun updateProfile(displayName: String, businessName: String): AppResult<Session> = mutex.withLock {
        val session = _session.value ?: return@withLock AppResult.Failure(AppError.Auth("You're signed out."))
        val account = table.find(session.userId)
            ?: return@withLock AppResult.Failure(AppError.Auth("Account not found on this device."))
        val updated = account.copy(
            displayName = displayName.trim().ifBlank { account.displayName },
            businessName = businessName.trim(),
        )
        table.upsert(updated)
        val next = session.copy(displayName = updated.displayName)
        persistSession(next)
        AppResult.Success(next)
    }

    suspend fun changePassword(currentPassword: String, newPassword: String): AppResult<Unit> = mutex.withLock {
        val session = _session.value ?: return@withLock AppResult.Failure(AppError.Auth("You're signed out."))
        val account = table.find(session.userId)
            ?: return@withLock AppResult.Failure(AppError.Auth("Account not found on this device."))
        if (account.provider != AuthProvider.EMAIL) {
            return@withLock AppResult.Failure(AppError.Auth("Google accounts sign in with Google, not a password."))
        }
        val candidate = crypto.hashPassword(currentPassword, account.passwordSalt)
        if (!crypto.constantTimeEquals(candidate, account.passwordHash)) {
            return@withLock AppResult.Failure(AppError.Auth("Current password is incorrect."))
        }
        validatePassword(newPassword)?.let { return@withLock AppResult.Failure(it) }
        val salt = crypto.newSaltBase64()
        table.upsert(account.copy(passwordHash = crypto.hashPassword(newPassword, salt), passwordSalt = salt))
        AppResult.Success(Unit)
    }

    suspend fun signOut() = mutex.withLock {
        _session.value = null
        store.delete(FILE_SESSION)
        analytics.log(AnalyticsEvents.SIGN_OUT)
    }

    suspend fun deleteAccountAndData() = mutex.withLock {
        val userId = _session.value?.userId
        if (userId != null) table.deleteById(userId)
        _session.value = null
        store.delete(FILE_SESSION)
        analytics.log(AnalyticsEvents.ACCOUNT_DELETED)
    }

    private suspend fun persistSession(session: Session) {
        _session.value = session
        store.write(FILE_SESSION, json.encodeToString(Session.serializer(), session))
    }

    private fun validateEmail(email: String): AppError? {
        if (email.isBlank()) return AppError.Validation("email", "Enter your email address.")
        if (!EMAIL_REGEX.matches(email)) return AppError.Validation("email", "That doesn't look like an email address.")
        return null
    }

    private fun validatePassword(password: String): AppError? {
        if (password.length < 8) return AppError.Validation("password", "Use at least 8 characters.")
        if (password.none { it.isDigit() } || password.none { it.isLetter() }) {
            return AppError.Validation("password", "Mix letters and numbers.")
        }
        return null
    }

    private companion object {
        const val TAG = "AuthRepo"
        const val FILE_SESSION = "session.json.enc"
        val EMAIL_REGEX = Regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]{2,}$")
    }
}
