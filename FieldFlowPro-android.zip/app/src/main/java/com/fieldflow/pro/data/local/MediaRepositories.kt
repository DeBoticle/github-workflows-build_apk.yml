package com.fieldflow.pro.data.local

import com.fieldflow.pro.core.AppLogger
import com.fieldflow.pro.core.JsonTable
import com.fieldflow.pro.core.analytics.Analytics
import com.fieldflow.pro.core.analytics.AnalyticsEvents
import com.fieldflow.pro.data.model.Photo
import com.fieldflow.pro.data.model.PhotoKind
import com.fieldflow.pro.data.model.Signature
import com.fieldflow.pro.data.model.SyncState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.serialization.json.Json

class PhotoRepository(
    private val table: JsonTable<Photo>,
    private val queue: SyncQueueRepository,
    private val analytics: Analytics,
    private val logger: AppLogger,
    private val json: Json,
    scope: CoroutineScope,
) {

    val photos: StateFlow<List<Photo>> = table.items.map { list ->
        list.filterNot { it.deleted }.sortedByDescending { it.capturedAt }
    }.stateIn(scope, SharingStarted.Eagerly, emptyList())

    suspend fun load(): List<Photo> = table.load()

    suspend fun byId(id: String): Photo? = table.ensureLoaded().firstOrNull { it.id == id && !it.deleted }

    suspend fun forJob(jobId: String): List<Photo> =
        table.ensureLoaded().filter { it.jobId == jobId && !it.deleted }.sortedBy { it.capturedAt }

    fun observeForJob(jobId: String): Flow<List<Photo>> = table.items.map { list ->
        list.filter { it.jobId == jobId && !it.deleted }.sortedBy { it.capturedAt }
    }

    suspend fun save(photo: Photo, event: String? = null): Photo {
        val now = System.currentTimeMillis()
        val existing = table.find(photo.id)
        val stamped = photo.copy(
            createdAt = if (photo.createdAt == 0L) existing?.createdAt ?: now else photo.createdAt,
            updatedAt = now,
            version = (existing?.version ?: photo.version) + (if (existing != null) 1L else 0L),
            syncState = SyncState.PENDING,
        )
        table.upsert(stamped)
        queue.enqueue(ENTITY, stamped.id, if (stamped.deleted) "delete" else "upsert", json.encodeToString(Photo.serializer(), stamped), now)
        if (event != null) {
            analytics.log(
                event,
                mapOf(
                    "photo_id" to stamped.id,
                    "job_id" to stamped.jobId,
                    "kind" to stamped.kind.name,
                    "size_bytes" to stamped.sizeBytes,
                ),
            )
        }
        return stamped
    }

    suspend fun softDelete(id: String) {
        val photo = byId(id) ?: return
        val now = System.currentTimeMillis()
        val tombstone = photo.copy(deleted = true, updatedAt = now, syncState = SyncState.PENDING, version = photo.version + 1)
        table.upsert(tombstone)
        queue.enqueue(ENTITY, id, "delete", json.encodeToString(Photo.serializer(), tombstone), now)
    }

    suspend fun applyRemote(remote: Photo): Boolean {
        val local = table.find(remote.id)
        if (local != null && local.updatedAt > remote.updatedAt && local.syncState == SyncState.PENDING) return false
        table.upsert(remote.copy(syncState = SyncState.SYNCED))
        return true
    }

    suspend fun markSynced(ids: Collection<String>) {
        if (ids.isEmpty()) return
        val set = ids.toSet()
        table.upsertAll(table.snapshot().filter { it.id in set }.map { it.copy(syncState = SyncState.SYNCED) })
    }

    suspend fun totalBytes(): Long = table.ensureLoaded().filterNot { it.deleted }.sumOf { it.sizeBytes }

    suspend fun markUploaded(event: String = AnalyticsEvents.PHOTO_ADDED) = Unit

    suspend fun beforeAfterPairs(jobId: String): List<Pair<Photo?, Photo?>> {
        val list = forJob(jobId)
        val before = list.filter { it.kind == PhotoKind.BEFORE }
        val after = list.filter { it.kind == PhotoKind.AFTER }
        return before.mapIndexed { index, b -> b to after.getOrNull(index) }
    }

    companion object {
        const val ENTITY = "photo"
    }
}

class SignatureRepository(
    private val table: JsonTable<Signature>,
    private val queue: SyncQueueRepository,
    private val analytics: Analytics,
    private val logger: AppLogger,
    private val json: Json,
    scope: CoroutineScope,
) {

    val signatures: StateFlow<List<Signature>> = table.items.map { list ->
        list.filterNot { it.deleted }.sortedByDescending { it.signedAt }
    }.stateIn(scope, SharingStarted.Eagerly, emptyList())

    suspend fun load(): List<Signature> = table.load()

    suspend fun byId(id: String): Signature? = table.ensureLoaded().firstOrNull { it.id == id && !it.deleted }

    suspend fun forJob(jobId: String): Signature? =
        table.ensureLoaded().filter { it.jobId == jobId && !it.deleted }.maxByOrNull { it.signedAt }

    fun observeForJob(jobId: String): Flow<Signature?> = table.items.map { list ->
        list.filter { it.jobId == jobId && !it.deleted }.maxByOrNull { it.signedAt }
    }

    suspend fun save(signature: Signature): Signature {
        val now = System.currentTimeMillis()
        val existing = table.find(signature.id)
        val stamped = signature.copy(
            updatedAt = now,
            version = (existing?.version ?: signature.version) + (if (existing != null) 1L else 0L),
            syncState = SyncState.PENDING,
        )
        table.upsert(stamped)
        queue.enqueue(ENTITY, stamped.id, if (stamped.deleted) "delete" else "upsert", json.encodeToString(Signature.serializer(), stamped), now)
        analytics.log(
            AnalyticsEvents.SIGNATURE_CAPTURED,
            mapOf("job_id" to stamped.jobId, "signer_role" to stamped.signerRole, "signature_id" to stamped.id),
        )
        return stamped
    }

    suspend fun softDelete(id: String) {
        val signature = byId(id) ?: return
        val now = System.currentTimeMillis()
        val tombstone = signature.copy(deleted = true, updatedAt = now, syncState = SyncState.PENDING, version = signature.version + 1)
        table.upsert(tombstone)
        queue.enqueue(ENTITY, id, "delete", json.encodeToString(Signature.serializer(), tombstone), now)
    }

    suspend fun applyRemote(remote: Signature): Boolean {
        val local = table.find(remote.id)
        if (local != null && local.updatedAt > remote.updatedAt && local.syncState == SyncState.PENDING) return false
        table.upsert(remote.copy(syncState = SyncState.SYNCED))
        return true
    }

    suspend fun markSynced(ids: Collection<String>) {
        if (ids.isEmpty()) return
        val set = ids.toSet()
        table.upsertAll(table.snapshot().filter { it.id in set }.map { it.copy(syncState = SyncState.SYNCED) })
    }

    companion object {
        const val ENTITY = "signature"
    }
}
