package com.fieldflow.pro.data.local

import com.fieldflow.pro.core.AppLogger
import com.fieldflow.pro.core.Ids
import com.fieldflow.pro.core.JsonTable
import com.fieldflow.pro.core.analytics.Analytics
import com.fieldflow.pro.core.analytics.AnalyticsEvents
import com.fieldflow.pro.data.model.Client
import com.fieldflow.pro.data.model.Job
import com.fieldflow.pro.data.model.JobStatus
import com.fieldflow.pro.data.model.Quote
import com.fieldflow.pro.data.model.QuoteStatus
import com.fieldflow.pro.data.model.SyncState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.serialization.json.Json

class JobRepository(
    private val table: JsonTable<Job>,
    private val queue: SyncQueueRepository,
    private val analytics: Analytics,
    private val logger: AppLogger,
    private val json: Json,
    scope: CoroutineScope,
) {

    val jobs: StateFlow<List<Job>> = table.items.map { list ->
        list.filterNot { it.deleted }.sortedByDescending { it.updatedAt }
    }.stateIn(scope, SharingStarted.Eagerly, emptyList())

    val openJobs: StateFlow<List<Job>> = table.items.map { list ->
        list.filterNot { it.deleted }.filter { it.isOpen }
            .sortedWith(compareBy({ it.scheduledAt == 0L }, { it.scheduledAt }, { -it.updatedAt }))
    }.stateIn(scope, SharingStarted.Eagerly, emptyList())

    val pendingSyncCount: StateFlow<Int> = table.items.map { list ->
        list.count { !it.deleted && it.syncState == SyncState.PENDING }
    }.stateIn(scope, SharingStarted.Eagerly, 0)

    suspend fun load(): List<Job> = table.load()

    fun observe(id: String): Flow<Job?> = table.items.map { list -> list.firstOrNull { it.id == id && !it.deleted } }

    suspend fun byId(id: String): Job? = table.ensureLoaded().firstOrNull { it.id == id && !it.deleted }

    suspend fun all(): List<Job> = table.ensureLoaded().filterNot { it.deleted }

    suspend fun save(job: Job, event: String? = null): Job {
        val now = System.currentTimeMillis()
        val existing = table.find(job.id)
        val stamped = job.copy(
            number = job.number.ifBlank { existing?.number ?: nextNumber() },
            createdAt = if (job.createdAt == 0L) existing?.createdAt ?: now else job.createdAt,
            updatedAt = now,
            version = (existing?.version ?: job.version) + (if (existing != null) 1L else 0L),
            syncState = SyncState.PENDING,
        )
        table.upsert(stamped)
        queue.enqueue(ENTITY, stamped.id, if (stamped.deleted) "delete" else "upsert", json.encodeToString(Job.serializer(), stamped), now)
        if (event != null) {
            analytics.log(
                event,
                mapOf(
                    "job_id" to stamped.id,
                    "trade" to stamped.trade.name,
                    "status" to stamped.status.name,
                    "total_cents" to stamped.totalCents,
                    "photo_count" to stamped.photoIds.size,
                ),
            )
        }
        return stamped
    }

    suspend fun setStatus(id: String, status: JobStatus): Job? {
        val job = byId(id) ?: return null
        val updated = save(
            job.copy(
                status = status,
                completedAt = if (status == JobStatus.COMPLETE) System.currentTimeMillis() else job.completedAt,
            ),
            if (status == JobStatus.COMPLETE) AnalyticsEvents.JOB_COMPLETED else null,
        )
        return updated
    }

    suspend fun attachPhoto(jobId: String, photoId: String): Job? {
        val job = byId(jobId) ?: return null
        if (job.photoIds.contains(photoId)) return job
        return save(job.copy(photoIds = job.photoIds + photoId))
    }

    suspend fun detachPhoto(jobId: String, photoId: String): Job? {
        val job = byId(jobId) ?: return null
        return save(job.copy(photoIds = job.photoIds - photoId))
    }

    suspend fun attachSignature(jobId: String, signatureId: String): Job? {
        val job = byId(jobId) ?: return null
        return save(
            job.copy(
                signatureId = signatureId,
                status = if (job.isOpen) JobStatus.AWAITING_SIGNATURE else job.status,
            ),
        )
    }

    suspend fun softDelete(id: String) {
        val job = byId(id) ?: return
        val now = System.currentTimeMillis()
        val tombstone = job.copy(deleted = true, updatedAt = now, syncState = SyncState.PENDING, version = job.version + 1)
        table.upsert(tombstone)
        queue.enqueue(ENTITY, id, "delete", json.encodeToString(Job.serializer(), tombstone), now)
        analytics.log(AnalyticsEvents.JOB_UPDATED, mapOf("job_id" to id, "deleted" to true))
    }

    suspend fun applyRemote(remote: Job): Boolean {
        val local = table.find(remote.id)
        if (local != null && local.updatedAt > remote.updatedAt && local.syncState == SyncState.PENDING) {
            logger.d(TAG, "keeping local ${remote.id} (newer)")
            return false
        }
        table.upsert(remote.copy(syncState = SyncState.SYNCED))
        return true
    }

    suspend fun markSynced(ids: Collection<String>) {
        if (ids.isEmpty()) return
        val set = ids.toSet()
        table.upsertAll(
            table.snapshot().filter { it.id in set }
                .map { it.copy(syncState = SyncState.SYNCED) },
        )
    }

    suspend fun markFailed(ids: Collection<String>) {
        if (ids.isEmpty()) return
        val set = ids.toSet()
        table.upsertAll(
            table.snapshot().filter { it.id in set }
                .map { it.copy(syncState = SyncState.FAILED) },
        )
    }

    private fun nextNumber(): String {
        val year = java.time.LocalDate.now().year
        val seq = table.snapshot().count { it.number.contains(year.toString()) } + 1
        return Ids.jobNumber(seq, year)
    }

    companion object {
        const val ENTITY = "job"
        private const val TAG = "JobRepo"
    }
}

class ClientRepository(
    private val table: JsonTable<Client>,
    private val queue: SyncQueueRepository,
    private val logger: AppLogger,
    private val json: Json,
    scope: CoroutineScope,
) {

    val clients: StateFlow<List<Client>> = table.items.map { list ->
        list.filterNot { it.deleted }.sortedBy { it.name.lowercase() }
    }.stateIn(scope, SharingStarted.Eagerly, emptyList())

    private val _search = MutableStateFlow("")
    val search: StateFlow<String> = _search.asStateFlow()

    suspend fun load(): List<Client> = table.load()

    suspend fun byId(id: String): Client? = table.ensureLoaded().firstOrNull { it.id == id }

    suspend fun save(client: Client): Client {
        val now = System.currentTimeMillis()
        val existing = table.find(client.id)
        val stamped = client.copy(
            createdAt = if (client.createdAt == 0L) existing?.createdAt ?: now else client.createdAt,
            updatedAt = now,
            version = (existing?.version ?: client.version) + (if (existing != null) 1L else 0L),
            syncState = SyncState.PENDING,
        )
        table.upsert(stamped)
        queue.enqueue(ENTITY, stamped.id, if (stamped.deleted) "delete" else "upsert", json.encodeToString(Client.serializer(), stamped), now)
        return stamped
    }

    suspend fun softDelete(id: String) {
        val client = byId(id) ?: return
        val now = System.currentTimeMillis()
        val tombstone = client.copy(deleted = true, updatedAt = now, syncState = SyncState.PENDING, version = client.version + 1)
        table.upsert(tombstone)
        queue.enqueue(ENTITY, id, "delete", json.encodeToString(Client.serializer(), tombstone), now)
    }

    suspend fun applyRemote(remote: Client): Boolean {
        val local = table.find(remote.id)
        if (local != null && local.updatedAt > remote.updatedAt && local.syncState == SyncState.PENDING) return false
        table.upsert(remote.copy(syncState = SyncState.SYNCED))
        return true
    }

    suspend fun markSynced(ids: Collection<String>) {
        if (ids.isEmpty()) return
        val set = ids.toSet()
        table.upsertAll(table.snapshot().filter { it.id in set }.map { it.copy(syncState = SyncState.SYNCED) })
    }

    suspend fun matching(query: String): List<Client> {
        if (query.isBlank()) return clients.value
        val q = query.lowercase()
        return clients.value.filter {
            it.name.lowercase().contains(q) || it.phone.contains(q) || it.address.lowercase().contains(q) ||
                it.company.lowercase().contains(q)
        }
    }

    val clientCount: StateFlow<Int> = clients.map { it.size }.stateIn(scope, SharingStarted.Eagerly, 0)

    companion object {
        const val ENTITY = "client"
    }
}

class QuoteRepository(
    private val table: JsonTable<Quote>,
    private val queue: SyncQueueRepository,
    private val analytics: Analytics,
    private val logger: AppLogger,
    private val json: Json,
    scope: CoroutineScope,
) {

    val quotes: StateFlow<List<Quote>> = table.items.map { list ->
        list.filterNot { it.deleted }.sortedByDescending { it.updatedAt }
    }.stateIn(scope, SharingStarted.Eagerly, emptyList())

    suspend fun load(): List<Quote> = table.load()

    fun observeForJob(jobId: String): Flow<List<Quote>> = table.items.map { list ->
        list.filter { it.jobId == jobId && !it.deleted }.sortedByDescending { it.updatedAt }
    }

    fun observe(id: String): Flow<Quote?> = table.items.map { list -> list.firstOrNull { it.id == id && !it.deleted } }

    suspend fun byId(id: String): Quote? = table.ensureLoaded().firstOrNull { it.id == id && !it.deleted }

    suspend fun latestForJob(jobId: String): Quote? =
        table.ensureLoaded().filter { it.jobId == jobId && !it.deleted }.maxByOrNull { it.updatedAt }

    suspend fun save(quote: Quote, event: String? = null): Quote {
        val now = System.currentTimeMillis()
        val existing = table.find(quote.id)
        val stamped = quote.copy(
            number = quote.number.ifBlank { existing?.number ?: nextNumber() },
            createdAt = if (quote.createdAt == 0L) existing?.createdAt ?: now else quote.createdAt,
            updatedAt = now,
            version = (existing?.version ?: quote.version) + (if (existing != null) 1L else 0L),
            syncState = SyncState.PENDING,
        )
        table.upsert(stamped)
        queue.enqueue(ENTITY, stamped.id, if (stamped.deleted) "delete" else "upsert", json.encodeToString(Quote.serializer(), stamped), now)
        if (event != null) {
            analytics.log(
                event,
                mapOf(
                    "quote_id" to stamped.id,
                    "job_id" to stamped.jobId,
                    "line_count" to stamped.lines.size,
                    "total_cents" to stamped.totalCents,
                    "status" to stamped.status.name,
                ),
            )
        }
        return stamped
    }

    suspend fun applyRemote(remote: Quote): Boolean {
        val local = table.find(remote.id)
        if (local != null && local.updatedAt > remote.updatedAt && local.syncState == SyncState.PENDING) return false
        table.upsert(remote.copy(syncState = SyncState.SYNCED))
        return true
    }

    suspend fun markSynced(ids: Collection<String>) {
        if (ids.isEmpty()) return
        val set = ids.toSet()
        table.upsertAll(table.snapshot().filter { it.id in set }.map { it.copy(syncState = SyncState.SYNCED) })
    }

    suspend fun quotedValueCents(): Long =
        quotes.value.filter { it.status != QuoteStatus.DECLINED }.sumOf { it.totalCents }

    private fun nextNumber(): String {
        val year = java.time.LocalDate.now().year
        val seq = table.snapshot().count { it.number.contains(year.toString()) } + 1
        return Ids.quoteNumber(seq, year)
    }

    companion object {
        const val ENTITY = "quote"
    }
}
