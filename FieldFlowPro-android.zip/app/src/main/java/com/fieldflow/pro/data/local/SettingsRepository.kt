package com.fieldflow.pro.data.local

import com.fieldflow.pro.core.AppLogger
import com.fieldflow.pro.core.EncryptedJsonStore
import com.fieldflow.pro.data.model.AppSettings
import com.fieldflow.pro.data.model.DeviceIdentity
import com.fieldflow.pro.data.model.SyncCursorState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.Json

class SettingsRepository(
    private val store: EncryptedJsonStore,
    private val json: Json,
    private val logger: AppLogger,
) {

    private val mutex = Mutex()
    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _device = MutableStateFlow(DeviceIdentity())
    val device: StateFlow<DeviceIdentity> = _device.asStateFlow()

    private val _cursor = MutableStateFlow(SyncCursorState())
    val cursor: StateFlow<SyncCursorState> = _cursor.asStateFlow()

    suspend fun load() {
        readInto(FILE_SETTINGS, AppSettings.serializer(), _settings)
        readInto(FILE_DEVICE, DeviceIdentity.serializer(), _device)
        readInto(FILE_CURSOR, SyncCursorState.serializer(), _cursor)
    }

    suspend fun current(): AppSettings = _settings.value

    suspend fun update(transform: (AppSettings) -> AppSettings): AppSettings = mutex.withLock {
        val now = System.currentTimeMillis()
        val existing = _settings.value
        val next = transform(existing).copy(
            createdAt = if (existing.createdAt == 0L) now else existing.createdAt,
            updatedAt = now,
            version = existing.version + 1,
        )
        _settings.value = next
        store.write(FILE_SETTINGS, json.encodeToString(AppSettings.serializer(), next))
        next
    }

    suspend fun recordSync(cursorValue: String, pulled: Int, pushed: Int, error: String = "") = mutex.withLock {
        val state = SyncCursorState(
            cursor = cursorValue,
            lastSyncAt = System.currentTimeMillis(),
            lastPulledCount = pulled,
            lastPushedCount = pushed,
        )
        _cursor.value = state
        store.write(FILE_CURSOR, json.encodeToString(SyncCursorState.serializer(), state))
        val next = _settings.value.copy(
            lastSyncAt = state.lastSyncAt,
            lastSyncCursor = cursorValue,
            lastSyncError = error,
        )
        _settings.value = next
        store.write(FILE_SETTINGS, json.encodeToString(AppSettings.serializer(), next))
    }

    suspend fun reset() = mutex.withLock {
        _settings.value = AppSettings()
        _cursor.value = SyncCursorState()
        store.delete(FILE_SETTINGS)
        store.delete(FILE_CURSOR)
        store.write(FILE_DEVICE, json.encodeToString(DeviceIdentity.serializer(), _device.value))
    }

    private suspend fun <T> readInto(
        file: String,
        serializer: kotlinx.serialization.KSerializer<T>,
        target: MutableStateFlow<T>,
    ) {
        val raw = runCatching { store.read(file) }.getOrNull() ?: return
        runCatching { json.decodeFromString(serializer, raw) }
            .onSuccess { target.value = it }
            .onFailure { logger.w(TAG, "Could not read $file, using defaults", it) }
    }

    private companion object {
        const val TAG = "SettingsRepo"
        const val FILE_SETTINGS = "settings.json.enc"
        const val FILE_DEVICE = "device.json.enc"
        const val FILE_CURSOR = "sync-cursor.json.enc"
    }
}
