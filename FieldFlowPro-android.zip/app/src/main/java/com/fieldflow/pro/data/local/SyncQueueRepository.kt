package com.fieldflow.pro.data.local

import com.fieldflow.pro.core.AppLogger
import com.fieldflow.pro.core.JsonTable
import com.fieldflow.pro.data.model.SyncOperation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class SyncQueueRepository(
    private val table: JsonTable<SyncOperation>,
    private val logger: AppLogger,
    scope: CoroutineScope,
) {

    val operations: StateFlow<List<SyncOperation>> = table.items

    val pendingCount: StateFlow<Int> = table.items
        .map { list -> list.size }
        .stateIn(scope, SharingStarted.Eagerly, 0)

    val failedCount: StateFlow<Int> = table.items
        .map { list -> list.count { it.attempts > 0 } }
        .stateIn(scope, SharingStarted.Eagerly, 0)

    suspend fun load(): List<SyncOperation> = table.load()

    suspend fun enqueue(
        entityType: String,
        entityId: String,
        op: String,
        payload: String,
        now: Long = System.currentTimeMillis(),
    ) {
        val existing = table.snapshot().firstOrNull { it.entityType == entityType && it.entityId == entityId }
        val record = SyncOperation(
            id = existing?.id ?: SyncOperation().id,
            entityType = entityType,
            entityId = entityId,
            op = op,
            payload = payload,
            attempts = 0,
            nextAttemptAt = now,
            lastError = "",
            createdAt = existing?.createdAt ?: now,
        )
        table.upsert(record)
        logger.d(TAG, "queued $op $entityType/$entityId")
    }

    suspend fun dueBatch(now: Long, limit: Int): List<SyncOperation> =
        table.snapshot().filter { it.nextAttemptAt <= now }.sortedBy { it.createdAt }.take(limit)

    suspend fun all(): List<SyncOperation> = table.ensureLoaded()

    suspend fun markDone(ids: Collection<String>) {
        ids.forEach { table.deleteById(it) }
    }

    suspend fun markFailed(id: String, error: String, nextAttemptAt: Long) {
        val record = table.find(id) ?: return
        table.upsert(
            record.copy(
                attempts = record.attempts + 1,
                lastError = error.take(300),
                nextAttemptAt = nextAttemptAt,
            ),
        )
    }

    suspend fun dropFor(entityType: String, entityId: String) {
        table.snapshot()
            .filter { it.entityType == entityType && it.entityId == entityId }
            .forEach { table.deleteById(it.id) }
    }

    suspend fun clear() = table.replaceAll(emptyList())

    private companion object {
        const val TAG = "SyncQueue"
    }
}
