package com.fieldflow.pro.data.model

import com.fieldflow.pro.core.Dates
import com.fieldflow.pro.core.Ids
import kotlinx.serialization.Serializable

@Serializable
enum class Trade(val displayName: String, val shortCode: String) {
    HVAC("HVAC", "HVAC"),
    PLUMBING("Plumbing", "PLMB"),
    ELECTRICAL("Electrical", "ELEC"),
    HANDYMAN("Handyman", "HAND"),
}

@Serializable
enum class JobStatus(val displayName: String) {
    DRAFT("Draft"),
    SCHEDULED("Scheduled"),
    IN_PROGRESS("On site"),
    AWAITING_SIGNATURE("Awaiting signature"),
    COMPLETE("Complete"),
    INVOICED("Invoiced"),
    CANCELLED("Cancelled"),
}

@Serializable
enum class Priority(val displayName: String) {
    LOW("Low"),
    NORMAL("Normal"),
    URGENT("Urgent"),
    EMERGENCY("Emergency"),
}

@Serializable
enum class SyncState(val displayName: String) {
    PENDING("Waiting to sync"),
    SYNCING("Syncing"),
    SYNCED("Synced"),
    FAILED("Sync failed"),
    CONFLICT("Conflict — kept newest"),
}

@Serializable
enum class PhotoKind(val displayName: String) {
    BEFORE("Before"),
    AFTER("After"),
    DETAIL("Detail"),
    MARKUP("Marked up"),
}

@Serializable
enum class QuoteStatus(val displayName: String) {
    DRAFT("Draft"),
    SENT("Sent"),
    ACCEPTED("Accepted"),
    DECLINED("Declined"),
    EXPIRED("Expired"),
}

@Serializable
enum class QuoteLineKind(val displayName: String) {
    LABOUR("Labour"),
    MATERIAL("Material"),
    FEE("Fee"),
    DISCOUNT("Discount"),
}

@Serializable
enum class AuthProvider(val displayName: String) {
    EMAIL("Email"),
    GOOGLE("Google"),
}

@Serializable
enum class ThemeMode(val displayName: String) {
    SYSTEM("Follow system"),
    LIGHT("Light"),
    DARK("Dark"),
}

@Serializable
data class MaterialLine(
    val id: String = Ids.new("mat"),
    val description: String = "",
    val quantity: Double = 1.0,
    val unit: String = "ea",
    val unitPriceCents: Long = 0L,
    val supplier: String = "",
    val taxable: Boolean = true,
) {
    val lineTotalCents: Long get() = Math.round(quantity * unitPriceCents.toDouble())
}

@Serializable
data class ChecklistItem(
    val id: String = Ids.new("chk"),
    val label: String = "",
    val done: Boolean = false,
    val note: String = "",
)

@Serializable
data class Job(
    val id: String = Ids.new("job"),
    val number: String = "",
    val title: String = "",
    val clientId: String? = null,
    val clientName: String = "",
    val clientPhone: String = "",
    val address: String = "",
    val trade: Trade = Trade.HVAC,
    val status: JobStatus = JobStatus.SCHEDULED,
    val priority: Priority = Priority.NORMAL,
    val description: String = "",
    val materials: List<MaterialLine> = emptyList(),
    val checklist: List<ChecklistItem> = emptyList(),
    val labourHours: Double = 0.0,
    val labourRateCents: Long = 0L,
    val taxRatePercent: Double = 0.0,
    val discountCents: Long = 0L,
    val photoIds: List<String> = emptyList(),
    val signatureId: String? = null,
    val scheduledAt: Long = 0L,
    val completedAt: Long = 0L,
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L,
    val syncState: SyncState = SyncState.PENDING,
    val version: Long = 1L,
    val deleted: Boolean = false,
) {

    val materialsTotalCents: Long get() = materials.sumOf { it.lineTotalCents }

    val labourTotalCents: Long get() = Math.round(labourHours * labourRateCents.toDouble())

    val subtotalCents: Long get() = materialsTotalCents + labourTotalCents

    val taxableBaseCents: Long get() = (subtotalCents - discountCents).coerceAtLeast(0L)

    val taxCents: Long get() = Math.round(taxableBaseCents * (taxRatePercent / 100.0))

    val totalCents: Long get() = taxableBaseCents + taxCents

    val checklistProgress: Float
        get() = if (checklist.isEmpty()) 0f else checklist.count { it.done }.toFloat() / checklist.size

    val isOpen: Boolean
        get() = status != JobStatus.COMPLETE && status != JobStatus.INVOICED && status != JobStatus.CANCELLED

    val scheduledLabel: String
        get() = if (scheduledAt <= 0L) "Unscheduled" else Dates.formatDate(scheduledAt)
}

@Serializable
data class QuoteLine(
    val id: String = Ids.new("ql"),
    val kind: QuoteLineKind = QuoteLineKind.LABOUR,
    val description: String = "",
    val detail: String = "",
    val quantity: Double = 1.0,
    val unit: String = "ea",
    val unitPriceCents: Long = 0L,
    val taxable: Boolean = true,
) {
    val lineTotalCents: Long
        get() = if (kind == QuoteLineKind.DISCOUNT) {
            -Math.round(quantity * unitPriceCents.toDouble())
        } else {
            Math.round(quantity * unitPriceCents.toDouble())
        }
}

@Serializable
data class Quote(
    val id: String = Ids.new("qte"),
    val jobId: String = "",
    val number: String = "",
    val status: QuoteStatus = QuoteStatus.DRAFT,
    val lines: List<QuoteLine> = emptyList(),
    val taxRatePercent: Double = 0.0,
    val notes: String = "",
    val terms: String = "",
    val validUntil: Long = 0L,
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L,
    val syncState: SyncState = SyncState.PENDING,
    val version: Long = 1L,
    val deleted: Boolean = false,
) {

    val subtotalCents: Long get() = lines.sumOf { it.lineTotalCents }

    val discountCents: Long
        get() = lines.filter { it.kind == QuoteLineKind.DISCOUNT }.sumOf { -it.lineTotalCents }

    val taxCents: Long
        get() = Math.round(
            lines.filter { it.taxable && it.kind != QuoteLineKind.DISCOUNT }
                .sumOf { it.lineTotalCents } * (taxRatePercent / 100.0),
        )

    val totalCents: Long get() = subtotalCents + taxCents

    fun groupTotal(kind: QuoteLineKind): Long = lines.filter { it.kind == kind }.sumOf { it.lineTotalCents }
}

@Serializable
data class Client(
    val id: String = Ids.new("cli"),
    val name: String = "",
    val company: String = "",
    val phone: String = "",
    val email: String = "",
    val address: String = "",
    val notes: String = "",
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L,
    val syncState: SyncState = SyncState.PENDING,
    val version: Long = 1L,
    val deleted: Boolean = false,
)

@Serializable
data class Photo(
    val id: String = Ids.new("img"),
    val jobId: String = "",
    val kind: PhotoKind = PhotoKind.DETAIL,
    val fileName: String = "",
    val caption: String = "",
    val parentId: String? = null,
    val width: Int = 0,
    val height: Int = 0,
    val sizeBytes: Long = 0L,
    val sha256: String = "",
    val capturedAt: Long = 0L,
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L,
    val syncState: SyncState = SyncState.PENDING,
    val version: Long = 1L,
    val deleted: Boolean = false,
)

@Serializable
data class Signature(
    val id: String = Ids.new("sig"),
    val jobId: String = "",
    val signerName: String = "",
    val signerRole: String = "Customer",
    val fileName: String = "",
    val sha256: String = "",
    val acceptedTerms: Boolean = true,
    val termsVersion: String = "v1",
    val deviceModel: String = "",
    val signedAt: Long = 0L,
    val updatedAt: Long = 0L,
    val syncState: SyncState = SyncState.PENDING,
    val version: Long = 1L,
    val deleted: Boolean = false,
)

@Serializable
data class SyncOperation(
    val id: String = Ids.new("op"),
    val entityType: String = "",
    val entityId: String = "",
    val op: String = "upsert",
    val payload: String = "",
    val attempts: Int = 0,
    val nextAttemptAt: Long = 0L,
    val lastError: String = "",
    val createdAt: Long = 0L,
)

@Serializable
data class AnalyticsEvent(
    val id: String = Ids.new("evt"),
    val name: String = "",
    val params: Map<String, String> = emptyMap(),
    val at: Long = 0L,
    val uploaded: Boolean = false,
)

@Serializable
data class UserAccount(
    val id: String = Ids.new("usr"),
    val email: String = "",
    val displayName: String = "",
    val provider: AuthProvider = AuthProvider.EMAIL,
    val passwordHash: String = "",
    val passwordSalt: String = "",
    val businessName: String = "",
    val remoteVerified: Boolean = false,
    val createdAt: Long = 0L,
    val lastLoginAt: Long = 0L,
)

@Serializable
data class Session(
    val userId: String = "",
    val email: String = "",
    val displayName: String = "",
    val provider: AuthProvider = AuthProvider.EMAIL,
    val signedInAt: Long = 0L,
    val token: String = "",
    val offlineOnly: Boolean = false,
)

@Serializable
data class DeviceIdentity(
    val deviceId: String = Ids.new("dev"),
    val label: String = "",
    val createdAt: Long = 0L,
)
