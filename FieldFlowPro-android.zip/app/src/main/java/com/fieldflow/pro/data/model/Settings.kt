package com.fieldflow.pro.data.model

import com.fieldflow.pro.core.Ids
import kotlinx.serialization.Serializable

@Serializable
data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val gloveMode: Boolean = false,
    val businessName: String = "",
    val businessPhone: String = "",
    val businessEmail: String = "",
    val businessAddress: String = "",
    val licenceNumber: String = "",
    val logoFileName: String = "",
    val defaultTrade: Trade = Trade.HVAC,
    val currencyCode: String = "USD",
    val defaultTaxRatePercent: Double = 0.0,
    val defaultLabourRateCents: Long = 0L,
    val defaultQuoteTerms: String = DEFAULT_TERMS,
    val defaultValidDays: Int = 30,
    val pdfFooterNote: String = "",
    val autoSync: Boolean = true,
    val syncOnWifiOnly: Boolean = false,
    val analyticsOptIn: Boolean = true,
    val onboardingComplete: Boolean = false,
    val hapticsEnabled: Boolean = true,
    val autoLockMinutes: Int = 0,
    val lastSyncAt: Long = 0L,
    val lastSyncCursor: String = "",
    val lastSyncError: String = "",
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L,
    val version: Long = 1L,
) {

    val isBusinessProfileComplete: Boolean get() = businessName.isNotBlank()

    companion object {
        const val DEFAULT_TERMS =
            "Work described above is performed to trade standards. Materials remain the property of the " +
                "contractor until paid in full. Warranty covers workmanship for 12 months from completion. " +
                "Quoted price is valid for the period stated. Any additional work discovered on site will be " +
                "quoted separately and requires written approval before proceeding."

        const val TERMS_VERSION = "v1"
    }
}

@Serializable
data class TemplateLine(
    val kind: QuoteLineKind = QuoteLineKind.MATERIAL,
    val description: String = "",
    val detail: String = "",
    val quantity: Double = 1.0,
    val unit: String = "ea",
    val unitPriceCents: Long = 0L,
)

@Serializable
data class TradeTemplate(
    val id: String = Ids.new("tpl"),
    val trade: Trade = Trade.HVAC,
    val name: String = "",
    val summary: String = "",
    val defaultTitle: String = "",
    val defaultDescription: String = "",
    val labourHours: Double = 0.0,
    val lines: List<TemplateLine> = emptyList(),
    val checklist: List<String> = emptyList(),
)

@Serializable
data class SyncCursorState(
    val cursor: String = "",
    val lastSyncAt: Long = 0L,
    val lastPulledCount: Int = 0,
    val lastPushedCount: Int = 0,
)
