package com.fieldflow.pro.data.pdf

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.fieldflow.pro.core.AppError
import com.fieldflow.pro.core.AppLogger
import com.fieldflow.pro.core.AppResult
import com.fieldflow.pro.core.Dates
import com.fieldflow.pro.core.Money
import com.fieldflow.pro.data.model.AppSettings
import com.fieldflow.pro.data.model.Client
import com.fieldflow.pro.data.model.Job
import com.fieldflow.pro.data.model.Photo
import com.fieldflow.pro.data.model.PhotoKind
import com.fieldflow.pro.data.model.Quote
import com.fieldflow.pro.data.model.QuoteLineKind
import com.fieldflow.pro.data.model.Signature
import com.fieldflow.pro.data.photo.PhotoStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

class PacketExporter(
    context: Context,
    private val photoStore: PhotoStore,
    private val logger: AppLogger,
) {

    private val appContext: Context = context.applicationContext

    suspend fun buildPacket(
        job: Job,
        client: Client?,
        quote: Quote?,
        jobPhotos: List<Photo>,
        signature: Signature?,
        settings: AppSettings,
    ): AppResult<File> = withContext(Dispatchers.IO) {
        try {
            val bitmaps = LinkedHashMap<String, Bitmap>()
            jobPhotos.forEach { photo ->
                photoStore.loadBitmap(photo, 1400)?.let { bitmaps[photo.id] = it }
            }
            val signatureBitmap = signature?.let { photoStore.loadSignatureBitmap(it) }

            val brand = settings.businessName.ifBlank { "FieldFlow Pro" }
            val document = PdfDocument()
            val canvas = PageCanvas(document, brand)
            canvas.newPage()

            drawCover(canvas, job, client, signature, settings, jobPhotos, quote)
            drawScope(canvas, job)
            drawMaterials(canvas, job, settings)
            if (quote != null && quote.lines.isNotEmpty()) drawQuote(canvas, quote, settings)
            drawPhotos(canvas, jobPhotos.filter { it.kind != PhotoKind.MARKUP }, bitmaps)
            drawBeforeAfter(canvas, jobPhotos, bitmaps)
            drawSignaturePage(canvas, job, client, signature, signatureBitmap, settings)
            canvas.finish()

            val baseName = (job.number.ifBlank { job.id }).replace(Regex("[^A-Za-z0-9._-]"), "_")
            val target = File(photoStore.exportsDirectory, "$baseName-packet.pdf")
            target.outputStream().use { document.writeTo(it) }
            document.close()
            bitmaps.values.forEach { if (!it.isRecycled) it.recycle() }
            signatureBitmap?.let { if (!it.isRecycled) it.recycle() }
            logger.i(TAG, "Wrote packet ${target.name} (${target.length()} bytes)")
            AppResult.Success(target)
        } catch (t: Throwable) {
            logger.e(TAG, "Packet build failed", t)
            AppResult.Failure(AppError.Storage(t.message ?: "Could not build the PDF"))
        }
    }

    fun shareIntent(file: File, job: Job): Intent {
        val uri: Uri = FileProvider.getUriForFile(appContext, "${appContext.packageName}.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Job packet ${job.number} — ${job.title}")
            putExtra(Intent.EXTRA_TEXT, "Job packet for ${job.title} (${job.address})")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(send, "Share job packet")
    }

    fun openIntent(file: File): Intent {
        val uri: Uri = FileProvider.getUriForFile(appContext, "${appContext.packageName}.fileprovider", file)
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun drawCover(
        canvas: PageCanvas,
        job: Job,
        client: Client?,
        signature: Signature?,
        settings: AppSettings,
        jobPhotos: List<Photo>,
        quote: Quote?,
    ) {
        canvas.band(
            title = job.title.ifBlank { "Untitled job" },
            subtitle = "Job packet ${job.number.ifBlank { "" }}".trim(),
        )
        canvas.keyValues(
            listOf(
                "Status" to job.status.displayName,
                "Trade" to job.trade.displayName,
                "Priority" to job.priority.displayName,
                "Scheduled" to job.scheduledLabel,
                "Completed" to if (job.completedAt > 0) Dates.formatDate(job.completedAt) else "—",
                "Created" to if (job.createdAt > 0) Dates.formatDateTime(job.createdAt) else "—",
            ),
        )
        canvas.space(12f)
        canvas.sectionTitle("Customer and site")
        canvas.keyValues(
            listOf(
                "Name" to job.clientName.ifBlank { client?.name ?: "—" },
                "Company" to (client?.company ?: "—"),
                "Phone" to job.clientPhone.ifBlank { client?.phone ?: "—" },
                "Email" to (client?.email ?: "—"),
            ),
        )
        canvas.paragraph(job.address.ifBlank { client?.address ?: "No site address recorded" }, 11f, COL_INK)
        canvas.space(12f)
        canvas.sectionTitle("Value summary")
        canvas.keyValues(
            listOf(
                "Materials" to Money.format(job.materialsTotalCents, settings.currencyCode),
                "Labour" to "${trimNumber(job.labourHours)} hrs — ${Money.format(job.labourTotalCents, settings.currencyCode)}",
                "Discount" to Money.format(job.discountCents, settings.currencyCode),
                "Tax (${trimNumber(job.taxRatePercent)}%)" to Money.format(job.taxCents, settings.currencyCode),
            ),
        )
        canvas.totalBanner("JOB TOTAL", Money.format(job.totalCents, settings.currencyCode))
        canvas.space(10f)
        canvas.keyValues(
            listOf(
                "Photos attached" to jobPhotos.size.toString(),
                "Quote" to (quote?.let { "${it.number} (${it.status.displayName})" } ?: "No quote on file"),
                "Signature" to (signature?.let { "${it.signerName} — ${Dates.formatDateTime(it.signedAt)}" }
                    ?: "Not signed"),
            ),
        )
        if (settings.businessName.isNotBlank() || settings.businessPhone.isNotBlank()) {
            canvas.space(14f)
            canvas.hairline()
            canvas.paragraph(
                listOfNotNull(
                    settings.businessName.ifBlank { null },
                    settings.businessPhone.ifBlank { null },
                    settings.businessEmail.ifBlank { null },
                    settings.businessAddress.ifBlank { null },
                    settings.licenceNumber.ifBlank { null }?.let { "Licence $it" },
                ).joinToString("  •  "),
                9.5f,
                COL_MUTED,
            )
        }
    }

    private fun drawScope(canvas: PageCanvas, job: Job) {
        canvas.newPage()
        canvas.sectionTitle("Scope of work")
        canvas.paragraph(job.description.ifBlank { "No scope description recorded." }, 10.5f, COL_INK)
        if (job.checklist.isNotEmpty()) {
            canvas.space(12f)
            canvas.sectionTitle("Site checklist — ${job.checklist.count { it.done }}/${job.checklist.size} complete")
            job.checklist.forEach { item -> canvas.checkRow(item.done, item.label, item.note) }
        }
        val withSupplier = job.materials.filter { it.supplier.isNotBlank() }
        if (withSupplier.isNotEmpty()) {
            canvas.space(10f)
            canvas.sectionTitle("Suppliers used")
            withSupplier.forEach { canvas.bullet("${it.description} — ${it.supplier}") }
        }
    }

    private fun drawMaterials(canvas: PageCanvas, job: Job, settings: AppSettings) {
        canvas.newPage()
        canvas.sectionTitle("Materials and labour")
        val rows = mutableListOf<List<String>>()
        job.materials.forEach { line ->
            rows += listOf(
                line.description.ifBlank { "Material" } + if (line.supplier.isNotBlank()) "  (${line.supplier})" else "",
                "${trimNumber(line.quantity)} ${line.unit}",
                Money.format(line.unitPriceCents, settings.currencyCode),
                Money.format(line.lineTotalCents, settings.currencyCode),
            )
        }
        rows += listOf(
            "Labour — ${trimNumber(job.labourHours)} hrs",
            "",
            Money.format(job.labourRateCents, settings.currencyCode),
            Money.format(job.labourTotalCents, settings.currencyCode),
        )
        canvas.table(
            headers = listOf("Description", "Qty", "Rate", "Amount"),
            rows = rows,
            widths = listOf(0.46f, 0.16f, 0.19f, 0.19f),
            rightAlign = setOf(1, 2, 3),
        )
        canvas.space(12f)
        canvas.keyValues(
            listOf(
                "Subtotal" to Money.format(job.subtotalCents, settings.currencyCode),
                "Discount" to Money.format(job.discountCents, settings.currencyCode),
                "Taxable" to Money.format(job.taxableBaseCents, settings.currencyCode),
                "Tax (${trimNumber(job.taxRatePercent)}%)" to Money.format(job.taxCents, settings.currencyCode),
            ),
        )
        canvas.totalBanner("JOB TOTAL", Money.format(job.totalCents, settings.currencyCode))
    }

    private fun drawQuote(canvas: PageCanvas, quote: Quote, settings: AppSettings) {
        canvas.newPage()
        canvas.sectionTitle("Quote ${quote.number}")
        canvas.keyValues(
            listOf(
                "Status" to quote.status.displayName,
                "Issued" to if (quote.createdAt > 0) Dates.formatDate(quote.createdAt) else "—",
                "Valid until" to if (quote.validUntil > 0) Dates.formatDate(quote.validUntil) else "—",
            ),
        )
        canvas.space(10f)
        val rows = quote.lines.map { line ->
            val prefix = if (line.kind == QuoteLineKind.MATERIAL) "" else "[${line.kind.displayName}] "
            val description = prefix + line.description +
                if (line.detail.isNotBlank()) "\n${line.detail}" else ""
            listOf(
                description,
                "${trimNumber(line.quantity)} ${line.unit}",
                Money.format(line.unitPriceCents, settings.currencyCode),
                Money.format(line.lineTotalCents, settings.currencyCode),
            )
        }
        canvas.table(
            headers = listOf("Description", "Qty", "Rate", "Amount"),
            rows = rows,
            widths = listOf(0.46f, 0.16f, 0.19f, 0.19f),
            rightAlign = setOf(1, 2, 3),
        )
        canvas.space(12f)
        canvas.keyValues(
            listOf(
                "Labour" to Money.format(quote.groupTotal(QuoteLineKind.LABOUR), settings.currencyCode),
                "Materials" to Money.format(quote.groupTotal(QuoteLineKind.MATERIAL), settings.currencyCode),
                "Fees" to Money.format(quote.groupTotal(QuoteLineKind.FEE), settings.currencyCode),
                "Discounts" to Money.format(-quote.groupTotal(QuoteLineKind.DISCOUNT), settings.currencyCode),
                "Tax (${trimNumber(quote.taxRatePercent)}%)" to Money.format(quote.taxCents, settings.currencyCode),
            ),
        )
        canvas.totalBanner("QUOTE TOTAL", Money.format(quote.totalCents, settings.currencyCode))
        if (quote.notes.isNotBlank()) {
            canvas.space(12f)
            canvas.sectionTitle("Notes")
            canvas.paragraph(quote.notes, 10f, COL_INK)
        }
        val terms = quote.terms.ifBlank { settings.defaultQuoteTerms }
        if (terms.isNotBlank()) {
            canvas.space(10f)
            canvas.sectionTitle("Terms")
            canvas.paragraph(terms, 9.5f, COL_MUTED)
        }
    }

    private fun drawPhotos(canvas: PageCanvas, photosToDraw: List<Photo>, bitmaps: Map<String, Bitmap>) {
        if (photosToDraw.isEmpty()) return
        canvas.newPage()
        canvas.sectionTitle("Site photos (${photosToDraw.size})")
        canvas.photoGrid(
            items = photosToDraw.map { photo ->
                PhotoCell(
                    bitmap = bitmaps[photo.id],
                    caption = photo.kind.displayName + if (photo.caption.isNotBlank()) " — ${photo.caption}" else "",
                )
            },
        )
    }

    private fun drawBeforeAfter(canvas: PageCanvas, jobPhotos: List<Photo>, bitmaps: Map<String, Bitmap>) {
        val before = jobPhotos.filter { it.kind == PhotoKind.BEFORE }
        val after = jobPhotos.filter { it.kind == PhotoKind.AFTER }
        if (before.isEmpty() || after.isEmpty()) return
        val pairs = minOf(before.size, after.size)
        for (index in 0 until pairs) {
            canvas.newPage()
            canvas.sectionTitle("Before / after — pair ${index + 1} of $pairs")
            canvas.space(4f)
            canvas.sideBySide(
                left = bitmaps[before[index].id],
                right = bitmaps[after[index].id],
                leftLabel = "BEFORE",
                rightLabel = "AFTER",
            )
            canvas.space(10f)
            canvas.paragraph(
                "Before: ${before[index].caption.ifBlank { before[index].kind.displayName }}  •  " +
                    "After: ${after[index].caption.ifBlank { after[index].kind.displayName }}",
                9.5f,
                COL_MUTED,
            )
        }
    }

    private fun drawSignaturePage(
        canvas: PageCanvas,
        job: Job,
        client: Client?,
        signature: Signature?,
        signatureBitmap: Bitmap?,
        settings: AppSettings,
    ) {
        canvas.newPage()
        canvas.sectionTitle("Acceptance and signature")
        canvas.paragraph(
            "The customer confirms the work described in this packet has been reviewed, completed to " +
                "satisfaction, and accepted.",
            10.5f,
            COL_INK,
        )
        canvas.space(10f)
        if (signature == null) {
            canvas.paragraph("No signature captured for this job yet.", 10.5f, COL_WARN)
        } else {
            if (signatureBitmap != null) {
                canvas.imageBlock(signatureBitmap, height = 140f, label = "Customer signature")
            } else {
                canvas.paragraph("Signature image unavailable on this device.", 10f, COL_WARN)
            }
            canvas.space(8f)
            canvas.keyValues(
                listOf(
                    "Signed by" to signature.signerName,
                    "Role" to signature.signerRole,
                    "Signed at" to Dates.formatDateTime(signature.signedAt),
                    "Device" to signature.deviceModel,
                    "Terms accepted" to if (signature.acceptedTerms) signature.termsVersion else "No",
                    "Signature hash" to signature.sha256.take(32).ifBlank { "—" },
                ),
            )
        }
        canvas.space(16f)
        canvas.hairline()
        canvas.space(12f)
        val customer = job.clientName.ifBlank { client?.name.orEmpty() }
        if (customer.isNotBlank()) canvas.paragraph("Customer: $customer", 10.5f, COL_INK)
        if (settings.businessName.isNotBlank()) canvas.paragraph("Contractor: ${settings.businessName}", 10.5f, COL_INK)
        if (settings.defaultQuoteTerms.isNotBlank()) {
            canvas.space(12f)
            canvas.sectionTitle("Terms and conditions")
            canvas.paragraph(settings.defaultQuoteTerms, 9f, COL_MUTED)
        }
        if (settings.pdfFooterNote.isNotBlank()) {
            canvas.space(10f)
            canvas.paragraph(settings.pdfFooterNote, 9f, COL_MUTED)
        }
        canvas.space(14f)
        canvas.paragraph(
            "Generated ${Dates.formatDateTime(System.currentTimeMillis())} by FieldFlow Pro",
            8.5f,
            COL_MUTED,
        )
    }

    private fun trimNumber(value: Double): String =
        if (value % 1.0 == 0.0) {
            value.toInt().toString()
        } else {
            String.format(Locale.US, "%.2f", value).trimEnd('0').trimEnd('.')
        }

    private companion object {
        const val TAG = "PacketExporter"
        const val COL_INK = 0xFF16202E.toInt()
        const val COL_MUTED = 0xFF6B7280.toInt()
        const val COL_WARN = 0xFFB45309.toInt()
        const val COL_ACCENT = 0xFFEA580C.toInt()
    }
}

internal data class PhotoCell(val bitmap: Bitmap?, val caption: String)

internal class PageCanvas(
    private val document: PdfDocument,
    private val brand: String,
) {

    private var page: PdfDocument.Page? = null
    private var canvas: Canvas? = null
    private var pageNumber = 0
    private var y: Float = MARGIN

    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = COL_INK
        textSize = 10.5f
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    val contentWidth: Float get() = PAGE_W - 2 * MARGIN

    fun newPage() {
        finishCurrent()
        pageNumber++
        val info = PdfDocument.PageInfo.Builder(PAGE_W.toInt(), PAGE_H.toInt(), pageNumber).create()
        val started = document.startPage(info)
        page = started
        canvas = started.canvas
        y = MARGIN
        drawFooterLine()
    }

    fun finish() {
        finishCurrent()
    }

    private fun finishCurrent() {
        val current = page ?: return
        drawFooterText(current.canvas)
        document.finishPage(current)
        page = null
        canvas = null
    }

    private fun requireCanvas(): Canvas = canvas ?: error("No active page — call newPage() first")

    fun space(height: Float) {
        y += height
    }

    fun ensure(height: Float) {
        if (y + height > PAGE_H - FOOTER_SPACE) newPage()
    }

    fun hairline() {
        val c = requireCanvas()
        fillPaint.color = COL_RULE
        c.drawRect(MARGIN, y, PAGE_W - MARGIN, y + 0.8f, fillPaint)
        y += 0.8f
    }

    fun band(title: String, subtitle: String) {
        val c = requireCanvas()
        fillPaint.color = COL_BAND
        c.drawRect(0f, 0f, PAGE_W, 108f, fillPaint)
        fillPaint.color = COL_ACCENT
        c.drawRect(0f, 108f, PAGE_W, 112f, fillPaint)
        textPaint.color = Color.WHITE
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.textSize = 10f
        c.drawText(brand.uppercase(Locale.US), MARGIN, 34f, textPaint)
        textPaint.textSize = 20f
        drawClipped(c, title, MARGIN, 66f, contentWidth)
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        textPaint.textSize = 10.5f
        textPaint.color = 0xFFCBD5E1.toInt()
        c.drawText(subtitle, MARGIN, 88f, textPaint)
        y = 130f
        textPaint.color = COL_INK
    }

    fun sectionTitle(title: String) {
        ensure(34f)
        val c = requireCanvas()
        fillPaint.color = COL_ACCENT
        c.drawRect(MARGIN, y + 1f, MARGIN + 3f, y + 15f, fillPaint)
        textPaint.color = COL_INK
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textPaint.textSize = 12.5f
        c.drawText(title, MARGIN + 10f, y + 12f, textPaint)
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        y += 22f
    }

    fun text(value: String, size: Float, color: Int, bold: Boolean = false, rightAligned: Boolean = false) {
        ensure(size + 6f)
        val c = requireCanvas()
        textPaint.color = color
        textPaint.textSize = size
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
        val x = if (rightAligned) PAGE_W - MARGIN - textPaint.measureText(value) else MARGIN
        c.drawText(value, x, y + size, textPaint)
        y += size * 1.35f
    }

    fun paragraph(value: String, size: Float, color: Int, indent: Float = 0f) {
        val lines = wrap(value, size, contentWidth - indent)
        lines.forEach { line ->
            ensure(size * 1.4f)
            val c = requireCanvas()
            textPaint.color = color
            textPaint.textSize = size
            textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            c.drawText(line, MARGIN + indent, y + size, textPaint)
            y += size * 1.4f
        }
    }

    fun bullet(value: String) {
        val lines = wrap(value, 10f, contentWidth - 14f)
        lines.forEachIndexed { index, line ->
            ensure(14f)
            val c = requireCanvas()
            textPaint.color = COL_INK
            textPaint.textSize = 10f
            textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            if (index == 0) {
                fillPaint.color = COL_ACCENT
                c.drawCircle(MARGIN + 3f, y + 5f, 2.2f, fillPaint)
            }
            c.drawText(line, MARGIN + 14f, y + 10f, textPaint)
            y += 14f
        }
    }

    fun checkRow(done: Boolean, label: String, note: String) {
        ensure(18f)
        val c = requireCanvas()
        val box = RectF(MARGIN, y + 1f, MARGIN + 10f, y + 11f)
        fillPaint.color = if (done) COL_OK else Color.TRANSPARENT
        fillPaint.style = Paint.Style.FILL
        c.drawRect(box, fillPaint)
        fillPaint.style = Paint.Style.STROKE
        fillPaint.strokeWidth = 0.9f
        fillPaint.color = if (done) COL_OK else 0xFF9CA3AF.toInt()
        c.drawRect(box, fillPaint)
        fillPaint.style = Paint.Style.FILL
        if (done) {
            fillPaint.color = Color.WHITE
            fillPaint.strokeWidth = 1.4f
            fillPaint.style = Paint.Style.STROKE
            c.drawLine(box.left + 2f, box.centerY(), box.centerX(), box.bottom - 2f, fillPaint)
            c.drawLine(box.centerX(), box.bottom - 2f, box.right - 1.6f, box.top + 2f, fillPaint)
            fillPaint.style = Paint.Style.FILL
        }
        textPaint.color = COL_INK
        textPaint.textSize = 10f
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        val suffix = if (note.isNotBlank()) "  ($note)" else ""
        c.drawText(label + suffix, MARGIN + 18f, y + 10f, textPaint)
        y += 17f
    }

    fun keyValues(pairs: List<Pair<String, String>>) {
        val columnWidth = contentWidth / 2f
        var index = 0
        while (index < pairs.size) {
            ensure(30f)
            val c = requireCanvas()
            drawKeyValue(c, pairs[index], MARGIN, columnWidth - 8f)
            pairs.getOrNull(index + 1)?.let { drawKeyValue(c, it, MARGIN + columnWidth, columnWidth - 8f) }
            y += 30f
            index += 2
        }
    }

    private fun drawKeyValue(c: Canvas, pair: Pair<String, String>, x: Float, width: Float) {
        textPaint.color = COL_MUTED
        textPaint.textSize = 8.5f
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        c.drawText(pair.first.uppercase(Locale.US), x, y + 9f, textPaint)
        textPaint.color = COL_INK
        textPaint.textSize = 11f
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        val wrapped = wrap(pair.second.ifBlank { "—" }, 11f, width)
        wrapped.take(2).forEachIndexed { lineIndex, line ->
            c.drawText(line, x, y + 23f + lineIndex * 12f, textPaint)
        }
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
    }

    fun table(
        headers: List<String>,
        rows: List<List<String>>,
        widths: List<Float>,
        rightAlign: Set<Int>,
    ) {
        ensure(40f)
        val c = requireCanvas()
        fillPaint.color = COL_TABLE_HEAD
        c.drawRect(MARGIN, y, PAGE_W - MARGIN, y + 20f, fillPaint)
        textPaint.color = Color.WHITE
        textPaint.textSize = 9.5f
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        var x = MARGIN + 6f
        headers.forEachIndexed { index, header ->
            val columnWidth = contentWidth * widths[index] - 12f
            val drawX = if (index in rightAlign) x + columnWidth - textPaint.measureText(header) else x
            c.drawText(header, drawX, y + 13.5f, textPaint)
            x += contentWidth * widths[index]
        }
        y += 20f

        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        textPaint.textSize = 9.5f
        rows.forEachIndexed { rowIndex, row ->
            val wrappedCells = row.mapIndexed { index, cell -> wrap(cell, 9.5f, contentWidth * widths[index] - 12f) }
            val lineCount = wrappedCells.maxOf { it.size }.coerceAtLeast(1)
            val rowHeight = lineCount * 12f + 8f
            ensure(rowHeight + 4f)
            val canvasNow = requireCanvas()
            if (rowIndex % 2 == 1) {
                fillPaint.color = COL_TABLE_ALT
                canvasNow.drawRect(MARGIN, y, PAGE_W - MARGIN, y + rowHeight, fillPaint)
            }
            var cellX = MARGIN + 6f
            wrappedCells.forEachIndexed { index, lines ->
                val columnWidth = contentWidth * widths[index] - 12f
                textPaint.color = COL_INK
                lines.forEachIndexed { lineIndex, line ->
                    val drawX = if (index in rightAlign) {
                        cellX + columnWidth - textPaint.measureText(line)
                    } else {
                        cellX
                    }
                    canvasNow.drawText(line, drawX, y + 12f + lineIndex * 12f, textPaint)
                }
                cellX += contentWidth * widths[index]
            }
            y += rowHeight
        }
        fillPaint.color = COL_RULE
        requireCanvas().drawRect(MARGIN, y, PAGE_W - MARGIN, y + 0.8f, fillPaint)
        y += 4f
    }

    fun totalBanner(label: String, amount: String) {
        ensure(40f)
        val c = requireCanvas()
        fillPaint.color = COL_BAND
        c.drawRoundRect(RectF(MARGIN, y, PAGE_W - MARGIN, y + 32f), 4f, 4f, fillPaint)
        textPaint.color = Color.WHITE
        textPaint.textSize = 10.5f
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        c.drawText(label, MARGIN + 12f, y + 21f, textPaint)
        textPaint.textSize = 15f
        c.drawText(amount, PAGE_W - MARGIN - 12f - textPaint.measureText(amount), y + 22f, textPaint)
        y += 40f
    }

    fun imageBlock(bitmap: Bitmap, height: Float, label: String = "") {
        ensure(height + 34f)
        val c = requireCanvas()
        val boxWidth = contentWidth
        val box = RectF(MARGIN, y, MARGIN + boxWidth, y + height)
        fillPaint.color = COL_TABLE_ALT
        c.drawRect(box, fillPaint)
        val fitted = fit(bitmap, boxWidth - 10f, height - 10f, box)
        fillPaint.color = Color.WHITE
        c.drawRect(fitted, fillPaint)
        c.drawBitmap(bitmap, null, fitted, Paint(Paint.FILTER_BITMAP_FLAG))
        y += height + 6f
        if (label.isNotBlank()) {
            textPaint.color = COL_MUTED
            textPaint.textSize = 8.5f
            textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            c.drawText(label, MARGIN, y + 8f, textPaint)
            y += 12f
        }
        y += 6f
    }

    fun photoGrid(items: List<PhotoCell>) {
        val columns = 2
        val gap = 12f
        val cellWidth = (contentWidth - gap) / columns
        val cellHeight = cellWidth * 0.72f
        var index = 0
        while (index < items.size) {
            ensure(cellHeight + 34f)
            val rowTop = y
            val inRow = minOf(columns, items.size - index)
            for (column in 0 until inRow) {
                val item = items[index + column]
                val left = MARGIN + column * (cellWidth + gap)
                val box = RectF(left, rowTop, left + cellWidth, rowTop + cellHeight)
                val c = requireCanvas()
                fillPaint.color = COL_TABLE_ALT
                c.drawRect(box, fillPaint)
                val bitmap = item.bitmap
                if (bitmap != null && !bitmap.isRecycled) {
                    c.drawBitmap(bitmap, null, fit(bitmap, box.width() - 6f, box.height() - 6f, box), Paint(Paint.FILTER_BITMAP_FLAG))
                } else {
                    textPaint.color = COL_MUTED
                    textPaint.textSize = 9f
                    textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
                    c.drawText("image unavailable", box.left + 10f, box.centerY(), textPaint)
                }
                textPaint.color = COL_MUTED
                textPaint.textSize = 8.5f
                textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
                val caption = wrap(item.caption.ifBlank { "Photo" }, 8.5f, cellWidth - 4f).firstOrNull().orEmpty()
                c.drawText(caption, box.left, box.bottom + 11f, textPaint)
            }
            y = rowTop + cellHeight + 26f
            index += columns
        }
    }

    fun sideBySide(left: Bitmap?, right: Bitmap?, leftLabel: String, rightLabel: String) {
        val gap = 14f
        val cellWidth = (contentWidth - gap) / 2f
        val cellHeight = 320f
        ensure(cellHeight + 40f)
        val c = requireCanvas()
        val leftBox = RectF(MARGIN, y, MARGIN + cellWidth, y + cellHeight)
        val rightBox = RectF(MARGIN + cellWidth + gap, y, MARGIN + cellWidth * 2 + gap, y + cellHeight)
        listOf(leftBox, rightBox).forEach { box ->
            fillPaint.color = COL_TABLE_ALT
            c.drawRect(box, fillPaint)
        }
        left?.let { c.drawBitmap(it, null, fit(it, leftBox.width() - 6f, leftBox.height() - 6f, leftBox), Paint(Paint.FILTER_BITMAP_FLAG)) }
        right?.let { c.drawBitmap(it, null, fit(it, rightBox.width() - 6f, rightBox.height() - 6f, rightBox), Paint(Paint.FILTER_BITMAP_FLAG)) }
        textPaint.color = COL_ACCENT
        textPaint.textSize = 10f
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        c.drawText(leftLabel, leftBox.left + 6f, leftBox.top + 14f, textPaint)
        c.drawText(rightLabel, rightBox.left + 6f, rightBox.top + 14f, textPaint)
        y += cellHeight + 14f
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
    }

    private fun drawFooterLine() {
        val c = requireCanvas()
        fillPaint.color = COL_RULE
        c.drawRect(MARGIN, PAGE_H - FOOTER_SPACE + 18f, PAGE_W - MARGIN, PAGE_H - FOOTER_SPACE + 18.8f, fillPaint)
    }

    private fun drawFooterText(c: Canvas) {
        textPaint.color = COL_MUTED
        textPaint.textSize = 8.5f
        textPaint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        c.drawText(brand, MARGIN, PAGE_H - 26f, textPaint)
        val label = "Page $pageNumber"
        c.drawText(label, PAGE_W - MARGIN - textPaint.measureText(label), PAGE_H - 26f, textPaint)
    }

    private fun drawClipped(c: Canvas, value: String, x: Float, baseline: Float, maxWidth: Float) {
        var text = value
        while (textPaint.measureText(text) > maxWidth && text.length > 4) {
            text = text.dropLast(2)
        }
        if (text != value) text = text.dropLast(1) + "…"
        c.drawText(text, x, baseline, textPaint)
    }

    private fun wrap(value: String, size: Float, maxWidth: Float): List<String> {
        textPaint.textSize = size
        if (value.isBlank()) return emptyList()
        val result = mutableListOf<String>()
        value.split("\n").forEach { hardLine ->
            var current = StringBuilder()
            hardLine.split(" ").forEach { word ->
                val candidate = if (current.isEmpty()) word else "$current $word"
                if (textPaint.measureText(candidate) <= maxWidth) {
                    current = StringBuilder(candidate)
                } else {
                    if (current.isNotEmpty()) result += current.toString()
                    current = StringBuilder(word)
                }
            }
            if (current.isNotEmpty()) result += current.toString()
        }
        return result
    }

    private fun fit(bitmap: Bitmap, maxWidth: Float, maxHeight: Float, box: RectF): RectF {
        val scale = minOf(maxWidth / bitmap.width, maxHeight / bitmap.height)
        val width = bitmap.width * scale
        val height = bitmap.height * scale
        val left = box.left + (box.width() - width) / 2f
        val top = box.top + (box.height() - height) / 2f
        return RectF(left, top, left + width, top + height)
    }

    private companion object {
        const val PAGE_W = 595f
        const val PAGE_H = 842f
        const val MARGIN = 44f
        const val FOOTER_SPACE = 60f
        const val COL_INK = 0xFF16202E.toInt()
        const val COL_MUTED = 0xFF6B7280.toInt()
        const val COL_WARN = 0xFFB45309.toInt()
        const val COL_ACCENT = 0xFFEA580C.toInt()
        const val COL_BAND = 0xFF0F172A.toInt()
        const val COL_RULE = 0xFFD7DCE5.toInt()
        const val COL_OK = 0xFF16A34A.toInt()
        const val COL_TABLE_HEAD = 0xFF334155.toInt()
        const val COL_TABLE_ALT = 0xFFF1F5F9.toInt()
    }
}
