package com.fieldflow.pro.data.photo

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.os.Build
import androidx.exifinterface.media.ExifInterface
import com.fieldflow.pro.core.AppLogger
import com.fieldflow.pro.core.CryptoBox
import com.fieldflow.pro.core.Ids
import com.fieldflow.pro.data.model.Photo
import com.fieldflow.pro.data.model.PhotoKind
import com.fieldflow.pro.data.model.Signature
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File

class PhotoStore(
    context: Context,
    private val crypto: CryptoBox,
    private val logger: AppLogger,
) {

    private val photoVault = File(context.filesDir, "photos").apply { mkdirs() }
    private val signatureVault = File(context.filesDir, "signatures").apply { mkdirs() }
    private val exportDir = File(context.filesDir, "exports").apply { mkdirs() }
    private val previewCache = File(context.cacheDir, "previews").apply { mkdirs() }
    private val thumbnailCache = File(previewCache, "thumbs").apply { mkdirs() }
    private val cameraTemp = File(context.cacheDir, "camera").apply { mkdirs() }

    val exportsDirectory: File get() = exportDir

    fun newCaptureFile(): File = File(cameraTemp, "capture_${System.currentTimeMillis()}.jpg")

    suspend fun importPhoto(
        source: File,
        jobId: String,
        kind: PhotoKind,
        caption: String = "",
        parentId: String? = null,
    ): Photo = withContext(Dispatchers.IO) {
        val normalized = normalizeExif(source)
        val bytes = normalized.readBytes()
        val sha = crypto.sha256Hex(bytes)
        val fileName = "${Ids.new("p")}.enc"
        val payload = crypto.encrypt(bytes)
        File(photoVault, fileName).writeBytes(payload)
        val bounds = decodeBounds(bytes)
        if (normalized != source && source.parentFile?.name == cameraTemp.name) source.delete()
        normalized.delete()
        val now = System.currentTimeMillis()
        Photo(
            jobId = jobId,
            kind = kind,
            fileName = fileName,
            caption = caption,
            parentId = parentId,
            width = bounds.first,
            height = bounds.second,
            sizeBytes = payload.size.toLong(),
            sha256 = sha,
            capturedAt = now,
            createdAt = now,
            updatedAt = now,
        )
    }

    suspend fun importBitmap(
        bitmap: Bitmap,
        jobId: String,
        kind: PhotoKind,
        caption: String = "",
        parentId: String? = null,
    ): Photo = withContext(Dispatchers.IO) {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 92, stream)
        val bytes = stream.toByteArray()
        val sha = crypto.sha256Hex(bytes)
        val fileName = "${Ids.new("p")}.enc"
        val payload = crypto.encrypt(bytes)
        File(photoVault, fileName).writeBytes(payload)
        val now = System.currentTimeMillis()
        Photo(
            jobId = jobId,
            kind = kind,
            fileName = fileName,
            caption = caption,
            parentId = parentId,
            width = bitmap.width,
            height = bitmap.height,
            sizeBytes = payload.size.toLong(),
            sha256 = sha,
            capturedAt = now,
            createdAt = now,
            updatedAt = now,
        )
    }

    suspend fun saveSignature(
        bitmap: Bitmap,
        jobId: String,
        signerName: String,
        signerRole: String,
        termsVersion: String,
        acceptedTerms: Boolean,
    ): Signature = withContext(Dispatchers.IO) {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        val bytes = stream.toByteArray()
        val sha = crypto.sha256Hex(bytes)
        val fileName = "${Ids.new("sig")}.enc"
        File(signatureVault, fileName).writeBytes(crypto.encrypt(bytes))
        val now = System.currentTimeMillis()
        Signature(
            jobId = jobId,
            signerName = signerName,
            signerRole = signerRole,
            fileName = fileName,
            sha256 = sha,
            acceptedTerms = acceptedTerms,
            termsVersion = termsVersion,
            deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}".trim(),
            signedAt = now,
            updatedAt = now,
        )
    }

    suspend fun displayFile(photo: Photo): File? = withContext(Dispatchers.IO) {
        if (photo.fileName.isBlank()) return@withContext null
        val target = File(previewCache, "${photo.id}.jpg")
        val source = File(photoVault, photo.fileName)
        if (!source.exists()) {
            logger.w(TAG, "Vault file missing for ${photo.id}")
            return@withContext null
        }
        if (target.exists() && target.length() > 0) return@withContext target
        runCatching { crypto.decryptToFile(source, target) }
            .onFailure { logger.e(TAG, "Could not decrypt ${photo.id}", it) }
            .getOrNull()
        if (target.exists()) target else null
    }

    suspend fun thumbnailFile(photo: Photo, maxPx: Int = 480): File? = withContext(Dispatchers.IO) {
        val target = File(thumbnailCache, "${photo.id}_$maxPx.jpg")
        if (target.exists() && target.length() > 0) return@withContext target
        val full = displayFile(photo) ?: return@withContext null
        val bitmap = decodeScaled(full, maxPx) ?: return@withContext null
        target.outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 82, it) }
        bitmap.recycle()
        if (target.exists()) target else null
    }

    suspend fun loadBitmap(photo: Photo, maxPx: Int = 1600): Bitmap? = withContext(Dispatchers.IO) {
        val file = displayFile(photo) ?: return@withContext null
        decodeScaled(file, maxPx)
    }

    suspend fun loadSignatureBitmap(signature: Signature): Bitmap? = withContext(Dispatchers.IO) {
        if (signature.fileName.isBlank()) return@withContext null
        val target = File(previewCache, "${signature.id}.png")
        val source = File(signatureVault, signature.fileName)
        if (!source.exists()) return@withContext null
        if (!target.exists()) {
            runCatching { crypto.decryptToFile(source, target) }
                .onFailure { logger.e(TAG, "Signature decrypt failed", it) }
        }
        if (target.exists()) BitmapFactory.decodeFile(target.absolutePath) else null
    }

    suspend fun exportPlainPhoto(photo: Photo, target: File): File? = withContext(Dispatchers.IO) {
        val file = displayFile(photo) ?: return@withContext null
        target.parentFile?.mkdirs()
        runCatching { file.copyTo(target, overwrite = true) }.getOrNull()
    }

    suspend fun deletePhotoFile(photo: Photo) = withContext(Dispatchers.IO) {
        File(photoVault, photo.fileName).delete()
        File(previewCache, "${photo.id}.jpg").delete()
        File(thumbnailCache, "${photo.id}_480.jpg").delete()
        Unit
    }

    suspend fun deleteSignatureFile(signature: Signature) = withContext(Dispatchers.IO) {
        File(signatureVault, signature.fileName).delete()
        File(previewCache, "${signature.id}.png").delete()
        Unit
    }

    fun vaultBytes(): Long =
        (photoVault.listFiles()?.sumOf { it.length() } ?: 0L) +
            (signatureVault.listFiles()?.sumOf { it.length() } ?: 0L)

    fun clearPreviews(): Int {
        var removed = 0
        previewCache.listFiles()?.forEach { file ->
            if (file.isDirectory) {
                file.listFiles()?.forEach { child -> if (child.delete()) removed++ }
            } else if (file.delete()) {
                removed++
            }
        }
        return removed
    }

    fun wipeAll() {
        photoVault.listFiles()?.forEach { it.delete() }
        signatureVault.listFiles()?.forEach { it.delete() }
        exportDir.listFiles()?.forEach { it.delete() }
        clearPreviews()
    }

    private fun normalizeExif(source: File): File {
        val orientation = runCatching {
            ExifInterface(source.absolutePath).getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL,
            )
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
        if (orientation == ExifInterface.ORIENTATION_NORMAL) return source
        val bitmap = BitmapFactory.decodeFile(source.absolutePath) ?: return source
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
            else -> return source
        }
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        val target = File(cameraTemp, "norm_${source.name}")
        target.outputStream().use { rotated.compress(Bitmap.CompressFormat.JPEG, 94, it) }
        bitmap.recycle()
        if (rotated != bitmap) rotated.recycle()
        return target
    }

    private fun decodeBounds(bytes: ByteArray): Pair<Int, Int> {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
        return options.outWidth to options.outHeight
    }

    private fun decodeScaled(file: File, maxPx: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > maxPx * 2) sample *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = BitmapFactory.decodeFile(file.absolutePath, options) ?: return null
        val longest = maxOf(decoded.width, decoded.height)
        if (longest <= maxPx) return decoded
        val scale = maxPx.toFloat() / longest
        val scaled = Bitmap.createScaledBitmap(decoded, (decoded.width * scale).toInt(), (decoded.height * scale).toInt(), true)
        if (scaled != decoded) decoded.recycle()
        return scaled
    }

    private companion object {
        const val TAG = "PhotoStore"
    }
}
