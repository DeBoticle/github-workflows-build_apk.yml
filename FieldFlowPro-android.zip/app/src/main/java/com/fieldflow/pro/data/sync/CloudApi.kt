package com.fieldflow.pro.data.sync

import android.content.Context
import com.fieldflow.pro.core.AppError
import com.fieldflow.pro.core.AppLogger
import com.fieldflow.pro.core.AppResult
import com.fieldflow.pro.core.map
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.DataOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

@Serializable
data class ChangeRecord(
    val entityType: String = "",
    val entityId: String = "",
    val op: String = "upsert",
    val payload: String = "",
    val updatedAt: Long = 0L,
    val version: Long = 1L,
)

@Serializable
data class PushRequest(
    val deviceId: String = "",
    val cursor: String = "",
    val changes: List<ChangeRecord> = emptyList(),
)

@Serializable
data class PushResponse(
    val accepted: List<String> = emptyList(),
    val rejected: List<String> = emptyList(),
    val cursor: String = "",
    val serverTime: Long = 0L,
)

@Serializable
data class PullResponse(
    val changes: List<ChangeRecord> = emptyList(),
    val cursor: String = "",
    val hasMore: Boolean = false,
    val serverTime: Long = 0L,
)

interface CloudApi {
    val isConfigured: Boolean
    val modeLabel: String
    suspend fun push(request: PushRequest): AppResult<PushResponse>
    suspend fun pull(cursor: String): AppResult<PullResponse>
}

@Serializable
private data class MirrorRecord(
    val key: String = "",
    val entityType: String = "",
    val entityId: String = "",
    val op: String = "upsert",
    val payload: String = "",
    val updatedAt: Long = 0L,
    val version: Long = 1L,
    val seq: Long = 0L,
)

@Serializable
private data class MirrorDb(val records: MutableList<MirrorRecord> = mutableListOf(), var seq: Long = 0L)

class LocalMirrorApi(
    context: Context,
    private val json: Json,
    private val logger: AppLogger,
) : CloudApi {

    private val mutex = Mutex()
    private val file = File(File(context.filesDir, "mirror").apply { mkdirs() }, "records.json")

    override val isConfigured: Boolean = true
    override val modeLabel: String = "On-device sync mirror (demo)"

    private fun load(): MirrorDb {
        if (!file.exists()) return MirrorDb()
        return runCatching { json.decodeFromString(MirrorDb.serializer(), file.readText()) }
            .getOrElse {
                logger.w(TAG, "Mirror reset", it)
                MirrorDb()
            }
    }

    private fun save(db: MirrorDb) = file.writeText(json.encodeToString(MirrorDb.serializer(), db))

    override suspend fun push(request: PushRequest): AppResult<PushResponse> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val db = load()
            val accepted = mutableListOf<String>()
            val rejected = mutableListOf<String>()
            request.changes.forEach { change ->
                val key = "${change.entityType}:${change.entityId}"
                val existing = db.records.firstOrNull { it.key == key }
                if (existing != null && existing.updatedAt > change.updatedAt) {
                    rejected += key
                } else {
                    db.seq += 1
                    val record = MirrorRecord(
                        key = key,
                        entityType = change.entityType,
                        entityId = change.entityId,
                        op = change.op,
                        payload = change.payload,
                        updatedAt = change.updatedAt,
                        version = change.version,
                        seq = db.seq,
                    )
                    if (existing != null) {
                        db.records[db.records.indexOf(existing)] = record
                    } else {
                        db.records += record
                    }
                    accepted += key
                }
            }
            save(db)
            AppResult.Success(
                PushResponse(
                    accepted = accepted,
                    rejected = rejected,
                    cursor = db.seq.toString(),
                    serverTime = System.currentTimeMillis(),
                ),
            )
        }
    }

    override suspend fun pull(cursor: String): AppResult<PullResponse> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val db = load()
            val from = cursor.toLongOrNull() ?: 0L
            val changes = db.records.filter { it.seq > from }.sortedBy { it.seq }.map {
                ChangeRecord(
                    entityType = it.entityType,
                    entityId = it.entityId,
                    op = it.op,
                    payload = it.payload,
                    updatedAt = it.updatedAt,
                    version = it.version,
                )
            }
            AppResult.Success(
                PullResponse(
                    changes = changes,
                    cursor = db.seq.toString(),
                    hasMore = false,
                    serverTime = System.currentTimeMillis(),
                ),
            )
        }
    }

    private companion object {
        const val TAG = "LocalMirrorApi"
    }
}

class HttpCloudApi(
    private val baseUrl: String,
    private val apiKey: String,
    private val json: Json,
    private val logger: AppLogger,
) : CloudApi {

    override val isConfigured: Boolean = baseUrl.isNotBlank()
    override val modeLabel: String = "Cloud: ${baseUrl.trimEnd('/')}"

    override suspend fun push(request: PushRequest): AppResult<PushResponse> = withContext(Dispatchers.IO) {
        post("/v1/sync/push", json.encodeToString(PushRequest.serializer(), request))
            .map { body -> json.decodeFromString(PushResponse.serializer(), body) }
    }

    override suspend fun pull(cursor: String): AppResult<PullResponse> = withContext(Dispatchers.IO) {
        get("/v1/sync/pull?cursor=" + URLEncoder.encode(cursor, "UTF-8") + "&limit=200")
            .map { body -> json.decodeFromString(PullResponse.serializer(), body) }
    }

    private fun get(path: String): AppResult<String> = request("GET", path, null)

    private fun post(path: String, body: String): AppResult<String> = request("POST", path, body)

    private fun request(method: String, path: String, body: String?): AppResult<String> {
        val url = baseUrl.trimEnd('/') + path
        return try {
            val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = 15_000
                readTimeout = 25_000
                setRequestProperty("Accept", "application/json")
                if (apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer $apiKey")
                if (body != null) {
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
            }
            if (body != null) {
                DataOutputStream(connection.outputStream).use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = connection.responseCode
            val text = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            connection.disconnect()
            when {
                code in 200..299 -> AppResult.Success(text)
                code == 401 || code == 403 -> AppResult.Failure(AppError.Auth("Sync server rejected the API key (HTTP $code)."))
                code == 429 -> AppResult.Failure(AppError.Network("Sync server is throttling requests. Try again shortly."))
                code >= 500 -> AppResult.Failure(AppError.Network("Sync server error (HTTP $code)."))
                else -> AppResult.Failure(AppError.Network("Sync failed (HTTP $code). ${text.take(120)}"))
            }
        } catch (t: java.io.IOException) {
            logger.w(TAG, "Network failure talking to $url", t)
            AppResult.Failure(AppError.Network("No connection to the sync server.", retryable = true))
        } catch (t: Throwable) {
            logger.e(TAG, "Unexpected sync failure", t)
            AppResult.Failure(AppError.Unknown(t.message ?: "Sync failed."))
        }
    }

    private companion object {
        const val TAG = "HttpCloudApi"
    }
}

object SyncEntities {
    const val JOB = "job"
    const val CLIENT = "client"
    const val QUOTE = "quote"
    const val PHOTO = "photo"
    const val SIGNATURE = "signature"

    val ALL = listOf(JOB, CLIENT, QUOTE, PHOTO, SIGNATURE)
}
