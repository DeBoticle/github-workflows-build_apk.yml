package com.fieldflow.pro.data.sync

import com.fieldflow.pro.core.AppLogger
import com.fieldflow.pro.core.analytics.Analytics
import com.fieldflow.pro.core.analytics.AnalyticsEvents
import com.fieldflow.pro.core.net.ConnectivityMonitor
import com.fieldflow.pro.data.local.ClientRepository
import com.fieldflow.pro.data.local.JobRepository
import com.fieldflow.pro.data.local.PhotoRepository
import com.fieldflow.pro.data.local.QuoteRepository
import com.fieldflow.pro.data.local.SettingsRepository
import com.fieldflow.pro.data.local.SignatureRepository
import com.fieldflow.pro.data.local.SyncQueueRepository
import com.fieldflow.pro.data.model.Client
import com.fieldflow.pro.data.model.Job
import com.fieldflow.pro.data.model.Photo
import com.fieldflow.pro.data.model.Quote
import com.fieldflow.pro.data.model.Signature
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

sealed class SyncOutcome {
    data class Success(val pushed: Int, val pulled: Int, val cursor: String) : SyncOutcome()
    data object Offline : SyncOutcome()
    data object NothingToDo : SyncOutcome()
    data class Failure(val message: String, val retryable: Boolean) : SyncOutcome()
}

data class SyncUiState(
    val isSyncing: Boolean = false,
    val pendingOps: Int = 0,
    val failedOps: Int = 0,
    val lastSyncAt: Long = 0L,
    val lastMessage: String = "",
    val lastOutcome: String = "",
    val online: Boolean = true,
    val apiMode: String = "",
    val apiConfigured: Boolean = true,
)

class SyncEngine(
    private val queue: SyncQueueRepository,
    private val jobs: JobRepository,
    private val clients: ClientRepository,
    private val quotes: QuoteRepository,
    private val photos: PhotoRepository,
    private val signatures: SignatureRepository,
    private val settings: SettingsRepository,
    private val connectivity: ConnectivityMonitor,
    private val api: CloudApi,
    private val analytics: Analytics,
    private val logger: AppLogger,
    private val json: Json,
    scope: CoroutineScope,
) {

    private val _state = MutableStateFlow(SyncUiState(apiMode = api.modeLabel, apiConfigured = api.isConfigured))
    val state: StateFlow<SyncUiState> = _state.asStateFlow()

    private var running = false

    init {
        scope.launch {
            queue.operations.collect { operations ->
                _state.value = _state.value.copy(
                    pendingOps = operations.size,
                    failedOps = operations.count { it.attempts > 0 },
                )
            }
        }
        scope.launch {
            connectivity.online.collect { online ->
                _state.value = _state.value.copy(online = online)
            }
        }
    }

    suspend fun refreshCounters() {
        val ops = queue.all()
        _state.value = _state.value.copy(
            pendingOps = ops.size,
            failedOps = ops.count { it.attempts > 0 },
            online = connectivity.online.value,
        )
    }

    suspend fun syncNow(trigger: String = "manual"): SyncOutcome {
        val current = _state.value
        if (running) {
            logger.d(TAG, "sync already running; skipping $trigger")
            return SyncOutcome.NothingToDo
        }
        if (!connectivity.isCurrentlyOnline()) {
            analytics.log(AnalyticsEvents.SYNC_OFFLINE, mapOf("trigger" to trigger))
            _state.value = current.copy(online = false, lastOutcome = "offline", lastMessage = "Offline — changes stay on the device")
            return SyncOutcome.Offline
        }
        if (!api.isConfigured) {
            _state.value = current.copy(lastOutcome = "unconfigured", lastMessage = "Sync endpoint not configured")
            return SyncOutcome.Failure("Sync endpoint not configured", retryable = false)
        }
        val settingsValue = settings.current()
        running = true
        _state.value = _state.value.copy(isSyncing = true, lastMessage = "Syncing…")
        analytics.log(AnalyticsEvents.SYNC_STARTED, mapOf("trigger" to trigger))

        return try {
            val now = System.currentTimeMillis()
            val due = queue.dueBatch(now, BATCH_SIZE)
            val pushResult = if (due.isEmpty()) {
                null
            } else {
                val request = PushRequest(
                    deviceId = deviceId(),
                    cursor = settingsValue.lastSyncCursor,
                    changes = due.map {
                        ChangeRecord(
                            entityType = it.entityType,
                            entityId = it.entityId,
                            op = it.op,
                            payload = it.payload,
                            updatedAt = now,
                            version = 1L,
                        )
                    },
                )
                api.push(request)
            }

            var pushedCount = 0
            var cursor = settingsValue.lastSyncCursor
            when (pushResult) {
                null -> Unit
                is com.fieldflow.pro.core.AppResult.Failure -> {
                    val message = pushResult.error.userMessage()
                    val retryable = (pushResult.error as? com.fieldflow.pro.core.AppError.Network)?.retryable ?: true
                    due.forEach { queue.markFailed(it.id, message, backoff(now, it.attempts)) }
                    return fail(message, retryable, trigger)
                }
                is com.fieldflow.pro.core.AppResult.Success -> {
                    val accepted = pushResult.value.accepted.toSet()
                    val rejected = pushResult.value.rejected.toSet()
                    val done = due.filter { "${it.entityType}:${it.entityId}" in accepted }
                    val conflicted = due.filter { "${it.entityType}:${it.entityId}" in rejected }
                    queue.markDone(done.map { it.id })
                    conflicted.forEach { queue.markFailed(it.id, "Server has newer data — will re-pull", now) }
                    markEntitiesSynced(done.map { it.entityType to it.entityId })
                    pushedCount = done.size
                    cursor = pushResult.value.cursor.ifBlank { cursor }
                }
            }

            val pullResult = api.pull(cursor)
            var pulledCount = 0
            val newCursor = when (pullResult) {
                is com.fieldflow.pro.core.AppResult.Success -> {
                    pullResult.value.changes.forEach { change ->
                        if (applyRemote(change)) pulledCount++
                    }
                    pullResult.value.cursor.ifBlank { cursor }
                }
                is com.fieldflow.pro.core.AppResult.Failure -> {
                    val message = pullResult.error.userMessage()
                    val retryable = (pullResult.error as? com.fieldflow.pro.core.AppError.Network)?.retryable ?: true
                    return fail(message, retryable, trigger)
                }
            }

            settings.recordSync(newCursor, pulledCount, pushedCount)
            analytics.log(
                AnalyticsEvents.SYNC_SUCCEEDED,
                mapOf("trigger" to trigger, "pushed" to pushedCount, "pulled" to pulledCount),
            )
            refreshCounters()
            _state.value = _state.value.copy(
                isSyncing = false,
                lastSyncAt = System.currentTimeMillis(),
                lastOutcome = "success",
                lastMessage = buildMessage(pushedCount, pulledCount),
            )
            SyncOutcome.Success(pushedCount, pulledCount, newCursor)
        } catch (t: Throwable) {
            logger.e(TAG, "Sync crashed", t)
            fail(t.message ?: "Sync failed", retryable = true, trigger = trigger)
        } finally {
            running = false
        }
    }

    private suspend fun fail(message: String, retryable: Boolean, trigger: String): SyncOutcome.Failure {
        analytics.log(AnalyticsEvents.SYNC_FAILED, mapOf("trigger" to trigger, "message" to message))
        _state.value = _state.value.copy(
            isSyncing = false,
            lastOutcome = "error",
            lastMessage = message,
        )
        runCatching { settings.recordSync(settings.cursor.value.cursor, 0, 0, message) }
        return SyncOutcome.Failure(message, retryable)
    }

    private fun buildMessage(pushed: Int, pulled: Int): String = when {
        pushed == 0 && pulled == 0 -> "Everything up to date"
        pushed > 0 && pulled == 0 -> "Uploaded $pushed change(s)"
        pushed == 0 && pulled > 0 -> "Downloaded $pulled change(s)"
        else -> "Uploaded $pushed, downloaded $pulled"
    }

    private suspend fun markEntitiesSynced(pairs: List<Pair<String, String>>) {
        SyncEntities.ALL.forEach { type ->
            val ids = pairs.filter { it.first == type }.map { it.second }
            when (type) {
                SyncEntities.JOB -> jobs.markSynced(ids)
                SyncEntities.CLIENT -> clients.markSynced(ids)
                SyncEntities.QUOTE -> quotes.markSynced(ids)
                SyncEntities.PHOTO -> photos.markSynced(ids)
                SyncEntities.SIGNATURE -> signatures.markSynced(ids)
            }
        }
    }

    private suspend fun applyRemote(change: ChangeRecord): Boolean = try {
        when (change.entityType) {
            SyncEntities.JOB -> jobs.applyRemote(json.decodeFromString(Job.serializer(), change.payload))
            SyncEntities.CLIENT -> clients.applyRemote(json.decodeFromString(Client.serializer(), change.payload))
            SyncEntities.QUOTE -> quotes.applyRemote(json.decodeFromString(Quote.serializer(), change.payload))
            SyncEntities.PHOTO -> photos.applyRemote(json.decodeFromString(Photo.serializer(), change.payload))
            SyncEntities.SIGNATURE -> signatures.applyRemote(json.decodeFromString(Signature.serializer(), change.payload))
            else -> {
                logger.w(TAG, "Ignoring unknown entity type ${change.entityType}")
                false
            }
        }
    } catch (t: Throwable) {
        logger.w(TAG, "Could not apply remote ${change.entityType}/${change.entityId}", t)
        false
    }

    private fun backoff(now: Long, attempts: Int): Long {
        val seconds = (30L * (1L shl attempts.coerceAtMost(6))).coerceAtMost(3600L)
        return now + seconds * 1000L
    }

    private fun deviceId(): String = settings.device.value.deviceId

    private companion object {
        const val TAG = "SyncEngine"
        const val BATCH_SIZE = 200
    }
}
