package com.fieldflow.pro.data.sync

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.fieldflow.pro.FieldFlowApp
import java.util.concurrent.TimeUnit

class SyncWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val container = (applicationContext as? FieldFlowApp)?.container
            ?: return Result.failure(workDataOf(KEY_ERROR to "app container unavailable"))
        val trigger = inputData.getString(KEY_TRIGGER) ?: "worker"
        return when (val outcome = container.sync.syncNow(trigger)) {
            is SyncOutcome.Success -> Result.success(
                workDataOf(KEY_PUSHED to outcome.pushed, KEY_PULLED to outcome.pulled, KEY_CURSOR to outcome.cursor),
            )
            SyncOutcome.NothingToDo -> Result.success(workDataOf(KEY_MESSAGE to "nothing to do"))
            SyncOutcome.Offline -> Result.success(workDataOf(KEY_MESSAGE to "offline"))
            is SyncOutcome.Failure -> if (outcome.retryable) {
                Result.retry()
            } else {
                Result.failure(workDataOf(KEY_ERROR to outcome.message))
            }
        }
    }

    companion object {
        const val KEY_TRIGGER = "trigger"
        const val KEY_ERROR = "error"
        const val KEY_MESSAGE = "message"
        const val KEY_PUSHED = "pushed"
        const val KEY_PULLED = "pulled"
        const val KEY_CURSOR = "cursor"
    }
}

object SyncScheduler {

    private const val PERIODIC_WORK = "fieldflow-periodic-sync"
    private const val IMMEDIATE_WORK = "fieldflow-immediate-sync"

    fun schedulePeriodic(context: Context, wifiOnly: Boolean) {
        val request = PeriodicWorkRequestBuilder<SyncWorker>(30, TimeUnit.MINUTES)
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED)
                    .build(),
            )
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .setInputData(workDataOf(SyncWorker.KEY_TRIGGER to "periodic"))
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            PERIODIC_WORK,
            ExistingPeriodicWorkPolicy.UPDATE,
            request,
        )
    }

    fun cancelPeriodic(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(PERIODIC_WORK)
    }

    fun requestImmediateSync(context: Context, trigger: String = "connectivity") {
        val request = OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build(),
            )
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.SECONDS)
            .setInputData(workDataOf(SyncWorker.KEY_TRIGGER to trigger))
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            IMMEDIATE_WORK,
            ExistingWorkPolicy.KEEP,
            request,
        )
    }
}
