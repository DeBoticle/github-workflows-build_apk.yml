package com.fieldflow.pro.data.templates

import android.content.Context
import com.fieldflow.pro.core.AppLogger
import com.fieldflow.pro.core.JsonTable
import com.fieldflow.pro.data.model.AppSettings
import com.fieldflow.pro.data.model.ChecklistItem
import com.fieldflow.pro.data.model.Job
import com.fieldflow.pro.data.model.JobStatus
import com.fieldflow.pro.data.model.MaterialLine
import com.fieldflow.pro.data.model.Quote
import com.fieldflow.pro.data.model.QuoteLine
import com.fieldflow.pro.data.model.QuoteLineKind
import com.fieldflow.pro.data.model.TemplateLine
import com.fieldflow.pro.data.model.Trade
import com.fieldflow.pro.data.model.TradeTemplate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

class TemplateRepository(
    private val context: Context,
    private val customTable: JsonTable<TradeTemplate>,
    private val json: Json,
    private val logger: AppLogger,
) {

    private val _builtIn = MutableStateFlow<List<TradeTemplate>>(emptyList())
    val builtIn: StateFlow<List<TradeTemplate>> = _builtIn.asStateFlow()

    val custom: StateFlow<List<TradeTemplate>> = customTable.items

    suspend fun load() {
        customTable.load()
        if (_builtIn.value.isNotEmpty()) return
        val parsed = withContext(Dispatchers.IO) {
            runCatching {
                val text = context.assets.open(ASSET).bufferedReader().use { it.readText() }
                json.decodeFromString(ListSerializer(TradeTemplate.serializer()), text)
            }.getOrElse { error ->
                logger.e(TAG, "Bundled templates failed to load", error)
                emptyList()
            }
        }
        _builtIn.value = parsed
        logger.i(TAG, "Loaded ${parsed.size} bundled templates")
    }

    fun forTrade(trade: Trade): List<TradeTemplate> =
        (_builtIn.value + custom.value).filter { it.trade == trade }

    fun all(): List<TradeTemplate> = _builtIn.value + custom.value

    fun byId(id: String): TradeTemplate? = all().firstOrNull { it.id == id }

    suspend fun saveCustom(template: TradeTemplate): TradeTemplate {
        val record = template.copy(id = template.id.ifBlank { "tpl-custom-" + System.currentTimeMillis() })
        customTable.upsert(record)
        return record
    }

    suspend fun deleteCustom(id: String) = customTable.deleteById(id)

    fun toQuoteLines(template: TradeTemplate, overrideRateCents: Long? = null): List<QuoteLine> =
        template.lines.map { line -> toQuoteLine(line, overrideRateCents) }

    private fun toQuoteLine(line: TemplateLine, overrideRateCents: Long?): QuoteLine {
        val rate = if (line.kind == QuoteLineKind.LABOUR && overrideRateCents != null && overrideRateCents > 0) {
            overrideRateCents
        } else {
            line.unitPriceCents
        }
        return QuoteLine(
            kind = line.kind,
            description = line.description,
            detail = line.detail,
            quantity = line.quantity,
            unit = line.unit,
            unitPriceCents = rate,
            taxable = line.kind != QuoteLineKind.DISCOUNT,
        )
    }

    fun checklistFor(template: TradeTemplate): List<ChecklistItem> = template.checklist.map { ChecklistItem(label = it) }

    fun applyTo(job: Job, template: TradeTemplate, settings: AppSettings? = null): Job = job.copy(
        title = template.defaultTitle.ifBlank { job.title },
        description = template.defaultDescription.ifBlank { job.description },
        trade = template.trade,
        materials = template.lines.filter { it.kind == QuoteLineKind.MATERIAL }.map { line ->
            MaterialLine(
                description = line.description,
                quantity = line.quantity,
                unit = line.unit,
                unitPriceCents = line.unitPriceCents,
            )
        },
        checklist = if (job.checklist.isEmpty()) checklistFor(template) else job.checklist,
        labourHours = if (job.labourHours == 0.0) template.labourHours else job.labourHours,
        labourRateCents = if (job.labourRateCents == 0L) settings?.defaultLabourRateCents ?: 0L else job.labourRateCents,
        taxRatePercent = if (job.taxRatePercent == 0.0) settings?.defaultTaxRatePercent ?: 0.0 else job.taxRatePercent,
        status = if (job.status == JobStatus.DRAFT) JobStatus.SCHEDULED else job.status,
    )

    fun newQuoteFor(job: Job, template: TradeTemplate, settings: AppSettings, now: Long): Quote = Quote(
        jobId = job.id,
        lines = toQuoteLines(template, settings.defaultLabourRateCents),
        taxRatePercent = settings.defaultTaxRatePercent,
        terms = settings.defaultQuoteTerms,
        validUntil = now + settings.defaultValidDays * 86_400_000L,
        createdAt = now,
        updatedAt = now,
    )

    private companion object {
        const val TAG = "Templates"
        const val ASSET = "templates.json"
    }
}
