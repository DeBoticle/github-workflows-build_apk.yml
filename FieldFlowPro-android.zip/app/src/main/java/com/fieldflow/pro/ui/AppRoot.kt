package com.fieldflow.pro.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.ui.components.LoadingDots
import com.fieldflow.pro.ui.components.VSpace
import com.fieldflow.pro.ui.nav.AppNav
import com.fieldflow.pro.ui.screens.LoginScreen
import com.fieldflow.pro.ui.screens.OnboardingScreen
import com.fieldflow.pro.ui.theme.FieldFlowTheme

@Composable
fun FieldFlowRoot(container: AppContainer) {
    val settings by container.settings.settings.collectAsState()
    val session by container.auth.session.collectAsState()
    var booted by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        runCatching { container.bootstrap() }
        booted = true
    }

    FieldFlowTheme(themeMode = settings.themeMode, gloveMode = settings.gloveMode) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background,
        ) {
            when {
                !booted -> BootGate()
                session == null -> LoginScreen(container)
                !settings.onboardingComplete -> OnboardingScreen(container)
                else -> AppNav(container)
            }
        }
    }
}

@Composable
private fun BootGate() {
    Surface(color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("FieldFlow Pro", style = MaterialTheme.typography.headlineMedium)
            VSpace(16)
            LoadingDots(label = "Unlocking encrypted storage…")
        }
    }
}
