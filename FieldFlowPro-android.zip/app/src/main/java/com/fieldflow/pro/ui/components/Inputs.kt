package com.fieldflow.pro.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.fieldflow.pro.core.Money

@Composable
fun FfMoneyInput(
    cents: Long,
    onCentsChange: (Long) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    supportingText: String? = null,
) {
    var text by remember { mutableStateOf(if (cents == 0L) "" else Money.formatPlain(cents)) }
    FfMoneyField(
        value = text,
        onValueChange = { input ->
            text = input
            onCentsChange(Money.parseToCents(input) ?: 0L)
        },
        label = label,
        modifier = modifier,
        supportingText = supportingText,
    )
}

@Composable
fun FfQtyInput(
    value: Double,
    onValueChange: (Double) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
) {
    var text by remember { mutableStateOf(if (value == 0.0) "" else trimNumber(value)) }
    FfNumberField(
        value = text,
        onValueChange = { input ->
            text = input
            onValueChange(input.toDoubleOrNull() ?: 0.0)
        },
        label = label,
        modifier = modifier,
    )
}

@Composable
fun FfPercentInput(
    value: Double,
    onValueChange: (Double) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
) {
    var text by remember {
        mutableStateOf(if (value == 0.0) "" else trimNumber(value))
    }
    FfTextField(
        value = text,
        onValueChange = { input ->
            val filtered = input.filter { it.isDigit() || it == '.' }
            text = filtered
            onValueChange(filtered.toDoubleOrNull() ?: 0.0)
        },
        label = label,
        modifier = modifier,
        keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal,
    )
}

fun trimNumber(value: Double): String =
    if (value == value.toLong().toDouble()) value.toLong().toString() else value.toString()
