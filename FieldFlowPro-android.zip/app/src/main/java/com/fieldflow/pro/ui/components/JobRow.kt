package com.fieldflow.pro.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.SyncProblem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.fieldflow.pro.core.Dates
import com.fieldflow.pro.core.Money
import com.fieldflow.pro.data.model.Job
import com.fieldflow.pro.data.model.JobStatus
import com.fieldflow.pro.data.model.Priority
import com.fieldflow.pro.data.model.SyncState
import com.fieldflow.pro.ui.theme.FieldFlowAmber
import com.fieldflow.pro.ui.theme.FieldFlowBlue
import com.fieldflow.pro.ui.theme.FieldFlowGreen
import com.fieldflow.pro.ui.theme.FieldFlowOrange
import com.fieldflow.pro.ui.theme.FieldFlowRed
import com.fieldflow.pro.ui.theme.LocalFfDimens

fun JobStatus.tint(): Color = when (this) {
    JobStatus.DRAFT -> FieldFlowBlue
    JobStatus.SCHEDULED -> FieldFlowBlue
    JobStatus.IN_PROGRESS -> FieldFlowOrange
    JobStatus.AWAITING_SIGNATURE -> FieldFlowAmber
    JobStatus.COMPLETE -> FieldFlowGreen
    JobStatus.INVOICED -> FieldFlowGreen
    JobStatus.CANCELLED -> FieldFlowRed
}

fun Priority.tint(): Color = when (this) {
    Priority.LOW -> FieldFlowBlue
    Priority.NORMAL -> FieldFlowBlue
    Priority.URGENT -> FieldFlowOrange
    Priority.EMERGENCY -> FieldFlowRed
}

@Composable
fun StatusPill(text: String, tint: Color, modifier: Modifier = Modifier) {
    Surface(
        color = tint.copy(alpha = 0.18f),
        shape = RoundedCornerShape(50),
        modifier = modifier,
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelSmall,
            color = tint,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
        )
    }
}

@Composable
fun JobRow(
    job: Job,
    currency: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val dimens = LocalFfDimens.current
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        color = MaterialTheme.colorScheme.surface,
        shape = MaterialTheme.shapes.large,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(modifier = Modifier.padding(dimens.cardPadding)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = MaterialTheme.shapes.small,
                ) {
                    Box(modifier = Modifier.size(dimens.touchTarget * 0.8f), contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = job.trade.icon(),
                            contentDescription = job.trade.displayName,
                            modifier = Modifier.size(dimens.iconMedium),
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        )
                    }
                }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 12.dp),
                ) {
                    Text(
                        job.title.ifBlank { "Untitled job" },
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        listOfNotNull(
                            job.number.ifBlank { null },
                            job.clientName.ifBlank { null },
                        ).joinToString(" · ").ifBlank { "No client yet" },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                StatusPill(job.status.displayName, job.status.tint())
            }

            if (job.address.isNotBlank()) {
                Row(
                    modifier = Modifier.padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        Icons.Filled.Place,
                        contentDescription = null,
                        modifier = Modifier.size(dimens.iconMedium * 0.8f),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        job.address,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(start = 6.dp),
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    Money.format(job.totalCents, currency),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    " · ${job.scheduledLabel}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (job.priority == Priority.URGENT || job.priority == Priority.EMERGENCY) {
                    HSpace(8)
                    StatusPill(job.priority.displayName, job.priority.tint())
                }
                Box(modifier = Modifier.weight(1f))
                if (job.photoIds.isNotEmpty()) {
                    Icon(
                        Icons.Filled.Image,
                        contentDescription = null,
                        modifier = Modifier.size(dimens.iconMedium * 0.8f),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        " ${job.photoIds.size}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Icon(
                    imageVector = when (job.syncState) {
                        SyncState.SYNCED -> Icons.Filled.CloudDone
                        SyncState.FAILED -> Icons.Filled.SyncProblem
                        else -> Icons.Filled.CloudUpload
                    },
                    contentDescription = job.syncState.displayName,
                    modifier = Modifier
                        .padding(start = 10.dp)
                        .size(dimens.iconMedium * 0.8f),
                    tint = when (job.syncState) {
                        SyncState.SYNCED -> FieldFlowGreen
                        SyncState.FAILED -> FieldFlowRed
                        else -> FieldFlowOrange
                    },
                )
            }

            if (job.checklist.isNotEmpty()) {
                Row(
                    modifier = Modifier.padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "Checklist ${(job.checklistProgress * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        "  ·  updated ${Dates.relative(job.updatedAt)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
