package com.fieldflow.pro.ui.components

import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint as AndroidPaint
import android.graphics.Path as AndroidPath
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

data class SignatureStroke(
    val points: List<Offset>,
    val width: Float,
)

private fun normalized(points: List<Offset>, size: Size): List<Offset> =
    points.map { Offset(it.x / size.width.coerceAtLeast(1f), it.y / size.height.coerceAtLeast(1f)) }

@Composable
fun SignaturePad(
    strokes: List<SignatureStroke>,
    onStrokeFinished: (SignatureStroke) -> Unit,
    modifier: Modifier = Modifier,
    penColor: Color = Color(0xFF12203A),
    backgroundColor: Color = Color.White,
    lineWidth: Float = 0.012f,
) {
    var live by remember { mutableStateOf<List<Offset>>(emptyList()) }
    Canvas(
        modifier = modifier
            .clipToBounds()
            .background(backgroundColor)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset -> live = listOf(offset) },
                    onDrag = { change, _ ->
                        change.consume()
                        live = live + change.position
                    },
                    onDragEnd = {
                        if (live.size > 1) {
                            onStrokeFinished(SignatureStroke(normalized(live, Size(size.width.toFloat(), size.height.toFloat())), lineWidth))
                        }
                        live = emptyList()
                    },
                    onDragCancel = { live = emptyList() },
                )
            },
    ) {
        strokes.forEach { stroke -> drawSignatureStroke(stroke, penColor) }
        if (live.size > 1) {
            drawSignatureStroke(
                SignatureStroke(normalized(live, Size(size.width.toFloat(), size.height.toFloat())), lineWidth),
                penColor,
            )
        }
    }
}

private fun DrawScope.drawSignatureStroke(stroke: SignatureStroke, color: Color) {
    val points = stroke.points.map { Offset(it.x * size.width, it.y * size.height) }
    if (points.size < 2) return
    val path = Path().apply {
        moveTo(points.first().x, points.first().y)
        for (index in 1 until points.size) {
            val previous = points[index - 1]
            val current = points[index]
            val midX = (previous.x + current.x) / 2f
            val midY = (previous.y + current.y) / 2f
            quadraticBezierTo(previous.x, previous.y, midX, midY)
        }
        lineTo(points.last().x, points.last().y)
    }
    drawPath(
        path = path,
        color = color,
        style = Stroke(width = stroke.width * minOf(size.width, size.height), cap = StrokeCap.Round, join = StrokeJoin.Round),
    )
}

fun renderSignatureBitmap(
    strokes: List<SignatureStroke>,
    outputWidth: Int = 1400,
): Bitmap? {
    if (strokes.isEmpty()) return null
    val allPoints = strokes.flatMap { it.points }
    if (allPoints.isEmpty()) return null
    val minX = allPoints.minOf { it.x }
    val maxX = allPoints.maxOf { it.x }
    val minY = allPoints.minOf { it.y }
    val maxY = allPoints.maxOf { it.y }
    val padX = 0.04f
    val padY = 0.06f
    val left = (minX - padX).coerceAtLeast(0f)
    val right = (maxX + padX).coerceAtMost(1f)
    val top = (minY - padY).coerceAtLeast(0f)
    val bottom = (maxY + padY).coerceAtMost(1f)
    val boxWidth = (right - left).coerceAtLeast(0.05f)
    val boxHeight = (bottom - top).coerceAtLeast(0.05f)
    val aspect = boxHeight / boxWidth
    val outWidth = outputWidth
    val outHeight = (outputWidth * aspect).toInt().coerceIn(220, 900)
    val scaleX = outWidth / boxWidth
    val scaleY = outHeight / boxHeight
    val bitmap = Bitmap.createBitmap(outWidth, outHeight, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bitmap)
    canvas.drawColor(android.graphics.Color.WHITE)
    val paint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
        this.color = android.graphics.Color.rgb(18, 32, 58)
        style = AndroidPaint.Style.STROKE
        strokeCap = AndroidPaint.Cap.ROUND
        strokeJoin = AndroidPaint.Join.ROUND
    }
    strokes.forEach { stroke ->
        val points = stroke.points.map { Offset((it.x - left) * scaleX, (it.y - top) * scaleY) }
        if (points.size < 2) return@forEach
        paint.strokeWidth = (stroke.width * minOf(scaleX, scaleY)).coerceAtLeast(2f)
        val path = AndroidPath()
        path.moveTo(points.first().x, points.first().y)
        for (index in 1 until points.size) {
            val previous = points[index - 1]
            val current = points[index]
            path.quadTo(
                previous.x,
                previous.y,
                (previous.x + current.x) / 2f,
                (previous.y + current.y) / 2f,
            )
        }
        path.lineTo(points.last().x, points.last().y)
        canvas.drawPath(path, paint)
    }
    return bitmap
}

enum class MarkupTool(val label: String) {
    PEN("Pen"),
    HIGHLIGHT("Highlight"),
    ARROW("Arrow"),
    BOX("Box"),
    TEXT("Label"),
}

data class MarkupStroke(
    val tool: MarkupTool,
    val points: List<Offset>,
    val color: Color,
    val width: Float,
    val label: String = "",
)

@Composable
fun MarkupCanvas(
    image: ImageBitmap,
    strokes: List<MarkupStroke>,
    tool: MarkupTool,
    color: Color,
    width: Float,
    pendingLabel: String,
    modifier: Modifier = Modifier,
    onStrokeFinished: (MarkupStroke) -> Unit,
) {
    val measurer = rememberTextMeasurer()
    var live by remember { mutableStateOf<List<Offset>>(emptyList()) }

    Canvas(
        modifier = modifier
            .aspectRatio(image.width.toFloat() / image.height.toFloat())
            .clipToBounds()
            .pointerInput(tool, color, width, pendingLabel) {
                if (tool == MarkupTool.TEXT) {
                    detectTapGestures { offset ->
                        onStrokeFinished(
                            MarkupStroke(
                                tool = MarkupTool.TEXT,
                                points = listOf(Offset(offset.x / size.width, offset.y / size.height)),
                                color = color,
                                width = width,
                                label = pendingLabel,
                            ),
                        )
                    }
                } else {
                    detectDragGestures(
                        onDragStart = { offset -> live = listOf(offset) },
                        onDrag = { change, _ ->
                            change.consume()
                            live = live + change.position
                        },
                        onDragEnd = {
                            if (live.size > 1) {
                                val currentSize = Size(size.width.toFloat(), size.height.toFloat())
                                onStrokeFinished(
                                    MarkupStroke(
                                        tool = tool,
                                        points = normalized(live, currentSize),
                                        color = color,
                                        width = width,
                                    ),
                                )
                            }
                            live = emptyList()
                        },
                        onDragCancel = { live = emptyList() },
                    )
                }
            },
    ) {
        drawImage(
            image = image,
            dstSize = androidx.compose.ui.unit.IntSize(size.width.toInt(), size.height.toInt()),
            dstOffset = androidx.compose.ui.unit.IntOffset.Zero,
        )
        strokes.forEach { drawMarkupStroke(it, measurer) }
        if (live.size > 1) {
            drawMarkupStroke(
                MarkupStroke(tool, normalized(live, Size(size.width.toFloat(), size.height.toFloat())), color, width),
                measurer,
            )
        }
    }
}

private fun DrawScope.drawMarkupStroke(stroke: MarkupStroke, measurer: TextMeasurer) {
    val points = stroke.points.map { Offset(it.x * size.width, it.y * size.height) }
    if (points.isEmpty()) return
    val thickness = (stroke.width * minOf(size.width, size.height)).coerceAtLeast(1.5f)
    when (stroke.tool) {
        MarkupTool.PEN, MarkupTool.HIGHLIGHT -> {
            if (points.size < 2) return
            val path = Path().apply {
                moveTo(points.first().x, points.first().y)
                points.drop(1).forEach { lineTo(it.x, it.y) }
            }
            drawPath(
                path = path,
                color = if (stroke.tool == MarkupTool.HIGHLIGHT) stroke.color.copy(alpha = 0.38f) else stroke.color,
                style = Stroke(
                    width = if (stroke.tool == MarkupTool.HIGHLIGHT) thickness * 3.2f else thickness,
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round,
                ),
            )
        }
        MarkupTool.ARROW -> {
            if (points.size < 2) return
            val start = points.first()
            val end = points.last()
            drawLine(stroke.color, start, end, strokeWidth = thickness, cap = StrokeCap.Round)
            val angle = kotlin.math.atan2((end.y - start.y).toDouble(), (end.x - start.x).toDouble())
            val headLength = thickness * 4.5f
            listOf(angle + 2.6, angle - 2.6).forEach { direction ->
                drawLine(
                    color = stroke.color,
                    start = end,
                    end = Offset(
                        end.x + (headLength * kotlin.math.cos(direction)).toFloat(),
                        end.y + (headLength * kotlin.math.sin(direction)).toFloat(),
                    ),
                    strokeWidth = thickness,
                    cap = StrokeCap.Round,
                )
            }
        }
        MarkupTool.BOX -> {
            if (points.size < 2) return
            val rect = Rect(
                left = minOf(points.first().x, points.last().x),
                top = minOf(points.first().y, points.last().y),
                right = maxOf(points.first().x, points.last().x),
                bottom = maxOf(points.first().y, points.last().y),
            )
            drawRect(
                color = stroke.color,
                topLeft = Offset(rect.left, rect.top),
                size = Size(rect.width, rect.height),
                style = Stroke(width = thickness),
            )
        }
        MarkupTool.TEXT -> {
            if (stroke.label.isBlank()) return
            val fontSize = (stroke.width * minOf(size.width, size.height) * 3.4f).coerceIn(11f, 90f)
            val measured = measurer.measure(
                text = AnnotatedString(stroke.label),
                style = TextStyle(color = Color.White, fontSize = fontSize.sp, fontWeight = FontWeight.Bold),
            )
            val pad = thickness * 2.4f
            val anchor = points.first().let {
                Offset((it.x).coerceIn(0f, (size.width - measured.size.width - pad * 2).coerceAtLeast(0f)), it.y.coerceIn(0f, size.height - measured.size.height - pad * 2))
            }
            drawRoundRect(
                color = stroke.color,
                topLeft = anchor,
                size = Size(measured.size.width + pad * 2, measured.size.height + pad * 2),
                cornerRadius = CornerRadius(pad * 1.6f, pad * 1.6f),
            )
            drawText(measured, topLeft = Offset(anchor.x + pad, anchor.y + pad))
        }
    }
}

fun renderMarkupBitmap(base: Bitmap, strokes: List<MarkupStroke>): Bitmap {
    val output = Bitmap.createBitmap(base.width, base.height, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(output)
    canvas.drawBitmap(base, 0f, 0f, null)
    val minDimension = minOf(base.width, base.height).toFloat()
    strokes.forEach { stroke ->
        val points = stroke.points.map { Offset(it.x * base.width, it.y * base.height) }
        if (points.isEmpty()) return@forEach
        val paint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
            color = stroke.color.toArgbInt()
            strokeWidth = (stroke.width * minDimension).coerceAtLeast(2f)
            style = AndroidPaint.Style.STROKE
            strokeCap = AndroidPaint.Cap.ROUND
            strokeJoin = AndroidPaint.Join.ROUND
        }
        when (stroke.tool) {
            MarkupTool.PEN -> {
                if (points.size < 2) return@forEach
                val path = AndroidPath().apply {
                    moveTo(points.first().x, points.first().y)
                    points.drop(1).forEach { lineTo(it.x, it.y) }
                }
                canvas.drawPath(path, paint)
            }
            MarkupTool.HIGHLIGHT -> {
                if (points.size < 2) return@forEach
                paint.alpha = 100
                paint.strokeWidth = paint.strokeWidth * 3.2f
                val path = AndroidPath().apply {
                    moveTo(points.first().x, points.first().y)
                    points.drop(1).forEach { lineTo(it.x, it.y) }
                }
                canvas.drawPath(path, paint)
            }
            MarkupTool.ARROW -> {
                if (points.size < 2) return@forEach
                val start = points.first()
                val end = points.last()
                canvas.drawLine(start.x, start.y, end.x, end.y, paint)
                val angle = kotlin.math.atan2((end.y - start.y).toDouble(), (end.x - start.x).toDouble())
                val head = paint.strokeWidth * 4.5f
                listOf(angle + 2.6, angle - 2.6).forEach { direction ->
                    canvas.drawLine(
                        end.x,
                        end.y,
                        end.x + (head * kotlin.math.cos(direction)).toFloat(),
                        end.y + (head * kotlin.math.sin(direction)).toFloat(),
                        paint,
                    )
                }
            }
            MarkupTool.BOX -> {
                if (points.size < 2) return@forEach
                val left = minOf(points.first().x, points.last().x)
                val top = minOf(points.first().y, points.last().y)
                val right = maxOf(points.first().x, points.last().x)
                val bottom = maxOf(points.first().y, points.last().y)
                canvas.drawRect(left, top, right, bottom, paint)
            }
            MarkupTool.TEXT -> {
                if (stroke.label.isBlank()) return@forEach
                val textPaint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
                    color = android.graphics.Color.WHITE
                    textSize = (paint.strokeWidth * 3.4f).coerceIn(14f, 120f)
                    isFakeBoldText = true
                }
                val pad = paint.strokeWidth * 2.4f
                val anchor = points.first()
                val width = textPaint.measureText(stroke.label) + pad * 2
                val baseline = textPaint.textSize
                paint.style = AndroidPaint.Style.FILL
                canvas.drawRoundRect(
                    anchor.x,
                    anchor.y,
                    (anchor.x + width).coerceAtMost(base.width.toFloat()),
                    (anchor.y + baseline + pad * 2).coerceAtMost(base.height.toFloat()),
                    pad * 1.6f,
                    pad * 1.6f,
                    paint,
                )
                canvas.drawText(stroke.label, anchor.x + pad, anchor.y + pad + baseline * 0.82f, textPaint)
            }
        }
    }
    return output
}

private fun Color.toArgbInt(): Int = android.graphics.Color.argb(
    (alpha * 255f).toInt().coerceIn(0, 255),
    (red * 255f).toInt().coerceIn(0, 255),
    (green * 255f).toInt().coerceIn(0, 255),
    (blue * 255f).toInt().coerceIn(0, 255),
)

@Composable
fun BeforeAfterSlider(
    beforeModel: Any?,
    afterModel: Any?,
    modifier: Modifier = Modifier,
    beforeLabel: String = "BEFORE",
    afterLabel: String = "AFTER",
    startFraction: Float = 0.5f,
) {
    var fraction by remember { mutableFloatStateOf(startFraction.coerceIn(0.05f, 0.95f)) }
    Column(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(320.dp)
                .clip(MaterialTheme.shapes.medium)
                .background(Color.Black),
        ) {
            AsyncImage(
                model = beforeModel,
                contentDescription = beforeLabel,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize(),
            )
            AsyncImage(
                model = afterModel,
                contentDescription = afterLabel,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .drawWithContent {
                        clipRect(right = size.width * fraction) {
                            this@drawWithContent.drawContent()
                        }
                    },
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectDragGestures { change, _ ->
                            change.consume()
                            fraction = (change.position.x / size.width.toFloat()).coerceIn(0.02f, 0.98f)
                        }
                    },
            )
            Surface(
                color = Color.White.copy(alpha = 0.85f),
                shape = MaterialTheme.shapes.extraSmall,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp),
            ) {
                Text(
                    beforeLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.Black,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                )
            }
            Surface(
                color = Color.White.copy(alpha = 0.85f),
                shape = MaterialTheme.shapes.extraSmall,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp),
            ) {
                Text(
                    afterLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.Black,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawWithContent {
                        drawContent()
                        val x = size.width * fraction
                        drawLine(
                            color = Color.White,
                            start = Offset(x, 0f),
                            end = Offset(x, size.height),
                            strokeWidth = 3.dp.toPx(),
                        )
                        drawCircle(color = Color.White, radius = 13.dp.toPx(), center = Offset(x, size.height / 2f))
                        drawCircle(
                            color = Color(0xFF12203A),
                            radius = 11.dp.toPx(),
                            center = Offset(x, size.height / 2f),
                            style = Stroke(width = 2.dp.toPx()),
                        )
                    },
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Drag to compare", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(12.dp))
            Slider(
                value = fraction,
                onValueChange = { fraction = it.coerceIn(0.02f, 0.98f) },
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
fun PhotoThumb(
    model: Any?,
    label: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onLongClick: (() -> Unit)? = null,
    selected: Boolean = false,
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = androidx.compose.foundation.BorderStroke(
            width = if (selected) 3.dp else 1.dp,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
        ),
        modifier = modifier
            .size(132.dp)
            .pointerInput(onClick, onLongClick) {
                detectTapGestures(
                    onTap = { onClick() },
                    onLongPress = { onLongClick?.invoke() },
                )
            },
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            AsyncImage(
                model = model,
                contentDescription = label,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            if (label != null) {
                Surface(
                    color = Color.Black.copy(alpha = 0.6f),
                    shape = MaterialTheme.shapes.extraSmall,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(6.dp),
                ) {
                    Text(
                        label,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    )
                }
            }
        }
    }
}
