package com.fieldflow.pro.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.fieldflow.pro.data.model.Photo
import com.fieldflow.pro.data.photo.PhotoStore
import java.io.File

@Composable
fun rememberThumbnail(photoStore: PhotoStore, photo: Photo?, maxPx: Int = 480): File? {
    var file by remember(photo?.id, maxPx) { mutableStateOf<File?>(null) }
    LaunchedEffect(photo?.id, maxPx) {
        file = photo?.let { runCatching { photoStore.thumbnailFile(it, maxPx) }.getOrNull() }
    }
    return file
}

@Composable
fun rememberDisplayImage(photoStore: PhotoStore, photo: Photo?, maxPx: Int = 1600): File? {
    var file by remember(photo?.id, maxPx) { mutableStateOf<File?>(null) }
    LaunchedEffect(photo?.id, maxPx) {
        file = photo?.let { runCatching { photoStore.displayFile(it) }.getOrNull() }
    }
    return file
}
