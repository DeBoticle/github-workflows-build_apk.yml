package com.fieldflow.pro.ui.nav

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.ui.screens.AboutScreen
import com.fieldflow.pro.ui.screens.AnalyticsScreen
import com.fieldflow.pro.ui.screens.ClientEditScreen
import com.fieldflow.pro.ui.screens.CompareScreen
import com.fieldflow.pro.ui.screens.DiagnosticsScreen
import com.fieldflow.pro.ui.screens.ExportScreen
import com.fieldflow.pro.ui.screens.HomeShell
import com.fieldflow.pro.ui.screens.JobDetailScreen
import com.fieldflow.pro.ui.screens.JobEditorScreen
import com.fieldflow.pro.ui.screens.MarkupScreen
import com.fieldflow.pro.ui.screens.PhotosScreen
import com.fieldflow.pro.ui.screens.QuoteBuilderScreen
import com.fieldflow.pro.ui.screens.SignatureScreen
import com.fieldflow.pro.ui.screens.TemplatesScreen

object Routes {
    const val HOME = "home"
    const val JOB_NEW = "job-new"
    const val JOB_DETAIL = "job/{jobId}"
    const val JOB_EDIT = "job/{jobId}/edit"
    const val JOB_PHOTOS = "job/{jobId}/photos"
    const val JOB_MARKUP = "job/{jobId}/markup/{photoId}"
    const val JOB_COMPARE = "job/{jobId}/compare"
    const val JOB_SIGNATURE = "job/{jobId}/signature"
    const val JOB_QUOTE = "job/{jobId}/quote"
    const val JOB_EXPORT = "job/{jobId}/export"
    const val CLIENT_EDIT = "client-edit/{clientId}"
    const val TEMPLATES = "templates"
    const val ANALYTICS = "analytics"
    const val DIAGNOSTICS = "diagnostics"
    const val ABOUT = "about"

    fun jobDetail(jobId: String) = "job/$jobId"
    fun jobEdit(jobId: String) = "job/$jobId/edit"
    fun jobPhotos(jobId: String) = "job/$jobId/photos"
    fun jobMarkup(jobId: String, photoId: String) = "job/$jobId/markup/$photoId"
    fun jobCompare(jobId: String) = "job/$jobId/compare"
    fun jobSignature(jobId: String) = "job/$jobId/signature"
    fun jobQuote(jobId: String) = "job/$jobId/quote"
    fun jobExport(jobId: String) = "job/$jobId/export"
    fun clientEdit(clientId: String) = "client-edit/$clientId"
}

@Composable
fun AppNav(container: AppContainer) {
    val nav: NavHostController = rememberNavController()
    NavHost(
        navController = nav,
        startDestination = Routes.HOME,
        modifier = Modifier.fillMaxSize(),
    ) {
        composable(Routes.HOME) {
            HomeShell(
                container = container,
                onNewJob = { nav.navigate(Routes.JOB_NEW) },
                onOpenJob = { jobId -> nav.navigate(Routes.jobDetail(jobId)) },
                onNewClient = { nav.navigate(Routes.clientEdit("new")) },
                onOpenClient = { clientId -> nav.navigate(Routes.clientEdit(clientId)) },
                onOpenTemplates = { nav.navigate(Routes.TEMPLATES) },
                onOpenAnalytics = { nav.navigate(Routes.ANALYTICS) },
                onOpenDiagnostics = { nav.navigate(Routes.DIAGNOSTICS) },
                onOpenAbout = { nav.navigate(Routes.ABOUT) },
            )
        }

        composable(Routes.JOB_NEW) {
            JobEditorScreen(
                container = container,
                jobId = null,
                onClose = { nav.popBackStack() },
                onSaved = { jobId ->
                    nav.popBackStack()
                    nav.navigate(Routes.jobDetail(jobId))
                },
            )
        }

        composable(Routes.JOB_EDIT, arguments = listOf(navArgument("jobId") { type = NavType.StringType })) { entry ->
            JobEditorScreen(
                container = container,
                jobId = entry.arguments?.getString("jobId").orEmpty(),
                onClose = { nav.popBackStack() },
                onSaved = { nav.popBackStack() },
            )
        }

        composable(Routes.JOB_DETAIL, arguments = listOf(navArgument("jobId") { type = NavType.StringType })) { entry ->
            val jobId = entry.arguments?.getString("jobId").orEmpty()
            JobDetailScreen(
                container = container,
                jobId = jobId,
                onBack = { nav.popBackStack() },
                onEdit = { nav.navigate(Routes.jobEdit(jobId)) },
                onOpenPhotos = { nav.navigate(Routes.jobPhotos(jobId)) },
                onOpenQuote = { nav.navigate(Routes.jobQuote(jobId)) },
                onOpenSignature = { nav.navigate(Routes.jobSignature(jobId)) },
                onOpenExport = { nav.navigate(Routes.jobExport(jobId)) },
                onDeleted = { nav.popBackStack() },
            )
        }

        composable(Routes.JOB_PHOTOS, arguments = listOf(navArgument("jobId") { type = NavType.StringType })) { entry ->
            val jobId = entry.arguments?.getString("jobId").orEmpty()
            PhotosScreen(
                container = container,
                jobId = jobId,
                onBack = { nav.popBackStack() },
                onMarkup = { photoId -> nav.navigate(Routes.jobMarkup(jobId, photoId)) },
                onCompare = { nav.navigate(Routes.jobCompare(jobId)) },
            )
        }

        composable(
            Routes.JOB_MARKUP,
            arguments = listOf(
                navArgument("jobId") { type = NavType.StringType },
                navArgument("photoId") { type = NavType.StringType },
            ),
        ) { entry ->
            MarkupScreen(
                container = container,
                jobId = entry.arguments?.getString("jobId").orEmpty(),
                photoId = entry.arguments?.getString("photoId").orEmpty(),
                onBack = { nav.popBackStack() },
            )
        }

        composable(Routes.JOB_COMPARE, arguments = listOf(navArgument("jobId") { type = NavType.StringType })) { entry ->
            CompareScreen(
                container = container,
                jobId = entry.arguments?.getString("jobId").orEmpty(),
                onBack = { nav.popBackStack() },
            )
        }

        composable(Routes.JOB_SIGNATURE, arguments = listOf(navArgument("jobId") { type = NavType.StringType })) { entry ->
            SignatureScreen(
                container = container,
                jobId = entry.arguments?.getString("jobId").orEmpty(),
                onBack = { nav.popBackStack() },
            )
        }

        composable(Routes.JOB_QUOTE, arguments = listOf(navArgument("jobId") { type = NavType.StringType })) { entry ->
            QuoteBuilderScreen(
                container = container,
                jobId = entry.arguments?.getString("jobId").orEmpty(),
                onBack = { nav.popBackStack() },
            )
        }

        composable(Routes.JOB_EXPORT, arguments = listOf(navArgument("jobId") { type = NavType.StringType })) { entry ->
            ExportScreen(
                container = container,
                jobId = entry.arguments?.getString("jobId").orEmpty(),
                onBack = { nav.popBackStack() },
            )
        }

        composable(Routes.CLIENT_EDIT, arguments = listOf(navArgument("clientId") { type = NavType.StringType })) { entry ->
            ClientEditScreen(
                container = container,
                clientId = entry.arguments?.getString("clientId").orEmpty(),
                onBack = { nav.popBackStack() },
            )
        }

        composable(Routes.TEMPLATES) {
            TemplatesScreen(container = container, onBack = { nav.popBackStack() })
        }

        composable(Routes.ANALYTICS) {
            AnalyticsScreen(container = container, onBack = { nav.popBackStack() })
        }

        composable(Routes.DIAGNOSTICS) {
            DiagnosticsScreen(container = container, onBack = { nav.popBackStack() })
        }

        composable(Routes.ABOUT) {
            AboutScreen(container = container, onBack = { nav.popBackStack() })
        }
    }
}
