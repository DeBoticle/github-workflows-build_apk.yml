package com.fieldflow.pro.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.fieldflow.pro.BuildConfig
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.ui.components.BigButton
import com.fieldflow.pro.ui.components.FfButtonTone
import com.fieldflow.pro.ui.components.FfScreen
import com.fieldflow.pro.ui.components.InfoBanner
import com.fieldflow.pro.ui.components.SectionCard
import com.fieldflow.pro.ui.components.VSpace

@Composable
fun AboutScreen(
    container: AppContainer,
    onBack: () -> Unit,
) {
    val snackbar = remember { SnackbarHostState() }

    FfScreen(
        title = "About",
        subtitle = "FieldFlow Pro ${BuildConfig.VERSION_NAME}",
        onBack = onBack,
        snackbarHostState = snackbar,
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
            SectionCard {
                Text(
                    "FieldFlow Pro",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    "The job book for one-truck contractors. Jobs, photo evidence, quotes, signatures and PDF packets — online or in a basement with no bars.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                VSpace(10)
                Text(
                    "Version ${BuildConfig.VERSION_NAME} (build 1) · minSdk 26 · targetSdk 35",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            VSpace(12)

            SectionCard(title = "What's inside") {
                listOf(
                    "Job creation: title, client, address, materials, cost",
                    "Camera capture with EXIF fix-up, markup and before/after compare",
                    "Quote builder: labour, materials, fees and discounts that total themselves",
                    "Offline-first: every action writes to the local encrypted vault first",
                    "Background auto-sync with per-change queue and retry backoff",
                    "Client signature capture with SHA-256 hash on the packet",
                    "PDF job packets for sharing, printing or archiving",
                    "Per-trade templates for HVAC, plumbing, electrical and handyman work",
                    "Dark mode and glove mode with oversized touch targets",
                ).forEach { line ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp),
                        verticalAlignment = Alignment.Top,
                    ) {
                        Icon(
                            Icons.Filled.CheckCircle,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                            tint = MaterialTheme.colorScheme.secondary,
                        )
                        Text(
                            line,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(start = 10.dp),
                        )
                    }
                }
            }

            VSpace(12)

            SectionCard(title = "Privacy") {
                Icon(
                    Icons.Filled.Security,
                    contentDescription = null,
                    modifier = Modifier.size(28.dp),
                    tint = MaterialTheme.colorScheme.primary,
                )
                VSpace(8)
                Text(
                    "Jobs, clients, photos and signatures live in an encrypted vault on this device (Android Keystore AES-256-GCM). " +
                        "Nothing is uploaded unless you enable sync and an endpoint is configured. Analytics are opt-in, anonymous and contain no customer data.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            VSpace(12)

            SectionCard(title = "Support") {
                InfoBanner("Support email: ${BuildConfig.SUPPORT_EMAIL}")
                VSpace(10)
                BigButton(
                    text = container.syncModeLabel,
                    subtitle = "Current sync backend",
                    icon = Icons.Filled.Email,
                    tone = FfButtonTone.SECONDARY,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {},
                )
            }

            VSpace(12)

            SectionCard(title = "Third-party notices") {
                Text(
                    "Jetpack Compose, AndroidX, CameraX, WorkManager, Kotlin, kotlinx.serialization, Coil and the AndroidX Credential Manager are used under the Apache License 2.0. " +
                        "FieldFlow Pro is an independent app and is not affiliated with Google LLC.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            VSpace(30)
        }
    }
}
