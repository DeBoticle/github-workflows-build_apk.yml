package com.fieldflow.pro.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.core.Dates
import com.fieldflow.pro.ui.components.BigButton
import com.fieldflow.pro.ui.components.FfButtonTone
import com.fieldflow.pro.ui.components.FfScreen
import com.fieldflow.pro.ui.components.InfoBanner
import com.fieldflow.pro.ui.components.SectionCard
import com.fieldflow.pro.ui.components.StatTile
import com.fieldflow.pro.ui.components.SwitchRow
import com.fieldflow.pro.ui.components.VSpace
import com.fieldflow.pro.ui.theme.FieldFlowGreen
import com.fieldflow.pro.ui.theme.FieldFlowOrange
import kotlinx.coroutines.launch

@Composable
fun AnalyticsScreen(
    container: AppContainer,
    onBack: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val settings by container.settings.settings.collectAsState()
    val events by container.analytics.events.collectAsState()
    val queued = events.count { !it.uploaded }

    FfScreen(
        title = "Analytics",
        subtitle = "Local-first event log",
        onBack = onBack,
        snackbarHostState = snackbar,
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .navigationBarsPadding(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                InfoBanner(
                    "FieldFlow records feature usage locally so you can see exactly what it stores. Job titles, client names, photos and signatures are never included in analytics.",
                )
            }

            item {
                SectionCard(title = "Controls") {
                    SwitchRow(
                        label = "Share anonymous analytics",
                        caption = if (container.analytics.endpointConfigured) {
                            "Uploads to your configured endpoint when online"
                        } else {
                            "No endpoint configured — events stay on this device"
                        },
                        checked = settings.analyticsOptIn,
                        onCheckedChange = { enabled ->
                            scope.launch {
                                container.settings.update { it.copy(analyticsOptIn = enabled) }
                                container.analytics.setOptIn(enabled)
                            }
                        },
                    )
                    VSpace(10)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatTile("Events", events.size.toString(), modifier = Modifier.weight(1f))
                        StatTile("Queued", queued.toString(), modifier = Modifier.weight(1f))
                    }
                    VSpace(12)
                    BigButton(
                        text = "Flush to server",
                        subtitle = if (container.analytics.endpointConfigured) null else "No endpoint configured",
                        icon = Icons.Filled.Upload,
                        tone = FfButtonTone.SECONDARY,
                        enabled = container.analytics.endpointConfigured,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            scope.launch {
                                val sent = container.analytics.flush()
                                snackbar.showSnackbar(if (sent > 0) "Uploaded $sent event(s)" else "Nothing uploaded")
                            }
                        },
                    )
                    VSpace(10)
                    BigButton(
                        text = "Clear uploaded events",
                        icon = Icons.Filled.CloudUpload,
                        tone = FfButtonTone.SECONDARY,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            scope.launch {
                                container.analytics.clearUploaded()
                                snackbar.showSnackbar("Cleared uploaded events")
                            }
                        },
                    )
                    VSpace(10)
                    BigButton(
                        text = "Reset event log",
                        icon = Icons.Filled.Delete,
                        tone = FfButtonTone.DANGER,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            scope.launch {
                                container.analytics.reset()
                                snackbar.showSnackbar("Event log reset")
                            }
                        },
                    )
                }
            }

            item {
                Text(
                    "Recent events",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                )
            }

            if (events.isEmpty()) {
                item {
                    Text(
                        "No events recorded yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                items(events.asReversed(), key = { it.id }) { event ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.surface,
                        shape = MaterialTheme.shapes.small,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = if (event.uploaded) Icons.Filled.CheckCircle else Icons.Filled.Refresh,
                                contentDescription = null,
                                tint = if (event.uploaded) FieldFlowGreen else FieldFlowOrange,
                            )
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(start = 12.dp),
                            ) {
                                Text(
                                    event.name,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                )
                                if (event.params.isNotEmpty()) {
                                    Text(
                                        event.params.entries.joinToString(", ") { "${it.key}=${it.value}" },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                Text(
                                    Dates.formatDateTime(event.at) + if (event.uploaded) " · uploaded" else " · local only",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }

            item { VSpace(24) }
        }
    }
}
