package com.fieldflow.pro.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.data.model.Client
import com.fieldflow.pro.ui.components.BigButton
import com.fieldflow.pro.ui.components.ConfirmDialog
import com.fieldflow.pro.ui.components.FfButtonTone
import com.fieldflow.pro.ui.components.FfScreen
import com.fieldflow.pro.ui.components.FfTextField
import com.fieldflow.pro.ui.components.SectionCard
import com.fieldflow.pro.ui.components.VSpace
import kotlinx.coroutines.launch

@Composable
fun ClientEditScreen(
    container: AppContainer,
    clientId: String,
    onBack: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val isNew = clientId == "new" || clientId.isBlank()

    var loaded by remember(clientId) { mutableStateOf(false) }
    var existing by remember(clientId) { mutableStateOf<Client?>(null) }
    var name by remember(clientId) { mutableStateOf("") }
    var company by remember(clientId) { mutableStateOf("") }
    var phone by remember(clientId) { mutableStateOf("") }
    var email by remember(clientId) { mutableStateOf("") }
    var address by remember(clientId) { mutableStateOf("") }
    var notes by remember(clientId) { mutableStateOf("") }
    var showDelete by remember { mutableStateOf(false) }

    LaunchedEffect(clientId) {
        if (!isNew) {
            val client = container.clients.byId(clientId)
            existing = client
            if (client != null) {
                name = client.name
                company = client.company
                phone = client.phone
                email = client.email
                address = client.address
                notes = client.notes
            }
        }
        loaded = true
    }

    FfScreen(
        title = if (isNew) "New client" else "Edit client",
        subtitle = if (isNew) "Saved encrypted on this device" else existing?.let { "Updated ${com.fieldflow.pro.core.Dates.relative(it.updatedAt)}" },
        onBack = onBack,
        snackbarHostState = snackbar,
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
            SectionCard(title = "Client details") {
                FfTextField(name, { name = it }, "Name")
                VSpace(12)
                FfTextField(company, { company = it }, "Company (optional)")
                VSpace(12)
                FfTextField(phone, { phone = it }, "Phone", keyboardType = androidx.compose.ui.text.input.KeyboardType.Phone)
                VSpace(12)
                FfTextField(email, { email = it }, "Email", keyboardType = androidx.compose.ui.text.input.KeyboardType.Email)
                VSpace(12)
                FfTextField(address, { address = it }, "Site address", singleLine = false, minLines = 2)
                VSpace(12)
                FfTextField(notes, { notes = it }, "Notes", singleLine = false, minLines = 3)
                VSpace(16)
                BigButton(
                    text = if (isNew) "Save client" else "Update client",
                    icon = Icons.Filled.Save,
                    enabled = loaded && name.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        scope.launch {
                            val saved = container.clients.save(
                                (existing ?: Client()).copy(
                                    name = name.trim(),
                                    company = company.trim(),
                                    phone = phone.trim(),
                                    email = email.trim(),
                                    address = address.trim(),
                                    notes = notes.trim(),
                                ),
                            )
                            existing = saved
                            snackbar.showSnackbar("Client saved")
                            if (isNew) onBack()
                        }
                    },
                )
                if (!isNew) {
                    VSpace(10)
                    BigButton(
                        text = "Delete client",
                        subtitle = "Jobs keep their copy of the details",
                        icon = Icons.Filled.Delete,
                        tone = FfButtonTone.DANGER,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { showDelete = true },
                    )
                }
            }
            if (!loaded) {
                VSpace(12)
                Text("Loading…", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            VSpace(24)
        }
    }

    if (showDelete) {
        ConfirmDialog(
            title = "Delete this client?",
            message = "The client is removed from your list. Jobs already created keep the name and address they captured.",
            confirmLabel = "Delete",
            destructive = true,
            onConfirm = {
                showDelete = false
                scope.launch {
                    container.clients.softDelete(clientId)
                    onBack()
                }
            },
            onDismiss = { showDelete = false },
        )
    }
}
