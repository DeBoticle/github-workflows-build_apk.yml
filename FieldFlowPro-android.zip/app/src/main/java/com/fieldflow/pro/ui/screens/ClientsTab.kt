package com.fieldflow.pro.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.core.initials
import com.fieldflow.pro.ui.components.BigButton
import com.fieldflow.pro.ui.components.EmptyState
import com.fieldflow.pro.ui.components.FfButtonTone
import com.fieldflow.pro.ui.components.FfScreen
import com.fieldflow.pro.ui.components.FfTextField
import com.fieldflow.pro.ui.components.VSpace

@Composable
fun ClientsTab(
    container: AppContainer,
    onNewClient: () -> Unit,
    onOpenClient: (String) -> Unit,
) {
    val clients by container.clients.clients.collectAsState()
    val jobs by container.jobs.jobs.collectAsState()
    var query by remember { mutableStateOf("") }
    val snackbar = remember { SnackbarHostState() }

    val filtered = clients.filter { client ->
        if (query.isBlank()) {
            true
        } else {
            val q = query.lowercase()
            client.name.lowercase().contains(q) ||
                client.company.lowercase().contains(q) ||
                client.phone.contains(q) ||
                client.address.lowercase().contains(q) ||
                client.email.lowercase().contains(q)
        }
    }

    FfScreen(
        title = "Clients",
        subtitle = "${clients.size} saved on this device",
        snackbarHostState = snackbar,
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                FfTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = "Search clients",
                    leadingIcon = Icons.Filled.Search,
                )
            }
            item {
                BigButton(
                    text = "New client",
                    subtitle = "Name, phone, address — used on quotes",
                    icon = Icons.Filled.Add,
                    tone = FfButtonTone.SECONDARY,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = onNewClient,
                )
            }

            if (filtered.isEmpty()) {
                item {
                    EmptyState(
                        icon = Icons.Filled.People,
                        title = if (clients.isEmpty()) "No clients yet" else "No matches",
                        message = "Add a client and their details auto-fill on new jobs and quotes.",
                        actionLabel = if (clients.isEmpty()) "Add a client" else null,
                        onAction = if (clients.isEmpty()) onNewClient else null,
                    )
                }
            } else {
                items(filtered, key = { it.id }) { client ->
                    val jobCount = jobs.count { it.clientId == client.id }
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenClient(client.id) },
                        color = MaterialTheme.colorScheme.surface,
                        shape = MaterialTheme.shapes.large,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = MaterialTheme.shapes.small,
                            ) {
                                Box(
                                    modifier = Modifier.size(52.dp),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Text(
                                        client.name.initials(),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    )
                                }
                            }
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(start = 12.dp),
                            ) {
                                Text(
                                    client.name.ifBlank { "Unnamed client" },
                                    style = MaterialTheme.typography.titleMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                if (client.company.isNotBlank()) {
                                    Text(
                                        client.company,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (client.phone.isNotBlank()) {
                                        Icon(
                                            Icons.Filled.Phone,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp),
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                        Text(
                                            " " + client.phone,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                    if (client.email.isNotBlank()) {
                                        Icon(
                                            Icons.Filled.Email,
                                            contentDescription = null,
                                            modifier = Modifier
                                                .padding(start = 10.dp)
                                                .size(14.dp),
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                }
                                if (client.address.isNotBlank()) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Filled.Place,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp),
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                        Text(
                                            " " + client.address,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                    }
                                }
                            }
                            Text(
                                "$jobCount job(s)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }
                }
            }
            item { VSpace(20) }
        }
    }
}
