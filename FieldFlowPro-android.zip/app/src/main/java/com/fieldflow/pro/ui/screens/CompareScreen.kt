package com.fieldflow.pro.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.data.model.Photo
import com.fieldflow.pro.data.model.PhotoKind
import com.fieldflow.pro.ui.components.BeforeAfterSlider
import com.fieldflow.pro.ui.components.BigButton
import com.fieldflow.pro.ui.components.FfButtonTone
import com.fieldflow.pro.ui.components.FfScreen
import com.fieldflow.pro.ui.components.InfoBanner
import com.fieldflow.pro.ui.components.PhotoThumb
import com.fieldflow.pro.ui.components.SectionCard
import com.fieldflow.pro.ui.components.VSpace
import com.fieldflow.pro.ui.components.rememberDisplayImage
import com.fieldflow.pro.ui.components.rememberThumbnail

@Composable
fun CompareScreen(
    container: AppContainer,
    jobId: String,
    onBack: () -> Unit,
) {
    val snackbar = remember { SnackbarHostState() }
    val photos by container.photos.observeForJob(jobId).collectAsState(initial = emptyList())
    var beforeId by remember { mutableStateOf<String?>(null) }
    var afterId by remember { mutableStateOf<String?>(null) }

    val before = photos.firstOrNull { it.id == beforeId } ?: photos.lastOrNull { it.kind == PhotoKind.BEFORE }
    val after = photos.firstOrNull { it.id == afterId } ?: photos.lastOrNull { it.kind == PhotoKind.AFTER }
    val beforeFile = rememberDisplayImage(container.photoStore, before)
    val afterFile = rememberDisplayImage(container.photoStore, after)

    FfScreen(
        title = "Before / after",
        subtitle = "${photos.count { it.kind == PhotoKind.BEFORE }} before · ${photos.count { it.kind == PhotoKind.AFTER }} after",
        onBack = onBack,
        snackbarHostState = snackbar,
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .navigationBarsPadding(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (before == null || after == null) {
                item {
                    InfoBanner(
                        "You need at least one Before photo and one After photo. Capture them from the Photos screen, then come back here.",
                        tone = com.fieldflow.pro.ui.components.BannerTone.WARNING,
                    )
                }
            }

            item {
                SectionCard(title = "Slider") {
                    BeforeAfterSlider(
                        beforeModel = beforeFile,
                        afterModel = afterFile,
                        beforeLabel = "BEFORE",
                        afterLabel = "AFTER",
                    )
                    VSpace(8)
                    Text(
                        "Before: ${before?.caption.orEmpty().ifBlank { before?.kind?.displayName ?: "—" }}  ·  " +
                            "After: ${after?.caption.orEmpty().ifBlank { after?.kind?.displayName ?: "—" }}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    VSpace(10)
                    BigButton(
                        text = "Swap sides",
                        icon = Icons.Filled.SwapHoriz,
                        tone = FfButtonTone.SECONDARY,
                        enabled = before != null && after != null,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            val previousBefore = beforeId
                            beforeId = afterId
                            afterId = previousBefore
                        },
                    )
                }
            }

            item {
                SectionCard(title = "Choose the before photo") {
                    PhotoPickerRow(
                        container = container,
                        photos = photos,
                        selectedId = before?.id,
                        emptyMessage = "No photos captured yet.",
                        onSelect = { beforeId = it.id },
                    )
                }
            }

            item {
                SectionCard(title = "Choose the after photo") {
                    PhotoPickerRow(
                        container = container,
                        photos = photos,
                        selectedId = after?.id,
                        emptyMessage = "No photos captured yet.",
                        onSelect = { afterId = it.id },
                    )
                }
            }

            item {
                SectionCard {
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        androidx.compose.material3.Icon(
                            Icons.Filled.Compare,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                        )
                        Text(
                            "Both photos are included in the PDF packet, side by side.",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(start = 10.dp),
                        )
                    }
                }
            }

            item { VSpace(30) }
        }
    }
}

@Composable
private fun PhotoPickerRow(
    container: AppContainer,
    photos: List<Photo>,
    selectedId: String?,
    emptyMessage: String,
    onSelect: (Photo) -> Unit,
) {
    if (photos.isEmpty()) {
        Text(
            emptyMessage,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        return
    }
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        items(photos.size) { index ->
            val photo = photos[index]
            PhotoThumb(
                model = rememberThumbnail(container.photoStore, photo, 240),
                label = photo.kind.displayName,
                onClick = { onSelect(photo) },
                selected = photo.id == selectedId,
            )
        }
    }
}
