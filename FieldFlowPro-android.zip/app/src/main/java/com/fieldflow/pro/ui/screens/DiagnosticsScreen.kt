package com.fieldflow.pro.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.fieldflow.pro.BuildConfig
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.core.Bytes
import com.fieldflow.pro.core.Dates
import com.fieldflow.pro.ui.components.BigButton
import com.fieldflow.pro.ui.components.FfButtonTone
import com.fieldflow.pro.ui.components.FfScreen
import com.fieldflow.pro.ui.components.KeyValueRow
import com.fieldflow.pro.ui.components.SectionCard
import com.fieldflow.pro.ui.components.StatTile
import com.fieldflow.pro.ui.components.VSpace
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun DiagnosticsScreen(
    container: AppContainer,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val syncState by container.sync.state.collectAsState()
    val queuePending by container.queue.pendingCount.collectAsState()
    val failedOps by container.queue.failedCount.collectAsState()
    val jobs by container.jobs.jobs.collectAsState()
    val photos by container.photos.photos.collectAsState()
    val signatures by container.signatures.signatures.collectAsState()
    val settings by container.settings.settings.collectAsState()
    val device by container.settings.device.collectAsState()

    var tick by remember { mutableStateOf(0) }
    val cameraGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    val pendingOps = remember(tick) { container.queue.operations.value }
    val logText = remember(tick) { container.logger.asText() }

    fun copyLog() {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboard?.setPrimaryClip(ClipData.newPlainText("FieldFlow diagnostics", logText))
        scope.launch { snackbar.showSnackbar("Diagnostics copied") }
    }

    fun shareLog() {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "FieldFlow Pro diagnostics")
            putExtra(Intent.EXTRA_TEXT, logText)
        }
        runCatching { context.startActivity(Intent.createChooser(intent, "Share diagnostics")) }
            .onFailure { scope.launch { snackbar.showSnackbar("No app available to share") } }
    }

    FfScreen(
        title = "Diagnostics",
        subtitle = "Everything the app knows about itself",
        onBack = onBack,
        snackbarHostState = snackbar,
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
            SectionCard(title = "Build") {
                KeyValueRow("App", "FieldFlow Pro ${BuildConfig.VERSION_NAME}")
                KeyValueRow("Package", context.packageName)
                KeyValueRow("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                KeyValueRow("Device", "${Build.MANUFACTURER} ${Build.MODEL}")
                KeyValueRow("Device id", device.deviceId.take(18) + "…")
                KeyValueRow("Camera permission", if (cameraGranted) "granted" else "not granted")
                KeyValueRow("Locale", Locale.getDefault().toString())
            }

            VSpace(12)

            SectionCard(title = "Sync") {
                KeyValueRow("Endpoint", container.syncModeLabel)
                KeyValueRow("Status", if (syncState.isSyncing) "syncing" else if (syncState.online) "online" else "offline")
                KeyValueRow("Waiting", queuePending.toString())
                KeyValueRow("Failed", failedOps.toString())
                KeyValueRow("Last sync", Dates.relative(settings.lastSyncAt))
                KeyValueRow("Last result", syncState.lastMessage.ifBlank { "—" })
                if (settings.lastSyncError.isNotBlank()) {
                    KeyValueRow("Last error", settings.lastSyncError)
                }
                VSpace(10)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BigButton(
                        text = "Sync now",
                        icon = Icons.Filled.Sync,
                        loading = syncState.isSyncing,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            scope.launch {
                                val outcome = container.syncNow("diagnostics")
                                snackbar.showSnackbar(
                                    when (outcome) {
                                        is com.fieldflow.pro.data.sync.SyncOutcome.Success -> "Synced"
                                        com.fieldflow.pro.data.sync.SyncOutcome.Offline -> "Offline"
                                        com.fieldflow.pro.data.sync.SyncOutcome.NothingToDo -> "Nothing to do"
                                        is com.fieldflow.pro.data.sync.SyncOutcome.Failure -> outcome.message
                                    },
                                )
                                tick++
                            }
                        },
                    )
                    BigButton(
                        text = "Refresh",
                        icon = Icons.Filled.Refresh,
                        tone = FfButtonTone.SECONDARY,
                        modifier = Modifier.weight(1f),
                        onClick = { tick++ },
                    )
                }
            }

            VSpace(12)

            SectionCard(title = "Storage") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile("Jobs", jobs.size.toString(), modifier = Modifier.weight(1f))
                    StatTile("Photos", photos.size.toString(), modifier = Modifier.weight(1f))
                }
                VSpace(8)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile("Signatures", signatures.size.toString(), modifier = Modifier.weight(1f))
                    StatTile("Media", Bytes.human(container.photoStore.vaultBytes()), modifier = Modifier.weight(1f))
                }
                VSpace(8)
                KeyValueRow("Vault files", container.vault.files().size.toString())
                KeyValueRow("Vault size", Bytes.human(container.vault.sizeBytes()))
                KeyValueRow("Analytics queued", container.analytics.queueSize.toString())
                VSpace(10)
                BigButton(
                    text = "Clear decrypted image cache",
                    icon = Icons.Filled.Delete,
                    tone = FfButtonTone.SECONDARY,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        val removed = container.photoStore.clearPreviews()
                        scope.launch { snackbar.showSnackbar("Cleared $removed cached file(s)") }
                        tick++
                    },
                )
            }

            VSpace(12)

            SectionCard(title = "Sync queue", subtitle = "${pendingOps.size} operation(s)") {
                if (pendingOps.isEmpty()) {
                    Text(
                        "Queue is empty — every change has been uploaded.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    pendingOps.take(20).forEach { op ->
                        KeyValueRow(
                            label = "${op.entityType}/${op.entityId.take(10)}",
                            value = "${op.op} · tries ${op.attempts}" +
                                if (op.lastError.isBlank()) "" else " · ${op.lastError.take(40)}",
                        )
                    }
                }
            }

            VSpace(12)

            SectionCard(title = "Log", subtitle = "${container.logger.recent().size} line(s) buffered") {
                Text(
                    text = logText.lines().takeLast(80).joinToString("\n").ifBlank { "No log entries yet." },
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.shapes.small)
                        .padding(10.dp),
                )
                VSpace(10)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BigButton(
                        text = "Copy",
                        icon = Icons.Filled.Refresh,
                        tone = FfButtonTone.SECONDARY,
                        modifier = Modifier.weight(1f),
                        onClick = { copyLog() },
                    )
                    BigButton(
                        text = "Share",
                        icon = Icons.Filled.Share,
                        tone = FfButtonTone.SECONDARY,
                        modifier = Modifier.weight(1f),
                        onClick = { shareLog() },
                    )
                }
                VSpace(10)
                BigButton(
                    text = "Clear log",
                    icon = Icons.Filled.Delete,
                    tone = FfButtonTone.DANGER,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        container.logger.clear()
                        tick++
                        scope.launch { snackbar.showSnackbar("Log cleared") }
                    },
                )
            }

            VSpace(30)
        }
    }
}
