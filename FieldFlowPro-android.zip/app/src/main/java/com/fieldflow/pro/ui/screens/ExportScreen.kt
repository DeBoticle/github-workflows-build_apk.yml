package com.fieldflow.pro.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.core.Bytes
import com.fieldflow.pro.core.Dates
import com.fieldflow.pro.core.Money
import com.fieldflow.pro.core.analytics.AnalyticsEvents
import com.fieldflow.pro.core.errorOrNull
import com.fieldflow.pro.core.valueOrNull
import com.fieldflow.pro.data.model.Client
import com.fieldflow.pro.data.model.Photo
import com.fieldflow.pro.data.model.PhotoKind
import com.fieldflow.pro.data.model.Quote
import com.fieldflow.pro.data.model.Signature
import com.fieldflow.pro.ui.components.BannerTone
import com.fieldflow.pro.ui.components.BigButton
import com.fieldflow.pro.ui.components.FfButtonTone
import com.fieldflow.pro.ui.components.FfScreen
import com.fieldflow.pro.ui.components.InfoBanner
import com.fieldflow.pro.ui.components.KeyValueRow
import com.fieldflow.pro.ui.components.LoadingDots
import com.fieldflow.pro.ui.components.SectionCard
import com.fieldflow.pro.ui.components.TotalRow
import com.fieldflow.pro.ui.components.VSpace
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun ExportScreen(
    container: AppContainer,
    jobId: String,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val job by container.jobs.observe(jobId).collectAsState(initial = null)
    val photos by container.photos.observeForJob(jobId).collectAsState(initial = emptyList())
    val signature by container.signatures.observeForJob(jobId).collectAsState(initial = null)
    val quotes by container.quotes.observeForJob(jobId).collectAsState(initial = emptyList())
    val settings by container.settings.settings.collectAsState()
    val pendingSync by container.queue.pendingCount.collectAsState()

    var client by remember(jobId) { mutableStateOf<Client?>(null) }
    var building by remember { mutableStateOf(false) }
    var packet by remember(jobId) { mutableStateOf<File?>(null) }
    var errorText by remember(jobId) { mutableStateOf<String?>(null) }

    LaunchedEffect(jobId, job?.clientId) {
        val clientId = job?.clientId
        client = if (clientId.isNullOrBlank()) null else container.clients.byId(clientId)
    }

    fun notify(message: String) {
        scope.launch { snackbar.showSnackbar(message) }
    }

    val current = job
    if (current == null) {
        FfScreen(title = "Job packet", onBack = onBack, snackbarHostState = snackbar) { padding ->
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Loading job…", style = MaterialTheme.typography.bodyMedium)
            }
        }
        return
    }

    val latestQuote: Quote? = quotes.maxByOrNull { it.updatedAt }
    val evidence: List<Photo> = photos.filter { it.kind != PhotoKind.MARKUP }
    val beforeCount = photos.count { it.kind == PhotoKind.BEFORE }
    val afterCount = photos.count { it.kind == PhotoKind.AFTER }
    val signatureValue: Signature? = signature

    fun build() {
        building = true
        errorText = null
        scope.launch {
            val result = container.packetExporter.buildPacket(
                job = current,
                client = client,
                quote = latestQuote,
                jobPhotos = photos,
                signature = signatureValue,
                settings = settings,
            )
            building = false
            val file = result.valueOrNull()
            if (file != null) {
                packet = file
                container.analytics.log(
                    AnalyticsEvents.PDF_EXPORTED,
                    mapOf(
                        "job_id" to current.id,
                        "photos" to photos.size,
                        "bytes" to file.length(),
                        "signed" to (signatureValue != null),
                        "quote" to (latestQuote != null),
                    ),
                )
                notify("Packet ready — ${Bytes.human(file.length())}")
            } else {
                errorText = result.errorOrNull()?.userMessage() ?: "Could not build the PDF packet."
            }
        }
    }

    fun open(file: File) {
        val intent = container.packetExporter.openIntent(file)
        runCatching { context.startActivity(intent) }
            .onFailure { notify("No PDF viewer on this device — try Share instead") }
    }

    fun share(file: File) {
        val intent = container.packetExporter.shareIntent(file, current)
        runCatching { context.startActivity(intent) }
            .onFailure { notify("Nothing available to share with") }
    }

    FfScreen(
        title = "Job packet",
        subtitle = "${current.number} · ${current.title.ifBlank { "Untitled job" }}",
        onBack = onBack,
        snackbarHostState = snackbar,
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            ) {
                TotalRow("Job total", Money.format(current.totalCents, settings.currencyCode))
                VSpace(8)
                BigButton(
                    text = if (packet == null) "Build PDF packet" else "Rebuild PDF packet",
                    subtitle = "Works offline — no internet needed",
                    icon = Icons.Filled.PictureAsPdf,
                    loading = building,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { build() },
                )
            }
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (errorText != null) {
                item {
                    InfoBanner(
                        text = errorText.orEmpty(),
                        tone = BannerTone.DANGER,
                        actionLabel = "Retry",
                        onAction = { build() },
                    )
                }
            }

            if (building) {
                item {
                    SectionCard(title = "Building packet") {
                        LoadingDots("Loading photos, quote, signature and totals…")
                        VSpace(10)
                        Text(
                            "Large photo sets can take a few seconds. Nothing is uploaded — the PDF is written to this device.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            packet?.let { file ->
                item {
                    SectionCard(
                        title = "Packet ready",
                        subtitle = "${file.name} · ${Bytes.human(file.length())}",
                    ) {
                        KeyValueRow("File", file.name)
                        KeyValueRow("Size", Bytes.human(file.length()))
                        KeyValueRow("Saved", Dates.relative(file.lastModified()))
                        VSpace(12)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            BigButton(
                                text = "Open",
                                icon = Icons.Filled.OpenInNew,
                                modifier = Modifier.weight(1f),
                                onClick = { open(file) },
                            )
                            BigButton(
                                text = "Share",
                                icon = Icons.Filled.Share,
                                tone = FfButtonTone.SECONDARY,
                                modifier = Modifier.weight(1f),
                                onClick = { share(file) },
                            )
                        }
                        VSpace(10)
                        InfoBanner(
                            text = "Share to email, Messages, Drive or a print app. The file lives in the app's export folder.",
                            tone = BannerTone.SUCCESS,
                        )
                    }
                }
            }

            item {
                SectionCard(title = "What goes in") {
                    KeyValueRow("Job detail", current.title.ifBlank { "Untitled job" })
                    KeyValueRow("Customer", current.clientName.ifBlank { client?.name.orEmpty() }.ifBlank { "—" })
                    KeyValueRow("Site address", current.address.ifBlank { client?.address.orEmpty() }.ifBlank { "—" })
                    KeyValueRow("Trade", current.trade.displayName)
                    KeyValueRow("Status", current.status.displayName)
                    KeyValueRow("Scheduled", current.scheduledLabel)
                    VSpace(8)
                    KeyValueRow("Photos", "${evidence.size} regular · ${photos.size} total")
                    KeyValueRow("Before / after pairs", if (beforeCount > 0 && afterCount > 0) minOf(beforeCount, afterCount).toString() else "none")
                    KeyValueRow("Quote", latestQuote?.let { "${it.number} (${it.status.displayName})" } ?: "not attached")
                    KeyValueRow("Signature", signatureValue?.signerName ?: "not signed")
                    KeyValueRow("Terms", if (signatureValue?.acceptedTerms == true) "accepted (${signatureValue?.termsVersion})" else "not accepted")
                    VSpace(8)
                    KeyValueRow("Materials", Money.format(current.materialsTotalCents, settings.currencyCode))
                    KeyValueRow("Labour", Money.format(current.labourTotalCents, settings.currencyCode))
                    KeyValueRow("Tax", Money.format(current.taxCents, settings.currencyCode))
                    KeyValueRow("Total", Money.format(current.totalCents, settings.currencyCode), emphasis = true)
                }
            }

            if (evidence.isEmpty() || signatureValue == null) {
                item {
                    SectionCard(title = "Finish the packet first") {
                        if (evidence.isEmpty()) {
                            InfoBanner(
                                text = "No photos on this job yet. Capture at least one before/after pair so the customer can see the work.",
                                tone = BannerTone.WARNING,
                            )
                            VSpace(10)
                        }
                        if (signatureValue == null) {
                            InfoBanner(
                                text = "No signature captured. You can still export, but Play-store customers expect a signed acceptance page.",
                                tone = BannerTone.WARNING,
                            )
                        }
                    }
                }
            }

            item {
                SectionCard(
                    title = "Offline first",
                    subtitle = "Sync: ${container.syncModeLabel}",
                ) {
                    Text(
                        "The PDF is generated entirely on this device from your encrypted vault — no network call and no account needed. " +
                            "Any changes you made while offline are queued and upload automatically once you're back online.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    VSpace(10)
                    KeyValueRow("Last sync", Dates.relative(settings.lastSyncAt))
                    KeyValueRow("Pending changes", pendingSync.toString())
                }
            }

            item { VSpace(90) }
        }
    }
}
