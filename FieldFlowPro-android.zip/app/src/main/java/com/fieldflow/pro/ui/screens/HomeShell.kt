package com.fieldflow.pro.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.fieldflow.pro.core.AppContainer

@Composable
fun HomeShell(
    container: AppContainer,
    onNewJob: () -> Unit,
    onOpenJob: (String) -> Unit,
    onNewClient: () -> Unit,
    onOpenClient: (String) -> Unit,
    onOpenTemplates: () -> Unit,
    onOpenAnalytics: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    onOpenAbout: () -> Unit,
) {
    var tab by rememberSaveable { mutableStateOf(0) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
            ) {
                TabItem(0, tab, "Home", Icons.Filled.Home) { tab = 0 }
                TabItem(1, tab, "Jobs", Icons.Filled.Work) { tab = 1 }
                TabItem(2, tab, "Clients", Icons.Filled.People) { tab = 2 }
                TabItem(3, tab, "Settings", Icons.Filled.Settings) { tab = 3 }
            }
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            when (tab) {
                0 -> HomeTab(
                    container = container,
                    onNewJob = onNewJob,
                    onOpenJob = onOpenJob,
                    onOpenTemplates = onOpenTemplates,
                    onOpenDiagnostics = onOpenDiagnostics,
                )

                1 -> JobsTab(
                    container = container,
                    onNewJob = onNewJob,
                    onOpenJob = onOpenJob,
                )

                2 -> ClientsTab(
                    container = container,
                    onNewClient = onNewClient,
                    onOpenClient = onOpenClient,
                )

                else -> SettingsTab(
                    container = container,
                    onOpenTemplates = onOpenTemplates,
                    onOpenAnalytics = onOpenAnalytics,
                    onOpenDiagnostics = onOpenDiagnostics,
                    onOpenAbout = onOpenAbout,
                )
            }
        }
    }
}

@Composable
private fun TabItem(
    index: Int,
    selected: Int,
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
) {
    NavigationBarItem(
        selected = selected == index,
        onClick = onClick,
        icon = {
            Icon(
                icon,
                contentDescription = label,
                modifier = Modifier.padding(2.dp),
            )
        },
        label = { Text(label, style = MaterialTheme.typography.labelSmall) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = MaterialTheme.colorScheme.onPrimary,
            selectedTextColor = MaterialTheme.colorScheme.primary,
            indicatorColor = MaterialTheme.colorScheme.primary,
        ),
    )
}
