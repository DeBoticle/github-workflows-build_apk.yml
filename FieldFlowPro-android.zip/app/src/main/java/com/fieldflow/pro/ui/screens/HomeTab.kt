package com.fieldflow.pro.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.core.Bytes
import com.fieldflow.pro.core.Dates
import com.fieldflow.pro.core.Money
import com.fieldflow.pro.data.model.SyncState
import com.fieldflow.pro.ui.components.BigButton
import com.fieldflow.pro.ui.components.FfButtonTone
import com.fieldflow.pro.ui.components.FfScreen
import com.fieldflow.pro.ui.components.JobRow
import com.fieldflow.pro.ui.components.OfflineBanner
import com.fieldflow.pro.ui.components.SectionCard
import com.fieldflow.pro.ui.components.StatTile
import com.fieldflow.pro.ui.components.SyncStatusPill
import com.fieldflow.pro.ui.components.VSpace
import kotlinx.coroutines.launch

@Composable
fun HomeTab(
    container: AppContainer,
    onNewJob: () -> Unit,
    onOpenJob: (String) -> Unit,
    onOpenTemplates: () -> Unit,
    onOpenDiagnostics: () -> Unit,
) {
    val jobs by container.jobs.jobs.collectAsState()
    val allQuotes by container.quotes.quotes.collectAsState()
    val allPhotos by container.photos.photos.collectAsState()
    val settings by container.settings.settings.collectAsState()
    val syncState by container.sync.state.collectAsState()
    val queuePending by container.queue.pendingCount.collectAsState()

    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    val openJobs = jobs.filter { it.isOpen }
    val todayStart = Dates.todayStart()
    val todayEnd = Dates.endOfDay(todayStart)
    val todaysJobs = openJobs.filter { it.scheduledAt in todayStart..todayEnd }
    val quotedValue = allQuotes.filter { it.status.name != "DECLINED" }.sumOf { it.totalCents }
    val vaultBytes = container.photoStore.vaultBytes()

    FfScreen(
        title = settings.businessName.ifBlank { "FieldFlow Pro" },
        subtitle = if (todaysJobs.isNotEmpty()) {
            "${todaysJobs.size} job(s) scheduled today"
        } else {
            "Offline-ready · ${settings.defaultTrade.displayName} default"
        },
        snackbarHostState = snackbar,
        actions = {
            SyncStatusPill(
                state = if (syncState.isSyncing) SyncState.SYNCING else if (syncState.failedOps > 0) SyncState.FAILED else SyncState.SYNCED,
                pendingCount = queuePending,
                online = syncState.online,
                onClick = {
                    scope.launch {
                        val outcome = container.syncNow("home-pill")
                        snackbar.showSnackbar(
                            when (outcome) {
                                is com.fieldflow.pro.data.sync.SyncOutcome.Success -> "Synced: ${outcome.pushed} up, ${outcome.pulled} down"
                                com.fieldflow.pro.data.sync.SyncOutcome.Offline -> "Still offline — changes stay on this device"
                                com.fieldflow.pro.data.sync.SyncOutcome.NothingToDo -> "Nothing to sync right now"
                                is com.fieldflow.pro.data.sync.SyncOutcome.Failure -> outcome.message
                            },
                        )
                    }
                },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                OfflineBanner(
                    online = syncState.online,
                    pendingCount = queuePending,
                    syncing = syncState.isSyncing,
                    onSyncNow = {
                        scope.launch {
                            val outcome = container.syncNow("banner")
                            if (outcome is com.fieldflow.pro.data.sync.SyncOutcome.Failure) {
                                snackbar.showSnackbar(outcome.message)
                            }
                        }
                    },
                )
            }

            item {
                BigButton(
                    text = "New job",
                    subtitle = "Title, client, address, materials, photos",
                    icon = Icons.Filled.Add,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = onNewJob,
                )
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile("Open jobs", openJobs.size.toString(), modifier = Modifier.weight(1f))
                    StatTile("Today", todaysJobs.size.toString(), modifier = Modifier.weight(1f))
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(
                        "Quoted",
                        Money.format(quotedValue, settings.currencyCode),
                        caption = "${allQuotes.size} quote(s)",
                        modifier = Modifier.weight(1f),
                    )
                    StatTile(
                        "Photos",
                        allPhotos.size.toString(),
                        caption = Bytes.human(vaultBytes),
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            item {
                SectionCard(title = "Quick actions") {
                    BigButton(
                        text = "Job templates",
                        subtitle = "HVAC · Plumbing · Electrical · Handyman",
                        icon = Icons.Filled.Description,
                        tone = FfButtonTone.SECONDARY,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onOpenTemplates,
                    )
                    VSpace(10)
                    BigButton(
                        text = "Sync now",
                        subtitle = container.syncModeLabel,
                        icon = Icons.Filled.Sync,
                        tone = FfButtonTone.SECONDARY,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            scope.launch {
                                val outcome = container.syncNow("quick-action")
                                snackbar.showSnackbar(
                                    when (outcome) {
                                        is com.fieldflow.pro.data.sync.SyncOutcome.Success -> "Synced ${outcome.pushed} change(s)"
                                        com.fieldflow.pro.data.sync.SyncOutcome.Offline -> "Offline — nothing left behind"
                                        com.fieldflow.pro.data.sync.SyncOutcome.NothingToDo -> "Already in sync"
                                        is com.fieldflow.pro.data.sync.SyncOutcome.Failure -> outcome.message
                                    },
                                )
                            }
                        },
                    )
                    VSpace(10)
                    BigButton(
                        text = "Diagnostics",
                        subtitle = "Logs, storage, sync queue",
                        icon = Icons.Filled.BugReport,
                        tone = FfButtonTone.SECONDARY,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onOpenDiagnostics,
                    )
                }
            }

            item {
                Text(
                    "Open work",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }

            if (openJobs.isEmpty()) {
                item {
                    SectionCard {
                        Text(
                            "No open jobs. Tap New job and you'll have a quote-ready record in under a minute.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        VSpace(10)
                        BigButton(
                            text = "Start from a template",
                            icon = Icons.Filled.People,
                            tone = FfButtonTone.SECONDARY,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = onOpenTemplates,
                        )
                    }
                }
            } else {
                items(openJobs, key = { it.id }) { job ->
                    JobRow(job = job, currency = settings.currencyCode, onClick = { onOpenJob(job.id) })
                }
            }

            item {
                Box(modifier = Modifier.padding(bottom = 20.dp)) {
                    Text(
                        "End of list",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
