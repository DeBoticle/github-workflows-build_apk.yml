package com.fieldflow.pro.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.core.Dates
import com.fieldflow.pro.core.Money
import com.fieldflow.pro.data.model.JobStatus
import com.fieldflow.pro.data.model.PhotoKind
import com.fieldflow.pro.ui.components.BigButton
import com.fieldflow.pro.ui.components.ConfirmDialog
import com.fieldflow.pro.ui.components.FfButtonTone
import com.fieldflow.pro.ui.components.FfScreen
import com.fieldflow.pro.ui.components.InfoBanner
import com.fieldflow.pro.ui.components.KeyValueRow
import com.fieldflow.pro.ui.components.PhotoThumb
import com.fieldflow.pro.ui.components.RowButton
import com.fieldflow.pro.ui.components.SectionCard
import com.fieldflow.pro.ui.components.StatusPill
import com.fieldflow.pro.ui.components.TotalRow
import com.fieldflow.pro.ui.components.VSpace
import com.fieldflow.pro.ui.components.rememberThumbnail
import com.fieldflow.pro.ui.components.tint
import kotlinx.coroutines.launch

@Composable
fun JobDetailScreen(
    container: AppContainer,
    jobId: String,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onOpenPhotos: () -> Unit,
    onOpenQuote: () -> Unit,
    onOpenSignature: () -> Unit,
    onOpenExport: () -> Unit,
    onDeleted: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val job by container.jobs.observe(jobId).collectAsState(initial = null)
    val photos by container.photos.observeForJob(jobId).collectAsState(initial = emptyList())
    val signature by container.signatures.observeForJob(jobId).collectAsState(initial = null)
    val quotes by container.quotes.observeForJob(jobId).collectAsState(initial = emptyList())
    val settings by container.settings.settings.collectAsState()
    var showDelete by remember { mutableStateOf(false) }

    fun notify(message: String) {
        scope.launch { snackbar.showSnackbar(message) }
    }

    val current = job
    if (current == null) {
        FfScreen(title = "Job", onBack = onBack, snackbarHostState = snackbar) { padding ->
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Loading job…", style = MaterialTheme.typography.bodyMedium)
            }
        }
        return
    }

    val latestQuote = quotes.maxByOrNull { it.updatedAt }
    val beforeCount = photos.count { it.kind == PhotoKind.BEFORE }
    val afterCount = photos.count { it.kind == PhotoKind.AFTER }

    FfScreen(
        title = current.title.ifBlank { "Untitled job" },
        subtitle = "${current.number} · ${current.trade.displayName} · ${current.scheduledLabel}",
        onBack = onBack,
        snackbarHostState = snackbar,
        actions = {
            StatusPill(current.status.displayName, current.status.tint())
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .navigationBarsPadding(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                TotalRow(
                    label = "Job total",
                    value = Money.format(current.totalCents, settings.currencyCode),
                )
            }

            item {
                SectionCard(title = "Customer and site") {
                    KeyValueRow("Client", current.clientName.ifBlank { "—" })
                    if (current.clientPhone.isNotBlank()) KeyValueRow("Phone", current.clientPhone)
                    KeyValueRow("Address", current.address.ifBlank { "—" })
                    VSpace(10)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        RowButton(
                            text = "Call",
                            icon = Icons.Filled.Phone,
                            enabled = current.clientPhone.isNotBlank(),
                            modifier = Modifier.weight(1f),
                            onClick = {
                                val uri = Uri.parse("tel:" + current.clientPhone.filter { it.isDigit() || it == '+' })
                                runCatching { context.startActivity(Intent(Intent.ACTION_DIAL, uri)) }
                                    .onFailure { notify("No dialler available") }
                            },
                        )
                        RowButton(
                            text = "Maps",
                            icon = Icons.Filled.Place,
                            enabled = current.address.isNotBlank(),
                            modifier = Modifier.weight(1f),
                            onClick = {
                                val uri = Uri.parse("geo:0,0?q=" + Uri.encode(current.address))
                                runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                                    .onFailure { notify("No maps app available") }
                            },
                        )
                    }
                    if (current.description.isNotBlank()) {
                        VSpace(10)
                        Text(current.description, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            item {
                SectionCard(
                    title = "Evidence",
                    subtitle = "$beforeCount before · $afterCount after · ${photos.size} total",
                ) {
                    if (photos.isEmpty()) {
                        InfoBanner("No photos yet. Capture a before shot before you start work.")
                        VSpace(10)
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            photos.take(3).forEach { photo ->
                                PhotoThumb(
                                    model = rememberThumbnail(container.photoStore, photo, 320),
                                    label = photo.kind.displayName,
                                    onClick = onOpenPhotos,
                                )
                            }
                        }
                        VSpace(12)
                    }
                    BigButton(
                        text = "Photos, camera and markup",
                        subtitle = "Capture · draw · before-after slider",
                        icon = Icons.Filled.CameraAlt,
                        tone = FfButtonTone.SECONDARY,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onOpenPhotos,
                    )
                    VSpace(10)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        BigButton(
                            text = "Compare",
                            icon = Icons.Filled.Compare,
                            tone = FfButtonTone.SECONDARY,
                            enabled = beforeCount > 0 && afterCount > 0,
                            modifier = Modifier.weight(1f),
                            onClick = onOpenPhotos,
                        )
                        BigButton(
                            text = "Markup",
                            icon = Icons.Filled.Draw,
                            tone = FfButtonTone.SECONDARY,
                            enabled = photos.isNotEmpty(),
                            modifier = Modifier.weight(1f),
                            onClick = onOpenPhotos,
                        )
                    }
                }
            }

            item {
                SectionCard(
                    title = "Quote",
                    subtitle = latestQuote?.let { "${it.number} · ${it.status.displayName}" } ?: "No quote yet",
                ) {
                    if (latestQuote != null) {
                        KeyValueRow("Subtotal", Money.format(latestQuote.subtotalCents, settings.currencyCode))
                        KeyValueRow("Tax", Money.format(latestQuote.taxCents, settings.currencyCode))
                        KeyValueRow("Total", Money.format(latestQuote.totalCents, settings.currencyCode), emphasis = true)
                        KeyValueRow("Valid until", if (latestQuote.validUntil == 0L) "—" else Dates.formatDate(latestQuote.validUntil))
                        VSpace(10)
                    } else {
                        InfoBanner("Build a quote from a trade template — totals calculate themselves.")
                        VSpace(10)
                    }
                    BigButton(
                        text = if (latestQuote == null) "Build a quote" else "Edit quote",
                        icon = Icons.Filled.ReceiptLong,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onOpenQuote,
                    )
                }
            }

            item {
                SectionCard(
                    title = "Checklist",
                    subtitle = "${current.checklist.count { it.done }}/${current.checklist.size} done",
                ) {
                    if (current.checklist.isEmpty()) {
                        Text(
                            "No checklist on this job. Apply a template while editing to add one.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    current.checklist.forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Checkbox(
                                checked = item.done,
                                onCheckedChange = { checked ->
                                    scope.launch {
                                        container.jobs.save(
                                            current.copy(
                                                checklist = current.checklist.map {
                                                    if (it.id == item.id) it.copy(done = checked) else it
                                                },
                                            ),
                                        )
                                    }
                                },
                            )
                            Text(item.label, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            item {
                SectionCard(
                    title = "Signature",
                    subtitle = signature?.let { "Signed by ${it.signerName} on ${Dates.formatDateTime(it.signedAt)}" }
                        ?: "Not signed yet",
                ) {
                    if (signature != null) {
                        KeyValueRow("Signer", signature?.signerName.orEmpty())
                        KeyValueRow("Role", signature?.signerRole.orEmpty())
                        KeyValueRow("Hash", signature?.sha256?.take(24).orEmpty() + "…")
                        KeyValueRow("Device", signature?.deviceModel.orEmpty())
                        VSpace(10)
                    } else {
                        InfoBanner("Get the customer to sign before you leave site — it attaches to the PDF packet.")
                        VSpace(10)
                    }
                    BigButton(
                        text = if (signature == null) "Capture signature" else "Replace signature",
                        icon = Icons.Filled.Gesture,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onOpenSignature,
                    )
                }
            }

            item {
                SectionCard(title = "Job packet") {
                    KeyValueRow("Photos included", photos.count { it.kind != PhotoKind.MARKUP }.toString())
                    KeyValueRow("Before/after pairs", minOf(beforeCount, afterCount).toString())
                    KeyValueRow("Signature", if (signature == null) "not attached" else "attached")
                    KeyValueRow("Quote", latestQuote?.number ?: "—")
                    VSpace(12)
                    BigButton(
                        text = "Export PDF packet",
                        subtitle = "Share, print or email",
                        icon = Icons.Filled.Share,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onOpenExport,
                    )
                }
            }

            item {
                SectionCard(title = "Status") {
                    val next = nextStatus(current.status)
                    BigButton(
                        text = if (next == null) "All finished" else "Mark ${next.displayName}",
                        subtitle = if (next == null) "This job is closed out" else "Current: ${current.status.displayName}",
                        icon = Icons.Filled.TaskAlt,
                        tone = FfButtonTone.SUCCESS,
                        enabled = next != null,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            if (next != null) {
                                scope.launch {
                                    container.jobs.setStatus(current.id, next)
                                    notify("Marked ${next.displayName}")
                                }
                            }
                        },
                    )
                    VSpace(10)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        BigButton(
                            text = "Edit",
                            icon = Icons.Filled.Edit,
                            tone = FfButtonTone.SECONDARY,
                            modifier = Modifier.weight(1f),
                            onClick = onEdit,
                        )
                        BigButton(
                            text = "Delete",
                            icon = Icons.Filled.Delete,
                            tone = FfButtonTone.DANGER,
                            modifier = Modifier.weight(1f),
                            onClick = { showDelete = true },
                        )
                    }
                    VSpace(10)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        RowButton(
                            text = "On site",
                            icon = Icons.Filled.Check,
                            modifier = Modifier.weight(1f),
                            onClick = { scope.launch { container.jobs.setStatus(current.id, JobStatus.IN_PROGRESS) } },
                        )
                        RowButton(
                            text = "Invoiced",
                            icon = Icons.Filled.ReceiptLong,
                            modifier = Modifier.weight(1f),
                            onClick = { scope.launch { container.jobs.setStatus(current.id, JobStatus.INVOICED) } },
                        )
                    }
                }
            }

            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Last updated ${Dates.relative(current.updatedAt)} · sync: ${current.syncState.displayName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Normal,
                    )
                }
            }

            item { VSpace(30) }
        }
    }

    if (showDelete) {
        ConfirmDialog(
            title = "Delete this job?",
            message = "The job is removed from this device and the deletion syncs to your other devices. Photos stay in the vault until you clear them.",
            confirmLabel = "Delete job",
            destructive = true,
            onConfirm = {
                showDelete = false
                scope.launch {
                    container.jobs.softDelete(current.id)
                    onDeleted()
                }
            },
            onDismiss = { showDelete = false },
        )
    }
}

private fun nextStatus(status: JobStatus): JobStatus? = when (status) {
    JobStatus.DRAFT, JobStatus.SCHEDULED -> JobStatus.IN_PROGRESS
    JobStatus.IN_PROGRESS -> JobStatus.AWAITING_SIGNATURE
    JobStatus.AWAITING_SIGNATURE -> JobStatus.COMPLETE
    JobStatus.COMPLETE -> JobStatus.INVOICED
    JobStatus.INVOICED, JobStatus.CANCELLED -> null
}
