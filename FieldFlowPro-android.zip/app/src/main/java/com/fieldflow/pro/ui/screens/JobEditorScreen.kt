package com.fieldflow.pro.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.core.Dates
import com.fieldflow.pro.core.Money
import com.fieldflow.pro.core.analytics.AnalyticsEvents
import com.fieldflow.pro.data.model.ChecklistItem
import com.fieldflow.pro.data.model.Job
import com.fieldflow.pro.data.model.JobStatus
import com.fieldflow.pro.data.model.MaterialLine
import com.fieldflow.pro.data.model.Priority
import com.fieldflow.pro.data.model.Trade
import com.fieldflow.pro.ui.components.BigButton
import com.fieldflow.pro.ui.components.ChipPicker
import com.fieldflow.pro.ui.components.FfButtonTone
import com.fieldflow.pro.ui.components.FfMoneyInput
import com.fieldflow.pro.ui.components.FfPercentInput
import com.fieldflow.pro.ui.components.FfQtyInput
import com.fieldflow.pro.ui.components.FfScreen
import com.fieldflow.pro.ui.components.FfTextField
import com.fieldflow.pro.ui.components.InfoBanner
import com.fieldflow.pro.ui.components.RowButton
import com.fieldflow.pro.ui.components.SectionCard
import com.fieldflow.pro.ui.components.TotalRow
import com.fieldflow.pro.ui.components.TradeChips
import com.fieldflow.pro.ui.components.VSpace
import kotlinx.coroutines.launch

@Composable
fun JobEditorScreen(
    container: AppContainer,
    jobId: String?,
    onClose: () -> Unit,
    onSaved: (String) -> Unit,
) {
    val isNew = jobId == null
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val settings by container.settings.settings.collectAsState()
    val clients by container.clients.clients.collectAsState()

    var ready by remember { mutableStateOf(isNew) }
    var existing by remember { mutableStateOf<Job?>(null) }
    var title by remember { mutableStateOf("") }
    var trade by remember { mutableStateOf(settings.defaultTrade) }
    var clientId by remember { mutableStateOf<String?>(null) }
    var clientName by remember { mutableStateOf("") }
    var clientPhone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var materials by remember { mutableStateOf<List<MaterialLine>>(emptyList()) }
    var checklist by remember { mutableStateOf<List<ChecklistItem>>(emptyList()) }
    var labourHours by remember { mutableStateOf(0.0) }
    var labourRate by remember { mutableStateOf(settings.defaultLabourRateCents) }
    var taxRate by remember { mutableStateOf(settings.defaultTaxRatePercent) }
    var discount by remember { mutableStateOf(0L) }
    var status by remember { mutableStateOf(JobStatus.SCHEDULED) }
    var priority by remember { mutableStateOf(Priority.NORMAL) }
    var scheduledAt by remember { mutableStateOf(0L) }
    var showClients by remember { mutableStateOf(false) }
    var showTemplates by remember { mutableStateOf(isNew) }
    var newChecklistItem by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }

    LaunchedEffect(jobId) {
        if (jobId != null) {
            val job = container.jobs.byId(jobId)
            if (job != null) {
                existing = job
                title = job.title
                trade = job.trade
                clientId = job.clientId
                clientName = job.clientName
                clientPhone = job.clientPhone
                address = job.address
                description = job.description
                materials = job.materials
                checklist = job.checklist
                labourHours = job.labourHours
                labourRate = job.labourRateCents
                taxRate = job.taxRatePercent
                discount = job.discountCents
                status = job.status
                priority = job.priority
                scheduledAt = job.scheduledAt
            }
            ready = true
        }
    }

    val materialsTotal = materials.sumOf { Math.round(it.quantity * it.unitPriceCents.toDouble()) }
    val labourTotal = Math.round(labourHours * labourRate.toDouble())
    val subtotal = materialsTotal + labourTotal
    val taxable = (subtotal - discount).coerceAtLeast(0L)
    val tax = Math.round(taxable * (taxRate / 100.0))
    val total = taxable + tax

    FfScreen(
        title = if (isNew) "New job" else "Edit job",
        subtitle = existing?.number ?: "Draft",
        onBack = onClose,
        snackbarHostState = snackbar,
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            ) {
                TotalRow(label = "Job total", value = Money.format(total, settings.currencyCode))
                VSpace(8)
                BigButton(
                    text = if (isNew) "Save job" else "Save changes",
                    subtitle = if (title.isBlank()) "Give the job a title first" else null,
                    icon = Icons.Filled.Save,
                    loading = saving,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        if (title.isBlank()) {
                            scope.launch { snackbar.showSnackbar("Add a title so you can find it later") }
                            return@BigButton
                        }
                        saving = true
                        scope.launch {
                            val base = existing ?: Job()
                            val saved = container.jobs.save(
                                base.copy(
                                    title = title.trim(),
                                    trade = trade,
                                    clientId = clientId,
                                    clientName = clientName.trim(),
                                    clientPhone = clientPhone.trim(),
                                    address = address.trim(),
                                    description = description.trim(),
                                    materials = materials,
                                    checklist = checklist,
                                    labourHours = labourHours,
                                    labourRateCents = labourRate,
                                    taxRatePercent = taxRate,
                                    discountCents = discount,
                                    status = status,
                                    priority = priority,
                                    scheduledAt = scheduledAt,
                                ),
                                event = if (isNew) AnalyticsEvents.JOB_CREATED else AnalyticsEvents.JOB_UPDATED,
                            )
                            saving = false
                            onSaved(saved.id)
                        }
                    },
                )
            }
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (!ready) {
                item { InfoBanner("Loading job…") }
            }

            item {
                SectionCard(
                    title = "What's the job?",
                    subtitle = "One line is enough — you can edit later",
                ) {
                    FfTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = "Job title",
                        placeholder = "e.g. Replace capacitor on rooftop unit",
                    )
                    VSpace(12)
                    TradeChips(selected = trade, onSelect = { trade = it })
                    VSpace(12)
                    FfTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = "Scope / notes",
                        singleLine = false,
                        minLines = 3,
                    )
                    if (isNew) {
                        VSpace(12)
                        RowButton(
                            text = if (showTemplates) "Hide templates" else "Start from a template",
                            icon = Icons.Filled.Description,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { showTemplates = !showTemplates },
                        )
                        if (showTemplates) {
                            VSpace(8)
                            val options = container.templates.forTrade(trade)
                            if (options.isEmpty()) {
                                Text(
                                    "No templates for this trade yet.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            options.forEach { template ->
                                VSpace(8)
                                BigButton(
                                    text = template.name,
                                    subtitle = "${template.lines.size} line(s) · ${template.checklist.size} checklist item(s)",
                                    tone = FfButtonTone.SECONDARY,
                                    modifier = Modifier.fillMaxWidth(),
                                    onClick = {
                                        val applied = container.templates.applyTo(existing ?: Job(), template, settings)
                                        title = applied.title
                                        description = applied.description
                                        materials = applied.materials
                                        checklist = applied.checklist
                                        labourHours = applied.labourHours
                                        labourRate = applied.labourRateCents
                                        taxRate = applied.taxRatePercent
                                        showTemplates = false
                                        container.analytics.log(
                                            AnalyticsEvents.TEMPLATE_APPLIED,
                                            mapOf("template_id" to template.id, "trade" to template.trade.name),
                                        )
                                        scope.launch { snackbar.showSnackbar("${template.name} applied") }
                                    },
                                )
                            }
                        }
                    }
                }
            }

            item {
                SectionCard(title = "Who is it for?") {
                    if (clientId == null) {
                        FfTextField(clientName, { clientName = it }, "Client name")
                        VSpace(12)
                        FfTextField(clientPhone, { clientPhone = it }, "Client phone")
                        VSpace(12)
                        RowButton(
                            text = if (showClients) "Hide saved clients" else "Pick a saved client",
                            icon = Icons.Filled.Person,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { showClients = !showClients },
                        )
                        if (showClients) {
                            if (clients.isEmpty()) {
                                VSpace(8)
                                Text(
                                    "No saved clients yet. Add them from the Clients tab and they'll appear here.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            clients.take(12).forEach { client ->
                                VSpace(8)
                                BigButton(
                                    text = client.name.ifBlank { "Unnamed client" },
                                    subtitle = listOf(client.phone, client.address).filter { it.isNotBlank() }.joinToString(" · "),
                                    tone = FfButtonTone.SECONDARY,
                                    modifier = Modifier.fillMaxWidth(),
                                    onClick = {
                                        clientId = client.id
                                        clientName = client.name
                                        clientPhone = client.phone
                                        if (address.isBlank()) address = client.address
                                        showClients = false
                                    },
                                )
                            }
                        }
                    } else {
                        val selected = clients.firstOrNull { it.id == clientId }
                        InfoBanner("Client: ${selected?.name ?: clientName}")
                        VSpace(10)
                        BigButton(
                            text = "Clear client",
                            tone = FfButtonTone.SECONDARY,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { clientId = null },
                        )
                    }
                    VSpace(12)
                    FfTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = "Site address",
                        singleLine = false,
                        minLines = 2,
                    )
                }
            }

            item {
                SectionCard(
                    title = "Materials",
                    subtitle = "Anything you'll bill for on this visit",
                    trailing = {
                        RowButton(
                            text = "Add",
                            icon = Icons.Filled.Add,
                            onClick = { materials = materials + MaterialLine() },
                        )
                    },
                ) {
                    if (materials.isEmpty()) {
                        Text(
                            "No materials yet.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    materials.forEachIndexed { index, line ->
                        if (index > 0) VSpace(12)
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                Text(
                                    "Material ${index + 1}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f),
                                )
                                RowButton(
                                    text = "Remove",
                                    icon = Icons.Filled.Delete,
                                    onClick = { materials = materials.filterNot { it.id == line.id } },
                                )
                            }
                            VSpace(8)
                            FfTextField(
                                value = line.description,
                                onValueChange = { text ->
                                    materials = materials.map { if (it.id == line.id) it.copy(description = text) else it }
                                },
                                label = "Description",
                            )
                            VSpace(8)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FfQtyInput(
                                    value = line.quantity,
                                    onValueChange = { qty ->
                                        materials = materials.map { if (it.id == line.id) it.copy(quantity = qty) else it }
                                    },
                                    label = "Qty",
                                    modifier = Modifier.weight(1f),
                                )
                                FfTextField(
                                    value = line.unit,
                                    onValueChange = { text ->
                                        materials = materials.map { if (it.id == line.id) it.copy(unit = text) else it }
                                    },
                                    label = "Unit",
                                    modifier = Modifier.weight(1f),
                                )
                            }
                            VSpace(8)
                            FfMoneyInput(
                                cents = line.unitPriceCents,
                                onCentsChange = { cents ->
                                    materials = materials.map { if (it.id == line.id) it.copy(unitPriceCents = cents) else it }
                                },
                                label = "Unit price",
                                supportingText = "Line total ${Money.format(line.lineTotalCents, settings.currencyCode)}",
                            )
                        }
                    }
                }
            }

            item {
                SectionCard(title = "Labour and totals") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FfQtyInput(
                            value = labourHours,
                            onValueChange = { labourHours = it },
                            label = "Hours",
                            modifier = Modifier.weight(1f),
                        )
                        FfMoneyInput(
                            cents = labourRate,
                            onCentsChange = { labourRate = it },
                            label = "Rate / hour",
                            modifier = Modifier.weight(1f),
                        )
                    }
                    VSpace(8)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FfPercentInput(
                            value = taxRate,
                            onValueChange = { taxRate = it },
                            label = "Tax %",
                            modifier = Modifier.weight(1f),
                        )
                        FfMoneyInput(
                            cents = discount,
                            onCentsChange = { discount = it },
                            label = "Discount",
                            modifier = Modifier.weight(1f),
                        )
                    }
                    VSpace(12)
                    TotalRow("Materials", Money.format(materialsTotal, settings.currencyCode))
                    VSpace(6)
                    TotalRow("Labour", Money.format(labourTotal, settings.currencyCode))
                    VSpace(6)
                    TotalRow("Tax", Money.format(tax, settings.currencyCode))
                    VSpace(6)
                    TotalRow("Total", Money.format(total, settings.currencyCode))
                }
            }

            item {
                SectionCard(title = "Status and schedule") {
                    Text("Status", style = MaterialTheme.typography.titleSmall)
                    VSpace(6)
                    ChipPicker(
                        options = JobStatus.entries.map { it.displayName },
                        selected = status.displayName,
                        onSelect = { label ->
                            status = JobStatus.entries.firstOrNull { it.displayName == label } ?: status
                        },
                    )
                    VSpace(12)
                    Text("Priority", style = MaterialTheme.typography.titleSmall)
                    VSpace(6)
                    ChipPicker(
                        options = Priority.entries.map { it.displayName },
                        selected = priority.displayName,
                        onSelect = { label ->
                            priority = Priority.entries.firstOrNull { it.displayName == label } ?: priority
                        },
                    )
                    VSpace(12)
                    Text(
                        "Scheduled: ${if (scheduledAt == 0L) "Unscheduled" else Dates.formatDate(scheduledAt)}",
                        style = MaterialTheme.typography.titleSmall,
                    )
                    VSpace(8)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val now = System.currentTimeMillis()
                        val day = 86_400_000L
                        ChipPicker(
                            options = listOf("Today", "Tomorrow", "+3d"),
                            selected = null,
                            onSelect = { label ->
                                scheduledAt = when (label) {
                                    "Today" -> Dates.todayStart(now) + 9 * 3_600_000L
                                    "Tomorrow" -> Dates.todayStart(now) + day + 9 * 3_600_000L
                                    else -> Dates.todayStart(now) + 3 * day + 9 * 3_600_000L
                                }
                            },
                        )
                    }
                    VSpace(8)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        RowButton(
                            text = "Clear date",
                            modifier = Modifier.weight(1f),
                            onClick = { scheduledAt = 0L },
                        )
                        RowButton(
                            text = "Set 9am today",
                            modifier = Modifier.weight(1f),
                            onClick = { scheduledAt = Dates.todayStart() + 9 * 3_600_000L },
                        )
                    }
                }
            }

            item {
                SectionCard(title = "Checklist", subtitle = "${checklist.count { it.done }}/${checklist.size} done") {
                    checklist.forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                        ) {
                            androidx.compose.material3.Checkbox(
                                checked = item.done,
                                onCheckedChange = { checked ->
                                    checklist = checklist.map { if (it.id == item.id) it.copy(done = checked) else it }
                                },
                            )
                            Text(item.label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                            RowButton(
                                text = "",
                                icon = Icons.Filled.Delete,
                                onClick = { checklist = checklist.filterNot { it.id == item.id } },
                            )
                        }
                    }
                    VSpace(8)
                    FfTextField(
                        value = newChecklistItem,
                        onValueChange = { newChecklistItem = it },
                        label = "Add a checklist step",
                    )
                    VSpace(8)
                    BigButton(
                        text = "Add step",
                        icon = Icons.Filled.Check,
                        tone = FfButtonTone.SECONDARY,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            if (newChecklistItem.isNotBlank()) {
                                checklist = checklist + ChecklistItem(label = newChecklistItem.trim())
                                newChecklistItem = ""
                            }
                        },
                    )
                }
            }

            item { VSpace(90) }
        }
    }
}
