package com.fieldflow.pro.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.core.Dates
import com.fieldflow.pro.data.model.Job
import com.fieldflow.pro.ui.components.BigButton
import com.fieldflow.pro.ui.components.EmptyState
import com.fieldflow.pro.ui.components.FfScreen
import com.fieldflow.pro.ui.components.FfTextField
import com.fieldflow.pro.ui.components.VSpace

private enum class JobFilter(val label: String) {
    ALL("All"),
    OPEN("Open"),
    TODAY("Today"),
    DONE("Completed"),
}

@Composable
fun JobsTab(
    container: AppContainer,
    onNewJob: () -> Unit,
    onOpenJob: (String) -> Unit,
) {
    val jobs by container.jobs.jobs.collectAsState()
    val settings by container.settings.settings.collectAsState()
    val syncState by container.sync.state.collectAsState()
    val queuePending by container.queue.pendingCount.collectAsState()

    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(JobFilter.OPEN) }
    val snackbar = remember { SnackbarHostState() }

    val todayStart = Dates.todayStart()
    val todayEnd = Dates.endOfDay(todayStart)

    val filtered: List<Job> = jobs
        .filter { job ->
            when (filter) {
                JobFilter.ALL -> true
                JobFilter.OPEN -> job.isOpen
                JobFilter.TODAY -> job.scheduledAt in todayStart..todayEnd
                JobFilter.DONE -> !job.isOpen
            }
        }
        .filter { job ->
            if (query.isBlank()) {
                true
            } else {
                val q = query.lowercase()
                job.title.lowercase().contains(q) ||
                    job.clientName.lowercase().contains(q) ||
                    job.address.lowercase().contains(q) ||
                    job.number.lowercase().contains(q) ||
                    job.description.lowercase().contains(q)
            }
        }

    FfScreen(
        title = "Jobs",
        subtitle = "${jobs.size} total · ${jobs.count { it.isOpen }} open",
        snackbarHostState = snackbar,
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                FfTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = "Search jobs, clients, addresses",
                    leadingIcon = Icons.Filled.Search,
                )
            }
            item {
                Row(modifier = Modifier.fillMaxWidth()) {
                    JobFilter.entries.forEach { option ->
                        FilterChip(
                            selected = filter == option,
                            onClick = { filter = option },
                            label = {
                                Text(option.label, style = MaterialTheme.typography.labelMedium)
                            },
                            modifier = Modifier.padding(end = 8.dp),
                        )
                    }
                }
            }
            item {
                BigButton(
                    text = "New job",
                    icon = Icons.Filled.Add,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = onNewJob,
                )
            }
            item { VSpace(2) }

            if (filtered.isEmpty()) {
                item {
                    EmptyState(
                        icon = Icons.Filled.Work,
                        title = if (jobs.isEmpty()) "No jobs yet" else "Nothing matches",
                        message = if (jobs.isEmpty()) {
                            "Create your first job — it takes about 30 seconds and works with no signal."
                        } else {
                            "Try a different filter or clear the search box."
                        },
                        actionLabel = if (jobs.isEmpty()) "Create a job" else null,
                        onAction = if (jobs.isEmpty()) onNewJob else null,
                    )
                }
            } else {
                items(filtered, key = { it.id }) { job ->
                    com.fieldflow.pro.ui.components.JobRow(
                        job = job,
                        currency = settings.currencyCode,
                        onClick = { onOpenJob(job.id) },
                    )
                }
            }
            item {
                Text(
                    if (syncState.online) "Synced ${Dates.relative(settings.lastSyncAt)}"
                    else "$queuePending change(s) waiting for signal",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 8.dp),
                )
            }
        }
    }
}
