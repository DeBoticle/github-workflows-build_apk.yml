package com.fieldflow.pro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.fieldflow.pro.BuildConfig
import com.fieldflow.pro.core.AppError
import com.fieldflow.pro.core.AppResult
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.data.model.AuthProvider
import com.fieldflow.pro.data.model.UserAccount
import com.fieldflow.pro.ui.components.BannerTone
import com.fieldflow.pro.ui.components.BigButton
import com.fieldflow.pro.ui.components.FfButtonTone
import com.fieldflow.pro.ui.components.FfTextField
import com.fieldflow.pro.ui.components.HSpace
import com.fieldflow.pro.ui.components.InfoBanner
import com.fieldflow.pro.ui.components.LoadingDots
import com.fieldflow.pro.ui.components.SectionCard
import com.fieldflow.pro.ui.components.VSpace
import com.fieldflow.pro.ui.theme.FieldFlowTeal
import com.fieldflow.pro.ui.theme.LocalFfDimens
import kotlinx.coroutines.launch

private enum class AuthMode { SIGN_IN, CREATE }

@Composable
fun LoginScreen(container: AppContainer) {
    val scope = rememberCoroutineScope()
    val dimens = LocalFfDimens.current
    val context = androidx.compose.ui.platform.LocalContext.current

    var mode by remember { mutableStateOf(AuthMode.SIGN_IN) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var businessName by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var errorLine by remember { mutableStateOf<String?>(null) }
    var storedAccounts by remember { mutableStateOf<List<UserAccount>>(emptyList()) }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        storedAccounts = runCatching { container.auth.accounts() }.getOrDefault(emptyList())
            .filter { it.email.isNotBlank() }
            .sortedByDescending { it.lastLoginAt }
    }

    fun handle(result: AppResult<*>) {
        when (result) {
            is AppResult.Success -> errorLine = null
            is AppResult.Failure -> {
                errorLine = result.error.userMessage()
                container.logger.w("Login", "Auth failure: ${result.error}")
            }
        }
        busy = false
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        MaterialTheme.colorScheme.background,
                        MaterialTheme.colorScheme.surface,
                    ),
                ),
            ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = dimens.gutter)
                .navigationBarsPadding(),
        ) {
            VSpace(56)
            Text("FieldFlow", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
            Text(
                "Pro",
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.Bold,
                color = FieldFlowTeal,
            )
            VSpace(6)
            Text(
                "Quotes, photo evidence and signatures for HVAC, plumbing, electrical and handyman work — built to work with no signal.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            VSpace(24)

            SectionCard {
                Row(modifier = Modifier.fillMaxWidth()) {
                    ModeTab(
                        label = "Sign in",
                        active = mode == AuthMode.SIGN_IN,
                        modifier = Modifier.weight(1f),
                        onClick = { mode = AuthMode.SIGN_IN; errorLine = null },
                    )
                    HSpace(8)
                    ModeTab(
                        label = "Create account",
                        active = mode == AuthMode.CREATE,
                        modifier = Modifier.weight(1f),
                        onClick = { mode = AuthMode.CREATE; errorLine = null },
                    )
                }
                VSpace(16)

                if (mode == AuthMode.CREATE) {
                    FfTextField(
                        value = displayName,
                        onValueChange = { displayName = it },
                        label = "Your name",
                        leadingIcon = Icons.Filled.AccountCircle,
                    )
                    VSpace(12)
                    FfTextField(
                        value = businessName,
                        onValueChange = { businessName = it },
                        label = "Business name (shown on quotes)",
                    )
                    VSpace(12)
                }

                FfTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = "Email",
                    keyboardType = androidx.compose.ui.text.input.KeyboardType.Email,
                    singleLine = true,
                )
                VSpace(12)
                FfTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = "Password",
                    singleLine = true,
                    visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                    leadingIcon = Icons.Filled.Lock,
                    trailing = {
                        Text(
                            if (showPassword) "Hide" else "Show",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .clickable { showPassword = !showPassword }
                                .padding(horizontal = 10.dp),
                        )
                    },
                    supportingText = if (mode == AuthMode.CREATE) "At least 8 characters, letters and numbers." else null,
                )
                VSpace(14)

                if (errorLine != null) {
                    InfoBanner(text = errorLine ?: "", tone = BannerTone.DANGER)
                    VSpace(12)
                }
                if (message != null) {
                    InfoBanner(text = message ?: "", tone = BannerTone.SUCCESS)
                    VSpace(12)
                }

                BigButton(
                    text = if (mode == AuthMode.SIGN_IN) "Sign in" else "Create my account",
                    icon = if (mode == AuthMode.SIGN_IN) Icons.Filled.Login else Icons.Filled.PersonAdd,
                    loading = busy,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        busy = true
                        errorLine = null
                        message = null
                        scope.launch {
                            val result = if (mode == AuthMode.SIGN_IN) {
                                container.auth.signInWithEmail(email, password)
                            } else {
                                container.auth.signUpWithEmail(email, password, displayName, businessName)
                            }
                            handle(result)
                        }
                    },
                )

                VSpace(16)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    HorizontalDivider(modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.outlineVariant)
                    Text(
                        "  or  ",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    HorizontalDivider(modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.outlineVariant)
                }
                VSpace(16)

                BigButton(
                    text = "Continue with Google",
                    subtitle = if (container.googleSignIn.isConfigured) null else "Set GOOGLE_WEB_CLIENT_ID to enable",
                    icon = Icons.Filled.AccountCircle,
                    tone = FfButtonTone.SECONDARY,
                    enabled = container.googleSignIn.isConfigured,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        busy = true
                        errorLine = null
                        message = null
                        scope.launch {
                            val identity = container.googleSignIn.signIn(context)
                            when (identity) {
                                is AppResult.Success -> {
                                    val value = identity.value
                                    handle(
                                        container.auth.signInWithGoogleIdentity(
                                            subject = value.subject,
                                            email = value.email,
                                            displayName = value.displayName,
                                            idToken = value.idToken,
                                            verifiedOnline = value.verifiedOnline,
                                        ),
                                    )
                                    if (!value.verifiedOnline) {
                                        message = "Signed in offline with Google. We'll verify the token when you're back online."
                                    }
                                }
                                is AppResult.Failure -> handle(identity)
                            }
                        }
                    },
                )
            }

            if (storedAccounts.isNotEmpty()) {
                VSpace(16)
                SectionCard(
                    title = "Use a saved account",
                    subtitle = "Sign in without a network connection",
                ) {
                    storedAccounts.take(3).forEach { account ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(MaterialTheme.shapes.small)
                                .clickable {
                                    busy = true
                                    errorLine = null
                                    scope.launch {
                                        handle(container.auth.signInAsStoredAccount(account.id, offlineOnly = true))
                                    }
                                }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                Icons.Filled.WifiOff,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(dimens.iconMedium),
                            )
                            HSpace(12)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(account.displayName, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    account.email + if (account.provider == AuthProvider.GOOGLE) " · Google" else "",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Text("Offline sign in", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }

            VSpace(16)
            InfoBanner(
                text = "Your jobs, photos and signatures are encrypted on this device (Android Keystore, AES-256). Nothing is uploaded until you turn sync on.",
                tone = BannerTone.INFO,
            )
            VSpace(10)
            Text(
                "FieldFlow Pro v${BuildConfig.VERSION_NAME}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            VSpace(30)
            if (busy) {
                LoadingDots(label = "Working…")
                VSpace(20)
            }
        }
    }
}

@Composable
private fun ModeTab(
    label: String,
    active: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val dimens = LocalFfDimens.current
    Surface(
        modifier = modifier
            .heightIn(min = dimens.touchTarget)
            .clip(RoundedCornerShape(50))
            .clickable(onClick = onClick),
        color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(50),
        border = if (active) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxWidth()) {
            Text(
                label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 12.dp),
            )
        }
    }
}
