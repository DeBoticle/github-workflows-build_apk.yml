package com.fieldflow.pro.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.core.analytics.AnalyticsEvents
import com.fieldflow.pro.data.model.PhotoKind
import com.fieldflow.pro.ui.components.BigButton
import com.fieldflow.pro.ui.components.ChipPicker
import com.fieldflow.pro.ui.components.FfButtonTone
import com.fieldflow.pro.ui.components.FfScreen
import com.fieldflow.pro.ui.components.FfTextField
import com.fieldflow.pro.ui.components.InfoBanner
import com.fieldflow.pro.ui.components.LoadingDots
import com.fieldflow.pro.ui.components.MarkupCanvas
import com.fieldflow.pro.ui.components.MarkupStroke
import com.fieldflow.pro.ui.components.MarkupTool
import com.fieldflow.pro.ui.components.RowButton
import com.fieldflow.pro.ui.components.VSpace
import com.fieldflow.pro.ui.components.renderMarkupBitmap
import kotlinx.coroutines.launch

private val markupPalette = listOf(
    Color(0xFFEF4444),
    Color(0xFFFFC107),
    Color(0xFF22C55E),
    Color(0xFF38BDF8),
    Color(0xFFFFFFFF),
    Color(0xFF111827),
)

@Composable
fun MarkupScreen(
    container: AppContainer,
    jobId: String,
    photoId: String,
    onBack: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    var bitmap by remember(photoId) { mutableStateOf<Bitmap?>(null) }
    var loading by remember(photoId) { mutableStateOf(true) }
    var tool by remember { mutableStateOf(MarkupTool.PEN) }
    var color by remember { mutableStateOf(markupPalette.first()) }
    var width by remember { mutableStateOf(0.012f) }
    var labelText by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    val strokes = remember(photoId) { mutableStateListOf<MarkupStroke>() }

    LaunchedEffect(photoId) {
        loading = true
        val photo = container.photos.byId(photoId)
        bitmap = photo?.let { runCatching { container.photoStore.loadBitmap(it, 1800) }.getOrNull() }
        loading = false
    }

    FfScreen(
        title = "Mark up photo",
        subtitle = "${strokes.size} annotation(s)",
        onBack = onBack,
        snackbarHostState = snackbar,
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .navigationBarsPadding(),
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
            ) {
                val base = bitmap
                if (loading || base == null) {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        LoadingDots(label = "Decrypting photo…")
                    }
                } else {
                    MarkupCanvas(
                        image = base.asImageBitmap(),
                        strokes = strokes.toList(),
                        tool = tool,
                        color = color,
                        width = width,
                        pendingLabel = labelText,
                        modifier = Modifier.fillMaxWidth(),
                        onStrokeFinished = { stroke -> strokes.add(stroke) },
                    )
                }
            }

            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                if (strokes.isEmpty()) {
                    InfoBanner("Pick a tool, then draw straight on the photo. Annotations are burned into a new copy — the original is untouched.")
                    VSpace(8)
                }
                ChipPicker(
                    options = MarkupTool.entries.map { it.label },
                    selected = tool.label,
                    onSelect = { label ->
                        tool = MarkupTool.entries.firstOrNull { it.label == label } ?: tool
                    },
                )
                VSpace(8)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    markupPalette.forEach { swatch ->
                        Box(
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(swatch)
                                .border(
                                    width = if (swatch == color) 3.dp else 1.dp,
                                    color = if (swatch == color) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                    shape = CircleShape,
                                )
                                .clickable { color = swatch },
                        )
                    }
                }
                VSpace(4)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Size", style = MaterialTheme.typography.labelMedium)
                    Slider(
                        value = width,
                        onValueChange = { width = it.coerceIn(0.004f, 0.05f) },
                        valueRange = 0.004f..0.05f,
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 10.dp),
                    )
                }
                if (tool == MarkupTool.TEXT) {
                    FfTextField(
                        value = labelText,
                        onValueChange = { labelText = it },
                        label = "Label text — then tap the photo",
                    )
                    VSpace(8)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RowButton(
                        text = "Undo",
                        icon = Icons.Filled.Undo,
                        enabled = strokes.isNotEmpty(),
                        modifier = Modifier.weight(1f),
                        onClick = { if (strokes.isNotEmpty()) strokes.removeAt(strokes.size - 1) },
                    )
                    RowButton(
                        text = "Clear",
                        icon = Icons.Filled.Delete,
                        enabled = strokes.isNotEmpty(),
                        modifier = Modifier.weight(1f),
                        onClick = { strokes.clear() },
                    )
                }
                VSpace(8)
                BigButton(
                    text = "Save marked-up copy",
                    subtitle = "Original photo is kept",
                    icon = Icons.Filled.Save,
                    loading = saving,
                    enabled = bitmap != null && strokes.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        val base = bitmap ?: return@BigButton
                        saving = true
                        scope.launch {
                            runCatching {
                                val rendered = renderMarkupBitmap(base, strokes.toList())
                                val photo = container.photoStore.importBitmap(
                                    bitmap = rendered,
                                    jobId = jobId,
                                    kind = PhotoKind.MARKUP,
                                    caption = "Marked up",
                                    parentId = photoId,
                                )
                                container.photos.save(photo, AnalyticsEvents.PHOTO_MARKED_UP)
                                container.jobs.attachPhoto(jobId, photo.id)
                                rendered.recycle()
                            }.onFailure {
                                container.logger.e("Markup", "Save failed", it)
                                snackbar.showSnackbar("Could not save the markup")
                                saving = false
                                return@launch
                            }
                            saving = false
                            snackbar.showSnackbar("Marked-up photo saved")
                            onBack()
                        }
                    },
                )
            }
        }
    }
}
