package com.fieldflow.pro.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.WavingHand
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.core.Money
import com.fieldflow.pro.core.analytics.AnalyticsEvents
import com.fieldflow.pro.data.model.AppSettings
import com.fieldflow.pro.data.model.ThemeMode
import com.fieldflow.pro.data.model.Trade
import com.fieldflow.pro.ui.components.BannerTone
import com.fieldflow.pro.ui.components.BigButton
import com.fieldflow.pro.ui.components.FfButtonTone
import com.fieldflow.pro.ui.components.FfMoneyField
import com.fieldflow.pro.ui.components.FfTextField
import com.fieldflow.pro.ui.components.InfoBanner
import com.fieldflow.pro.ui.components.RowButton
import com.fieldflow.pro.ui.components.SectionCard
import com.fieldflow.pro.ui.components.TradeChips
import com.fieldflow.pro.ui.components.VSpace
import com.fieldflow.pro.ui.theme.LocalFfDimens
import kotlinx.coroutines.launch

private const val PAGE_COUNT = 6

@Composable
fun OnboardingScreen(container: AppContainer) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val dimens = LocalFfDimens.current
    val settings by container.settings.settings.collectAsState()
    val pagerState = rememberPagerState(pageCount = { PAGE_COUNT })

    var businessName by remember { mutableStateOf(settings.businessName) }
    var businessPhone by remember { mutableStateOf(settings.businessPhone) }
    var businessEmail by remember { mutableStateOf(settings.businessEmail) }
    var licence by remember { mutableStateOf(settings.licenceNumber) }
    var trade by remember { mutableStateOf(settings.defaultTrade) }
    var labourRate by remember { mutableStateOf(if (settings.defaultLabourRateCents > 0) Money.formatPlain(settings.defaultLabourRateCents) else "") }
    var taxRate by remember { mutableStateOf(if (settings.defaultTaxRatePercent > 0) settings.defaultTaxRatePercent.toString() else "") }
    var themeMode by remember { mutableStateOf(settings.themeMode) }
    var gloveMode by remember { mutableStateOf(settings.gloveMode) }
    var haptics by remember { mutableStateOf(settings.hapticsEnabled) }
    var autoSync by remember { mutableStateOf(settings.autoSync) }
    var wifiOnly by remember { mutableStateOf(settings.syncOnWifiOnly) }
    var cameraGranted by remember { mutableStateOf(false) }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        cameraGranted = granted
        container.analytics.log("onboarding_permission", mapOf("permission" to "camera", "granted" to granted))
    }

    LaunchedEffect(Unit) {
        container.analytics.log(AnalyticsEvents.ONBOARDING_START)
    }

    fun persist() {
        scope.launch {
            container.settings.update { current ->
                current.copy(
                    businessName = businessName.trim(),
                    businessPhone = businessPhone.trim(),
                    businessEmail = businessEmail.trim(),
                    licenceNumber = licence.trim(),
                    defaultTrade = trade,
                    defaultLabourRateCents = labourRate.toDoubleOrNull()?.let { Math.round(it * 100) }
                        ?: current.defaultLabourRateCents,
                    defaultTaxRatePercent = taxRate.toDoubleOrNull() ?: current.defaultTaxRatePercent,
                    themeMode = themeMode,
                    gloveMode = gloveMode,
                    hapticsEnabled = haptics,
                    autoSync = autoSync,
                    syncOnWifiOnly = wifiOnly,
                )
            }
            container.applySyncPolicy()
        }
    }

    fun finish(skip: Boolean) {
        persist()
        scope.launch {
            container.settings.update { it.copy(onboardingComplete = true) }
            container.analytics.log(AnalyticsEvents.ONBOARDING_COMPLETE, mapOf("skipped" to skip))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = dimens.gutter, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Getting set up", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(
                    "Step ${pagerState.currentPage + 1} of $PAGE_COUNT",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            RowButton(text = "Skip", onClick = { finish(skip = true) })
        }

        HorizontalPager(
            state = pagerState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
        ) { page ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = dimens.gutter),
            ) {
                when (page) {
                    0 -> OnboardingPage(
                        icon = Icons.Filled.WavingHand,
                        title = "Welcome to FieldFlow Pro",
                        body = "Create a job in under a minute, snap before/after photos, build a quote that totals itself, get the customer's signature, then send a PDF packet. " +
                            "Built for gloves, bright sun and no signal.",
                    ) {
                        SectionCard(title = "What you get") {
                            FeatureLine("Ultra-simple job creation with materials and cost")
                            FeatureLine("Photo capture, markup and before/after compare")
                            FeatureLine("Quote builder with automatic totals")
                            FeatureLine("Client signature capture, stored with a hash")
                            FeatureLine("PDF job packets you can text or email")
                            FeatureLine("Per-trade templates for HVAC, plumbing and electrical")
                        }
                    }

                    1 -> OnboardingPage(
                        icon = Icons.Filled.Storefront,
                        title = "Your business details",
                        body = "These appear at the top of every quote and job packet. You can change them any time in Settings.",
                    ) {
                        SectionCard {
                            FfTextField(businessName, { businessName = it }, "Business name")
                            VSpace(12)
                            FfTextField(businessPhone, { businessPhone = it }, "Business phone")
                            VSpace(12)
                            FfTextField(businessEmail, { businessEmail = it }, "Business email")
                            VSpace(12)
                            FfTextField(licence, { licence = it }, "Licence / registration number")
                        }
                    }

                    2 -> OnboardingPage(
                        icon = Icons.Filled.Payments,
                        title = "Your default rates",
                        body = "New jobs and quotes start with these numbers so you don't retype them on site.",
                    ) {
                        SectionCard(title = "Default trade") {
                            TradeChips(selected = trade, onSelect = { trade = it })
                        }
                        VSpace(14)
                        SectionCard(title = "Money") {
                            FfMoneyField(labourRate, { labourRate = it }, "Labour rate per hour")
                            VSpace(12)
                            FfTextField(taxRate, { taxRate = it.filter { c -> c.isDigit() || c == '.' } }, "Tax rate %")
                            VSpace(8)
                            Text(
                                "Leave blank to keep 0. You can override both per job.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }

                    3 -> OnboardingPage(
                        icon = Icons.Filled.Palette,
                        title = "Built for the field",
                        body = "Glove mode makes every button bigger and the type larger. Dark mode is easier in a plant room.",
                    ) {
                        SectionCard(title = "Appearance") {
                            ChoiceRow("Follow system", themeMode == ThemeMode.SYSTEM) { themeMode = ThemeMode.SYSTEM }
                            ChoiceRow("Light", themeMode == ThemeMode.LIGHT) { themeMode = ThemeMode.LIGHT }
                            ChoiceRow("Dark", themeMode == ThemeMode.DARK) { themeMode = ThemeMode.DARK }
                        }
                        VSpace(14)
                        SectionCard(title = "Comfort") {
                            SwitchRow(
                                label = "Glove mode",
                                caption = "Bigger buttons and type for dirty hands",
                                checked = gloveMode,
                                onCheckedChange = {
                                    gloveMode = it
                                    scope.launch { container.settings.update { current -> current.copy(gloveMode = it) } }
                                },
                            )
                            SwitchRow(
                                label = "Haptic feedback",
                                caption = "Vibrate on big actions",
                                checked = haptics,
                                onCheckedChange = { haptics = it },
                            )
                        }
                        VSpace(14)
                        InfoBanner(
                            "Everything in FieldFlow works with no signal. Sync only moves your work between devices.",
                            tone = BannerTone.INFO,
                        )
                    }

                    4 -> OnboardingPage(
                        icon = Icons.Filled.CloudOff,
                        title = "Offline first",
                        body = "Every job, photo, quote and signature is written to encrypted storage on this device first. When you get signal, changes upload quietly in the background.",
                    ) {
                        SectionCard(title = "Sync") {
                            SwitchRow(
                                label = "Auto-sync when online",
                                caption = "Background sync every 30 minutes",
                                checked = autoSync,
                                onCheckedChange = { autoSync = it },
                            )
                            SwitchRow(
                                label = "Only sync on Wi-Fi",
                                caption = "Saves mobile data on big photo sets",
                                checked = wifiOnly,
                                onCheckedChange = { wifiOnly = it },
                            )
                            VSpace(8)
                            Text(
                                "Sync endpoint: ${container.syncModeLabel}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }

                    else -> OnboardingPage(
                        icon = Icons.Filled.CheckCircle,
                        title = "One last thing",
                        body = "FieldFlow needs the camera to capture job photos. You can grant it now or the first time you take a picture.",
                    ) {
                        SectionCard(title = "Camera") {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Filled.CameraAlt,
                                    contentDescription = null,
                                    modifier = Modifier.size(dimens.iconLarge),
                                    tint = if (cameraGranted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                VSpace(6)
                                Column(modifier = Modifier.weight(1f).padding(start = 12.dp)) {
                                    Text(
                                        if (cameraGranted) "Camera ready" else "Camera permission",
                                        style = MaterialTheme.typography.titleSmall,
                                    )
                                    Text(
                                        if (cameraGranted) "Photos are encrypted the moment they're saved." else "Tap allow when Android asks.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                            VSpace(12)
                            BigButton(
                                text = if (cameraGranted) "Camera allowed" else "Allow camera",
                                icon = Icons.Filled.CameraAlt,
                                tone = FfButtonTone.SECONDARY,
                                enabled = !cameraGranted,
                                modifier = Modifier.fillMaxWidth(),
                                onClick = { cameraLauncher.launch(Manifest.permission.CAMERA) },
                            )
                        }
                        VSpace(14)
                        SectionCard(title = "Signature pad") {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Filled.Gesture,
                                    contentDescription = null,
                                    modifier = Modifier.size(dimens.iconLarge),
                                    tint = MaterialTheme.colorScheme.primary,
                                )
                                Text(
                                    "Customers sign on screen; the image plus a SHA-256 hash is attached to the job packet.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.padding(start = 12.dp),
                                )
                            }
                        }
                    }
                }
                VSpace(20)
            }
        }

        Column(modifier = Modifier.padding(horizontal = dimens.gutter, vertical = 12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                repeat(PAGE_COUNT) { index ->
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 4.dp)
                            .size(if (index == pagerState.currentPage) 12.dp else 8.dp)
                            .clip(CircleShape)
                            .background(
                                if (index == pagerState.currentPage) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.outlineVariant,
                            ),
                    )
                }
            }
            VSpace(12)
            val last = pagerState.currentPage == PAGE_COUNT - 1
            BigButton(
                text = if (last) "Start using FieldFlow" else "Next",
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    if (last) {
                        finish(skip = false)
                    } else {
                        val target = pagerState.currentPage + 1
                        persist()
                        container.analytics.log(AnalyticsEvents.ONBOARDING_STEP, mapOf("step" to target))
                        scope.launch { pagerState.animateScrollToPage(target) }
                    }
                },
            )
            if (pagerState.currentPage > 0) {
                VSpace(8)
                RowButton(
                    text = "Back",
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { scope.launch { pagerState.animateScrollToPage(pagerState.currentPage - 1) } },
                )
            }
        }
    }
}

@Composable
private fun OnboardingPage(
    icon: ImageVector,
    title: String,
    body: String,
    content: @Composable () -> Unit,
) {
    val dimens = LocalFfDimens.current
    Column(modifier = Modifier.fillMaxWidth()) {
        VSpace(16)
        Icon(
            icon,
            contentDescription = null,
            modifier = Modifier.size(dimens.iconLarge * 1.6f),
            tint = MaterialTheme.colorScheme.primary,
        )
        VSpace(12)
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        VSpace(8)
        Text(
            body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        VSpace(18)
        content()
    }
}

@Composable
private fun FeatureLine(text: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(
            Icons.Filled.CheckCircle,
            contentDescription = null,
            modifier = Modifier.size(LocalFfDimens.current.iconMedium),
            tint = MaterialTheme.colorScheme.secondary,
        )
        Text(
            text,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(start = 10.dp),
        )
    }
}

@Composable
private fun ChoiceRow(label: String, active: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (active) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        shape = MaterialTheme.shapes.small,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(MaterialTheme.shapes.small)
            .clickable(onClick = onClick),
    ) {
        Row(modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                label,
                style = MaterialTheme.typography.bodyLarge,
                color = if (active) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f),
            )
            if (active) {
                Text(
                    "Selected",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    textAlign = TextAlign.End,
                )
            }
        }
    }
}

@Composable
private fun SwitchRow(
    label: String,
    caption: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.titleSmall)
            Text(caption, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
