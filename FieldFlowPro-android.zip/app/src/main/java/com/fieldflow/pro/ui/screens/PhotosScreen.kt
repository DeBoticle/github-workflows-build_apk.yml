package com.fieldflow.pro.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.core.analytics.AnalyticsEvents
import com.fieldflow.pro.data.model.Photo
import com.fieldflow.pro.data.model.PhotoKind
import com.fieldflow.pro.ui.components.BigButton
import com.fieldflow.pro.ui.components.ChipPicker
import com.fieldflow.pro.ui.components.ConfirmDialog
import com.fieldflow.pro.ui.components.FfButtonTone
import com.fieldflow.pro.ui.components.FfScreen
import com.fieldflow.pro.ui.components.InfoBanner
import com.fieldflow.pro.ui.components.PhotoThumb
import com.fieldflow.pro.ui.components.SectionCard
import com.fieldflow.pro.ui.components.VSpace
import com.fieldflow.pro.ui.components.rememberThumbnail
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun PhotosScreen(
    container: AppContainer,
    jobId: String,
    onBack: () -> Unit,
    onMarkup: (String) -> Unit,
    onCompare: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val job by container.jobs.observe(jobId).collectAsState(initial = null)
    val photos by container.photos.observeForJob(jobId).collectAsState(initial = emptyList())

    var kind by remember { mutableStateOf(PhotoKind.BEFORE) }
    var cameraGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED)
    }
    var cameraReady by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<Photo?>(null) }
    val imageCapture = remember { mutableStateOf<ImageCapture?>(null) }

    fun notify(message: String) {
        scope.launch { snackbar.showSnackbar(message) }
    }

    fun importFrom(path: File, photoKind: PhotoKind) {
        scope.launch {
            runCatching {
                val photo = container.photoStore.importPhoto(path, jobId, photoKind)
                container.photos.save(photo, AnalyticsEvents.PHOTO_ADDED)
                container.jobs.attachPhoto(jobId, photo.id)
                notify("${photoKind.displayName} photo saved (encrypted)")
            }.onFailure {
                container.logger.e("Photos", "Import failed", it)
                notify("Could not save that photo")
            }
        }
    }

    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        cameraGranted = granted
        if (!granted) notify("Camera permission denied — you can still import photos")
    }

    val galleryPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val target = container.photoStore.newCaptureFile()
            val copied = runCatching {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    target.outputStream().use { output -> input.copyTo(output) }
                }
            }.isSuccess
            if (copied) importFrom(target, kind) else notify("Could not read that image")
        }
    }

    fun takePhoto() {
        val capture = imageCapture.value
        if (capture == null) {
            notify("Camera is still starting up")
            return
        }
        val target = container.photoStore.newCaptureFile()
        val options = ImageCapture.OutputFileOptions.Builder(target).build()
        capture.takePicture(
            options,
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    importFrom(target, kind)
                }

                override fun onError(exception: ImageCaptureException) {
                    container.logger.e("Photos", "Capture failed", exception)
                    notify("Capture failed: ${exception.message ?: "unknown error"}")
                }
            },
        )
    }

    FfScreen(
        title = "Job photos",
        subtitle = job?.let { "${it.number} · ${photos.size} photo(s)" } ?: "Loading…",
        onBack = onBack,
        snackbarHostState = snackbar,
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .navigationBarsPadding(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                SectionCard(title = "Photo type", subtitle = "Tag evidence as before or after for compare") {
                    ChipPicker(
                        options = listOf(PhotoKind.BEFORE.displayName, PhotoKind.AFTER.displayName, PhotoKind.DETAIL.displayName),
                        selected = kind.displayName,
                        onSelect = { label ->
                            kind = PhotoKind.entries.firstOrNull { it.displayName == label } ?: kind
                        },
                    )
                }
            }

            item {
                SectionCard(title = "Camera", subtitle = if (cameraGranted) "Tap capture — saved encrypted" else "Permission needed") {
                    if (!cameraGranted) {
                        InfoBanner("FieldFlow needs camera access to capture job photos.", tone = com.fieldflow.pro.ui.components.BannerTone.WARNING)
                        VSpace(10)
                        BigButton(
                            text = "Allow camera",
                            icon = Icons.Filled.CameraAlt,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { cameraPermission.launch(Manifest.permission.CAMERA) },
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(300.dp)
                                .clip(RoundedCornerShape(16.dp)),
                        ) {
                            CameraPreview(
                                imageCapture = imageCapture,
                                onReady = { cameraReady = true },
                                onError = { message ->
                                    cameraReady = false
                                    notify(message)
                                },
                            )
                            if (!cameraReady) {
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.fillMaxSize(),
                                ) {
                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                                        Text("Starting camera…", style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }
                        VSpace(10)
                        BigButton(
                            text = "Capture ${kind.displayName} photo",
                            subtitle = "Stored in the encrypted vault",
                            icon = Icons.Filled.CameraAlt,
                            enabled = cameraReady,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { takePhoto() },
                        )
                    }
                    VSpace(10)
                    BigButton(
                        text = "Import from gallery",
                        icon = Icons.Filled.PhotoLibrary,
                        tone = FfButtonTone.SECONDARY,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            galleryPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                    )
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BigButton(
                        text = "Compare",
                        subtitle = "Before / after slider",
                        icon = Icons.Filled.Compare,
                        tone = FfButtonTone.SECONDARY,
                        modifier = Modifier.weight(1f),
                        onClick = onCompare,
                    )
                    BigButton(
                        text = "Markup",
                        subtitle = photos.firstOrNull()?.let { "Newest first" } ?: "Add a photo first",
                        icon = Icons.Filled.Draw,
                        tone = FfButtonTone.SECONDARY,
                        enabled = photos.isNotEmpty(),
                        modifier = Modifier.weight(1f),
                        onClick = { photos.lastOrNull()?.let { onMarkup(it.id) } },
                    )
                }
            }

            item {
                Text(
                    "Evidence (${photos.size})",
                    style = MaterialTheme.typography.titleLarge,
                )
            }

            if (photos.isEmpty()) {
                item {
                    InfoBanner("No photos yet. Capture a before shot as soon as you arrive — it wins arguments later.")
                }
            } else {
                items((photos.size + 1) / 2) { rowIndex ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        val left = photos[rowIndex * 2]
                        PhotoCellItem(container, left, onMarkup, { pendingDelete = left }, Modifier.weight(1f))
                        val right = photos.getOrNull(rowIndex * 2 + 1)
                        if (right != null) {
                            PhotoCellItem(container, right, onMarkup, { pendingDelete = right }, Modifier.weight(1f))
                        } else {
                            Box(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }

            item { VSpace(30) }
        }
    }

    pendingDelete?.let { photo ->
        ConfirmDialog(
            title = "Delete this photo?",
            message = "The encrypted file is removed from this device and the deletion is queued to sync.",
            confirmLabel = "Delete photo",
            destructive = true,
            onConfirm = {
                pendingDelete = null
                scope.launch {
                    container.photos.softDelete(photo.id)
                    container.photoStore.deletePhotoFile(photo)
                    container.jobs.detachPhoto(jobId, photo.id)
                    notify("Photo deleted")
                }
            },
            onDismiss = { pendingDelete = null },
        )
    }

    LaunchedEffect(jobId) {
        container.analytics.log("photo_screen_open", mapOf("job_id" to jobId))
    }
}

@Composable
private fun PhotoCellItem(
    container: AppContainer,
    photo: Photo,
    onMarkup: (String) -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val file = rememberThumbnail(container.photoStore, photo, 480)
    Column(modifier = modifier) {
        PhotoThumb(
            model = file,
            label = photo.kind.displayName,
            onClick = { onMarkup(photo.id) },
        )
        VSpace(6)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            BigButton(
                text = "Markup",
                icon = Icons.Filled.Draw,
                tone = FfButtonTone.SECONDARY,
                modifier = Modifier.weight(1f),
                onClick = { onMarkup(photo.id) },
            )
            BigButton(
                text = "",
                icon = Icons.Filled.Delete,
                tone = FfButtonTone.DANGER,
                modifier = Modifier.weight(1f),
                onClick = onDelete,
            )
        }
    }
}

@Composable
private fun CameraPreview(
    imageCapture: androidx.compose.runtime.MutableState<ImageCapture?>,
    onReady: () -> Unit,
    onError: (String) -> Unit,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember { PreviewView(context).apply { scaleType = PreviewView.ScaleType.FILL_CENTER } }

    AndroidView(
        factory = { previewView },
        modifier = Modifier.fillMaxSize(),
    )

    DisposableEffect(lifecycleOwner) {
        val future = ProcessCameraProvider.getInstance(context)
        val listener = Runnable {
            runCatching {
                val provider = future.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                provider.unbindAll()
                provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
                imageCapture.value = capture
                onReady()
            }.onFailure {
                onError("Camera unavailable: ${it.message ?: "unknown"}")
            }
        }
        future.addListener(listener, ContextCompat.getMainExecutor(context))
        onDispose {
            runCatching { ProcessCameraProvider.getInstance(context).get().unbindAll() }
            imageCapture.value = null
        }
    }
}
