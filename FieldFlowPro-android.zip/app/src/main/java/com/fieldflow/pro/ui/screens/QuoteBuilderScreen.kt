package com.fieldflow.pro.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.core.Dates
import com.fieldflow.pro.core.Money
import com.fieldflow.pro.core.analytics.AnalyticsEvents
import com.fieldflow.pro.data.model.Quote
import com.fieldflow.pro.data.model.QuoteLine
import com.fieldflow.pro.data.model.QuoteLineKind
import com.fieldflow.pro.data.model.QuoteStatus
import com.fieldflow.pro.data.model.TemplateLine
import com.fieldflow.pro.data.model.TradeTemplate
import com.fieldflow.pro.ui.components.BigButton
import com.fieldflow.pro.ui.components.ChipPicker
import com.fieldflow.pro.ui.components.FfButtonTone
import com.fieldflow.pro.ui.components.FfMoneyInput
import com.fieldflow.pro.ui.components.FfPercentInput
import com.fieldflow.pro.ui.components.FfQtyInput
import com.fieldflow.pro.ui.components.FfScreen
import com.fieldflow.pro.ui.components.FfTextField
import com.fieldflow.pro.ui.components.InfoBanner
import com.fieldflow.pro.ui.components.RowButton
import com.fieldflow.pro.ui.components.SectionCard
import com.fieldflow.pro.ui.components.TotalRow
import com.fieldflow.pro.ui.components.VSpace
import kotlinx.coroutines.launch

@Composable
fun QuoteBuilderScreen(
    container: AppContainer,
    jobId: String,
    onBack: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val job by container.jobs.observe(jobId).collectAsState(initial = null)
    val settings by container.settings.settings.collectAsState()

    var loaded by remember(jobId) { mutableStateOf(false) }
    var quote by remember(jobId) { mutableStateOf<Quote?>(null) }
    var lines by remember(jobId) { mutableStateOf<List<QuoteLine>>(emptyList()) }
    var taxRate by remember(jobId) { mutableStateOf(0.0) }
    var terms by remember(jobId) { mutableStateOf("") }
    var notes by remember(jobId) { mutableStateOf("") }
    var validUntil by remember(jobId) { mutableStateOf(0L) }
    var status by remember(jobId) { mutableStateOf(QuoteStatus.DRAFT) }
    var saving by remember { mutableStateOf(false) }
    var showTemplatePicker by remember(jobId) { mutableStateOf(false) }
    var showSaveTemplate by remember { mutableStateOf(false) }
    var templateName by remember { mutableStateOf("") }

    LaunchedEffect(jobId) {
        val existing = container.quotes.latestForJob(jobId)
        if (existing != null) {
            quote = existing
            lines = existing.lines
            taxRate = existing.taxRatePercent
            terms = existing.terms
            notes = existing.notes
            validUntil = existing.validUntil
            status = existing.status
        } else {
            taxRate = settings.defaultTaxRatePercent
            terms = settings.defaultQuoteTerms
            validUntil = System.currentTimeMillis() + settings.defaultValidDays * 86_400_000L
            showTemplatePicker = true
        }
        loaded = true
    }

    val subtotal = lines.sumOf { it.lineTotalCents }
    val discount = lines.filter { it.kind == QuoteLineKind.DISCOUNT }.sumOf { -it.lineTotalCents }
    val taxableBase = lines.filter { it.taxable && it.kind != QuoteLineKind.DISCOUNT }.sumOf { it.lineTotalCents }
    val tax = Math.round(taxableBase * (taxRate / 100.0))
    val total = subtotal + tax

    fun saveQuote(extraEvent: String = AnalyticsEvents.QUOTE_UPDATED) {
        val jobValue = job ?: return
        saving = true
        scope.launch {
            val base = quote ?: Quote(jobId = jobId, createdAt = System.currentTimeMillis())
            val saved = container.quotes.save(
                base.copy(
                    lines = lines,
                    taxRatePercent = taxRate,
                    terms = terms,
                    notes = notes,
                    validUntil = validUntil,
                    status = status,
                ),
                event = extraEvent,
            )
            quote = saved
            saving = false
            snackbar.showSnackbar("Quote ${saved.number} saved")
            if (jobValue.status == com.fieldflow.pro.data.model.JobStatus.DRAFT) {
                container.jobs.setStatus(jobValue.id, com.fieldflow.pro.data.model.JobStatus.SCHEDULED)
            }
        }
    }

    FfScreen(
        title = "Quote builder",
        subtitle = job?.let { "${it.number} · ${it.clientName.ifBlank { "no client" }}" } ?: "Loading…",
        onBack = onBack,
        snackbarHostState = snackbar,
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            ) {
                TotalRow("Quote total", Money.format(total, settings.currencyCode))
                VSpace(8)
                BigButton(
                    text = if (quote == null) "Create quote" else "Save quote",
                    icon = Icons.Filled.Save,
                    loading = saving,
                    enabled = lines.isNotEmpty() && loaded,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { saveQuote(if (quote == null) AnalyticsEvents.QUOTE_CREATED else AnalyticsEvents.QUOTE_UPDATED) },
                )
            }
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (showTemplatePicker) {
                item {
                    SectionCard(
                        title = "Start from a template",
                        subtitle = job?.trade?.displayName ?: "Pick a trade",
                    ) {
                        val options = job?.let { container.templates.forTrade(it.trade) } ?: emptyList()
                        if (options.isEmpty()) {
                            Text(
                                "No templates for this trade. Add lines manually below.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        options.forEach { template ->
                            VSpace(8)
                            BigButton(
                                text = template.name,
                                subtitle = template.summary,
                                icon = Icons.Filled.Description,
                                tone = FfButtonTone.SECONDARY,
                                modifier = Modifier.fillMaxWidth(),
                                onClick = {
                                    val jobValue = job
                                    if (jobValue != null) {
                                        val fresh = container.templates.newQuoteFor(jobValue, template, settings, System.currentTimeMillis())
                                        lines = fresh.lines
                                        taxRate = fresh.taxRatePercent
                                        terms = fresh.terms
                                        validUntil = fresh.validUntil
                                        container.analytics.log(
                                            AnalyticsEvents.TEMPLATE_APPLIED,
                                            mapOf("template_id" to template.id, "context" to "quote"),
                                        )
                                    }
                                    showTemplatePicker = false
                                    snackbarMessage(scope, snackbar, "${template.name} lines added")
                                },
                            )
                        }
                        if (options.isNotEmpty()) {
                            VSpace(10)
                            RowButton(
                                text = "Start blank instead",
                                modifier = Modifier.fillMaxWidth(),
                                onClick = { showTemplatePicker = false },
                            )
                        }
                    }
                }
            }

            item {
                SectionCard(
                    title = "Line items",
                    subtitle = "${lines.size} line(s) · totals update as you type",
                    trailing = {
                        RowButton(
                            text = "Add",
                            icon = Icons.Filled.Add,
                            onClick = { lines = lines + QuoteLine(kind = QuoteLineKind.MATERIAL) },
                        )
                    },
                ) {
                    if (lines.isEmpty()) {
                        InfoBanner("Add labour, materials, fees or a discount. The total at the bottom updates live.")
                    }
                    lines.forEachIndexed { index, line ->
                        key(line.id) {
                            if (index > 0) VSpace(14)
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        "${index + 1}. ${line.kind.displayName}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.weight(1f),
                                    )
                                    RowButton(
                                        text = "Remove",
                                        icon = Icons.Filled.Delete,
                                        onClick = { lines = lines.filterNot { it.id == line.id } },
                                    )
                                }
                                VSpace(8)
                                ChipPicker(
                                    options = QuoteLineKind.entries.map { it.displayName },
                                    selected = line.kind.displayName,
                                    onSelect = { label ->
                                        val kind = QuoteLineKind.entries.firstOrNull { it.displayName == label } ?: line.kind
                                        lines = lines.map { if (it.id == line.id) it.copy(kind = kind) else it }
                                    },
                                )
                                VSpace(8)
                                FfTextField(
                                    value = line.description,
                                    onValueChange = { text ->
                                        lines = lines.map { if (it.id == line.id) it.copy(description = text) else it }
                                    },
                                    label = "Description",
                                    placeholder = "e.g. 40 gal gas water heater, 6yr warranty",
                                )
                                VSpace(8)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FfQtyInput(
                                        value = line.quantity,
                                        onValueChange = { qty -> lines = lines.map { if (it.id == line.id) it.copy(quantity = qty) else it } },
                                        label = if (line.kind == QuoteLineKind.LABOUR) "Hours" else "Qty",
                                        modifier = Modifier.weight(1f),
                                    )
                                    FfTextField(
                                        value = line.unit,
                                        onValueChange = { text -> lines = lines.map { if (it.id == line.id) it.copy(unit = text) else it } },
                                        label = "Unit",
                                        modifier = Modifier.weight(1f),
                                    )
                                }
                                VSpace(8)
                                FfMoneyInput(
                                    cents = line.unitPriceCents,
                                    onCentsChange = { cents -> lines = lines.map { if (it.id == line.id) it.copy(unitPriceCents = cents) else it } },
                                    label = if (line.kind == QuoteLineKind.LABOUR) "Rate / hour" else "Unit price",
                                    supportingText = "Line total ${Money.format(line.lineTotalCents, settings.currencyCode)}",
                                )
                                VSpace(8)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Switch(
                                        checked = line.taxable,
                                        onCheckedChange = { checked ->
                                            lines = lines.map { if (it.id == line.id) it.copy(taxable = checked) else it }
                                        },
                                    )
                                    Text(
                                        "  Taxable",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                SectionCard(title = "Totals") {
                    TotalRow("Subtotal", Money.format(subtotal, settings.currencyCode))
                    VSpace(6)
                    if (discount > 0) {
                        TotalRow("Discount", "-" + Money.format(discount, settings.currencyCode))
                        VSpace(6)
                    }
                    TotalRow("Tax", Money.format(tax, settings.currencyCode))
                    VSpace(6)
                    TotalRow("Total", Money.format(total, settings.currencyCode))
                    VSpace(10)
                    FfPercentInput(
                        value = taxRate,
                        onValueChange = { taxRate = it },
                        label = "Tax rate %",
                    )
                }
            }

            item {
                SectionCard(title = "Status and validity") {
                    ChipPicker(
                        options = QuoteStatus.entries.map { it.displayName },
                        selected = status.displayName,
                        onSelect = { label ->
                            val next = QuoteStatus.entries.firstOrNull { it.displayName == label } ?: status
                            status = next
                            if (quote != null) {
                                container.analytics.log(
                                    AnalyticsEvents.QUOTE_STATUS_CHANGED,
                                    mapOf("quote_id" to quote?.id.orEmpty(), "status" to next.name),
                                )
                            }
                        },
                    )
                    VSpace(10)
                    Text(
                        "Valid until: ${if (validUntil == 0L) "—" else Dates.formatDate(validUntil)}",
                        style = MaterialTheme.typography.titleSmall,
                    )
                    VSpace(8)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(7, 14, 30).forEach { days ->
                            RowButton(
                                text = "+$days days",
                                modifier = Modifier.weight(1f),
                                onClick = { validUntil = System.currentTimeMillis() + days * 86_400_000L },
                            )
                        }
                    }
                }
            }

            item {
                SectionCard(title = "Notes and terms") {
                    FfTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = "Notes for the customer",
                        singleLine = false,
                        minLines = 2,
                    )
                    VSpace(12)
                    FfTextField(
                        value = terms,
                        onValueChange = { terms = it },
                        label = "Terms",
                        singleLine = false,
                        minLines = 4,
                    )
                    VSpace(12)
                    BigButton(
                        text = "Save as a custom template",
                        subtitle = "Reuse these lines on the next job",
                        icon = Icons.Filled.Star,
                        tone = FfButtonTone.SECONDARY,
                        enabled = lines.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { templateName = ""; showSaveTemplate = true },
                    )
                }
            }

            item { VSpace(90) }
        }
    }

    if (showSaveTemplate) {
        AlertDialog(
            onDismissRequest = { showSaveTemplate = false },
            title = { Text("Name this template") },
            text = {
                Column {
                    FfTextField(
                        value = templateName,
                        onValueChange = { templateName = it },
                        label = "Template name",
                        placeholder = "e.g. Commercial rooftop service",
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val jobValue = job
                        if (jobValue != null && templateName.isNotBlank()) {
                            val template = TradeTemplate(
                                trade = jobValue.trade,
                                name = templateName.trim(),
                                summary = notes.ifBlank { "Custom quote template" }.take(120),
                                defaultTitle = jobValue.title,
                                defaultDescription = jobValue.description,
                                labourHours = jobValue.labourHours,
                                lines = lines.map {
                                    TemplateLine(
                                        kind = it.kind,
                                        description = it.description,
                                        detail = it.detail,
                                        quantity = it.quantity,
                                        unit = it.unit,
                                        unitPriceCents = it.unitPriceCents,
                                    )
                                },
                                checklist = emptyList(),
                            )
                            scope.launch {
                                container.templates.saveCustom(template)
                                snackbar.showSnackbar("Template saved")
                            }
                        }
                        showSaveTemplate = false
                    },
                ) { Text("Save template") }
            },
            dismissButton = {
                TextButton(onClick = { showSaveTemplate = false }) { Text("Cancel") }
            },
        )
    }
}

private fun snackbarMessage(scope: kotlinx.coroutines.CoroutineScope, host: SnackbarHostState, message: String) {
    scope.launch { host.showSnackbar(message) }
}
