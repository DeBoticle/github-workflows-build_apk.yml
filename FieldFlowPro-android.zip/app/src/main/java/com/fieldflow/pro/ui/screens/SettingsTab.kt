package com.fieldflow.pro.ui.screens

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.fieldflow.pro.core.AppResult
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.core.Bytes
import com.fieldflow.pro.core.Dates
import com.fieldflow.pro.core.Money
import com.fieldflow.pro.data.model.ThemeMode
import com.fieldflow.pro.ui.components.BannerTone
import com.fieldflow.pro.ui.components.BigButton
import com.fieldflow.pro.ui.components.ChipPicker
import com.fieldflow.pro.ui.components.ConfirmDialog
import com.fieldflow.pro.ui.components.FfButtonTone
import com.fieldflow.pro.ui.components.FfMoneyField
import com.fieldflow.pro.ui.components.FfScreen
import com.fieldflow.pro.ui.components.FfTextField
import com.fieldflow.pro.ui.components.InfoBanner
import com.fieldflow.pro.ui.components.RowButton
import com.fieldflow.pro.ui.components.SectionCard
import com.fieldflow.pro.ui.components.SwitchRow
import com.fieldflow.pro.ui.components.VSpace
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun SettingsTab(
    container: AppContainer,
    onOpenTemplates: () -> Unit,
    onOpenAnalytics: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    onOpenAbout: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by container.settings.settings.collectAsState()
    val session by container.auth.session.collectAsState()
    val syncState by container.sync.state.collectAsState()
    val queuePending by container.queue.pendingCount.collectAsState()
    val failedOps by container.queue.failedCount.collectAsState()
    val snackbar = remember { SnackbarHostState() }

    var businessName by remember(settings.businessName) { mutableStateOf(settings.businessName) }
    var businessPhone by remember(settings.businessPhone) { mutableStateOf(settings.businessPhone) }
    var businessEmail by remember(settings.businessEmail) { mutableStateOf(settings.businessEmail) }
    var businessAddress by remember(settings.businessAddress) { mutableStateOf(settings.businessAddress) }
    var licence by remember(settings.licenceNumber) { mutableStateOf(settings.licenceNumber) }
    var labourRate by remember(settings.defaultLabourRateCents) {
        mutableStateOf(if (settings.defaultLabourRateCents > 0) Money.formatPlain(settings.defaultLabourRateCents) else "")
    }
    var taxRate by remember(settings.defaultTaxRatePercent) {
        mutableStateOf(if (settings.defaultTaxRatePercent > 0) settings.defaultTaxRatePercent.toString() else "")
    }
    var displayName by remember(session?.displayName) { mutableStateOf(session?.displayName.orEmpty()) }

    var showPasswordDialog by remember { mutableStateOf(false) }
    var showDeleteAccount by remember { mutableStateOf(false) }
    var showWipe by remember { mutableStateOf(false) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val staged = File(context.cacheDir, "imported-backup.ffbackup")
            val copied = runCatching {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    staged.outputStream().use { output -> input.copyTo(output) }
                }
            }.isSuccess
            if (!copied) {
                snackbar.showSnackbar("Could not read that file")
                return@launch
            }
            when (val result = container.importBackup(staged)) {
                is AppResult.Success -> snackbar.showSnackbar("Restored ${result.value} job(s) from backup")
                is AppResult.Failure -> snackbar.showSnackbar(result.error.userMessage())
            }
            staged.delete()
        }
    }

    fun saveBusiness() {
        scope.launch {
            container.settings.update { current ->
                current.copy(
                    businessName = businessName.trim(),
                    businessPhone = businessPhone.trim(),
                    businessEmail = businessEmail.trim(),
                    businessAddress = businessAddress.trim(),
                    licenceNumber = licence.trim(),
                    defaultLabourRateCents = labourRate.toDoubleOrNull()?.let { Math.round(it * 100) }
                        ?: current.defaultLabourRateCents,
                    defaultTaxRatePercent = taxRate.toDoubleOrNull() ?: current.defaultTaxRatePercent,
                )
            }
            snackbar.showSnackbar("Business profile saved")
        }
    }

    fun shareBackup() {
        scope.launch {
            when (val result = container.exportBackup()) {
                is AppResult.Success -> {
                    val file = result.value
                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/octet-stream"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, "FieldFlow Pro backup — ${file.name}")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    runCatching { context.startActivity(Intent.createChooser(intent, "Save or share backup")) }
                        .onFailure { snackbar.showSnackbar("No app available to receive the backup") }
                }

                is AppResult.Failure -> snackbar.showSnackbar(result.error.userMessage())
            }
        }
    }

    FfScreen(
        title = "Settings",
        subtitle = session?.email.orEmpty(),
        snackbarHostState = snackbar,
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                SectionCard(
                    title = "Business profile",
                    subtitle = "Appears on every quote and job packet",
                ) {
                    FfTextField(businessName, { businessName = it }, "Business name")
                    VSpace(12)
                    FfTextField(businessPhone, { businessPhone = it }, "Phone")
                    VSpace(12)
                    FfTextField(businessEmail, { businessEmail = it }, "Email")
                    VSpace(12)
                    FfTextField(businessAddress, { businessAddress = it }, "Business address", singleLine = false, minLines = 2)
                    VSpace(12)
                    FfTextField(licence, { licence = it }, "Licence / registration")
                    VSpace(12)
                    FfMoneyField(labourRate, { labourRate = it }, "Default labour rate / hour")
                    VSpace(12)
                    FfTextField(taxRate, { taxRate = it.filter { c -> c.isDigit() || c == '.' } }, "Default tax rate %")
                    VSpace(14)
                    BigButton(
                        text = "Save business profile",
                        icon = Icons.Filled.Save,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { saveBusiness() },
                    )
                }
            }

            item {
                SectionCard(title = "Work style", subtitle = "Glove mode enlarges every control") {
                    Text("Theme", style = MaterialTheme.typography.titleSmall)
                    VSpace(6)
                    ChipPicker(
                        options = ThemeMode.entries.map { it.displayName },
                        selected = settings.themeMode.displayName,
                        onSelect = { label ->
                            val mode = ThemeMode.entries.firstOrNull { it.displayName == label } ?: ThemeMode.SYSTEM
                            scope.launch { container.settings.update { it.copy(themeMode = mode) } }
                        },
                    )
                    VSpace(10)
                    SwitchRow(
                        label = "Glove mode",
                        caption = "84dp touch targets, larger type",
                        checked = settings.gloveMode,
                        onCheckedChange = { enabled ->
                            scope.launch {
                                container.settings.update { it.copy(gloveMode = enabled) }
                                container.analytics.log("settings_changed", mapOf("key" to "glove_mode", "value" to enabled))
                            }
                        },
                    )
                    SwitchRow(
                        label = "Haptic feedback",
                        caption = "Buzzer feedback on big actions",
                        checked = settings.hapticsEnabled,
                        onCheckedChange = { enabled ->
                            scope.launch { container.settings.update { it.copy(hapticsEnabled = enabled) } }
                        },
                    )
                }
            }

            item {
                SectionCard(title = "Offline sync") {
                    InfoBanner(
                        text = "Endpoint: ${container.syncModeLabel}",
                        tone = if (container.syncEndpointConfigured) BannerTone.INFO else BannerTone.WARNING,
                    )
                    VSpace(10)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        com.fieldflow.pro.ui.components.StatTile(
                            "Waiting",
                            queuePending.toString(),
                            caption = "$failedOps failed",
                            modifier = Modifier.weight(1f),
                        )
                        com.fieldflow.pro.ui.components.StatTile(
                            "Last sync",
                            Dates.relative(settings.lastSyncAt),
                            caption = if (syncState.online) "Online" else "Offline",
                            modifier = Modifier.weight(1f),
                        )
                    }
                    VSpace(10)
                    SwitchRow(
                        label = "Auto-sync when online",
                        caption = "Background sync every 30 minutes",
                        checked = settings.autoSync,
                        onCheckedChange = { enabled ->
                            scope.launch {
                                container.settings.update { it.copy(autoSync = enabled) }
                                container.applySyncPolicy()
                            }
                        },
                    )
                    SwitchRow(
                        label = "Only sync on Wi-Fi",
                        checked = settings.syncOnWifiOnly,
                        onCheckedChange = { enabled ->
                            scope.launch {
                                container.settings.update { it.copy(syncOnWifiOnly = enabled) }
                                container.applySyncPolicy()
                            }
                        },
                    )
                    VSpace(10)
                    BigButton(
                        text = if (syncState.isSyncing) "Syncing…" else "Sync now",
                        subtitle = if (settings.lastSyncError.isBlank()) null else settings.lastSyncError,
                        icon = Icons.Filled.Sync,
                        loading = syncState.isSyncing,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            scope.launch {
                                val outcome = container.syncNow("settings")
                                snackbar.showSnackbar(
                                    when (outcome) {
                                        is com.fieldflow.pro.data.sync.SyncOutcome.Success -> "Synced ${outcome.pushed} up / ${outcome.pulled} down"
                                        com.fieldflow.pro.data.sync.SyncOutcome.Offline -> "Offline — nothing uploaded"
                                        com.fieldflow.pro.data.sync.SyncOutcome.NothingToDo -> "Nothing to sync"
                                        is com.fieldflow.pro.data.sync.SyncOutcome.Failure -> outcome.message
                                    },
                                )
                            }
                        },
                    )
                }
            }

            item {
                SectionCard(title = "Data and storage", subtitle = "Encrypted vault on this device") {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        com.fieldflow.pro.ui.components.StatTile(
                            "Media",
                            Bytes.human(container.photoStore.vaultBytes()),
                            modifier = Modifier.weight(1f),
                        )
                        com.fieldflow.pro.ui.components.StatTile(
                            "Records",
                            Bytes.human(container.vault.sizeBytes()),
                            caption = "${container.vault.files().size} files",
                            modifier = Modifier.weight(1f),
                        )
                    }
                    VSpace(12)
                    BigButton(
                        text = "Export backup",
                        subtitle = "Jobs, photos, signatures in one file",
                        icon = Icons.Filled.Download,
                        tone = FfButtonTone.SECONDARY,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { shareBackup() },
                    )
                    VSpace(10)
                    BigButton(
                        text = "Restore from backup",
                        subtitle = "Replaces the local vault contents",
                        icon = Icons.Filled.Upload,
                        tone = FfButtonTone.SECONDARY,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { importLauncher.launch(arrayOf("*/*")) },
                    )
                    VSpace(10)
                    BigButton(
                        text = "Clear image cache",
                        subtitle = "Decrypted preview copies only",
                        icon = Icons.Filled.Storage,
                        tone = FfButtonTone.SECONDARY,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            val removed = container.photoStore.clearPreviews()
                            snackbar.showSnackbar("Cleared $removed cached image(s)")
                        },
                    )
                    VSpace(10)
                    BigButton(
                        text = "Delete all local data",
                        subtitle = "Jobs, photos, signatures and settings",
                        icon = Icons.Filled.DeleteForever,
                        tone = FfButtonTone.DANGER,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { showWipe = true },
                    )
                }
            }

            item {
                SectionCard(title = "Privacy and diagnostics") {
                    SwitchRow(
                        label = "Share anonymous analytics",
                        caption = "Feature usage only — never job content",
                        checked = settings.analyticsOptIn,
                        onCheckedChange = { enabled ->
                            scope.launch {
                                container.settings.update { it.copy(analyticsOptIn = enabled) }
                                container.analytics.setOptIn(enabled)
                            }
                        },
                    )
                    VSpace(10)
                    RowButton(
                        text = "Analytics events",
                        icon = Icons.Filled.BarChart,
                        trailingText = "${container.analytics.queueSize} queued",
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onOpenAnalytics,
                    )
                    VSpace(8)
                    RowButton(
                        text = "Diagnostics",
                        icon = Icons.Filled.BugReport,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onOpenDiagnostics,
                    )
                    VSpace(8)
                    RowButton(
                        text = "Trade templates",
                        icon = Icons.Filled.Description,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onOpenTemplates,
                    )
                    VSpace(8)
                    RowButton(
                        text = "About FieldFlow Pro",
                        icon = Icons.Filled.Info,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onOpenAbout,
                    )
                }
            }

            item {
                SectionCard(title = "Account", subtitle = session?.email.orEmpty()) {
                    FfTextField(displayName, { displayName = it }, "Display name")
                    VSpace(10)
                    BigButton(
                        text = "Save profile",
                        icon = Icons.Filled.Save,
                        tone = FfButtonTone.SECONDARY,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            scope.launch {
                                val result = container.auth.updateProfile(displayName, businessName)
                                snackbar.showSnackbar(
                                    if (result is AppResult.Success) "Profile updated" else "Could not update profile",
                                )
                            }
                        },
                    )
                    VSpace(10)
                    RowButton(
                        text = "Change password",
                        icon = Icons.Filled.Key,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { showPasswordDialog = true },
                    )
                    VSpace(8)
                    BigButton(
                        text = "Sign out",
                        subtitle = "Local data stays on this device",
                        icon = Icons.Filled.Logout,
                        tone = FfButtonTone.SECONDARY,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { scope.launch { container.signOut() } },
                    )
                    VSpace(10)
                    BigButton(
                        text = "Delete account and data",
                        icon = Icons.Filled.Security,
                        tone = FfButtonTone.DANGER,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { showDeleteAccount = true },
                    )
                }
            }

            item { VSpace(24) }
        }
    }

    if (showPasswordDialog) {
        ChangePasswordDialog(
            container = container,
            onDismiss = { showPasswordDialog = false },
            onMessage = { scope.launch { snackbar.showSnackbar(it) } },
        )
    }

    if (showDeleteAccount) {
        ConfirmDialog(
            title = "Delete account?",
            message = "This removes your account, jobs, photos, quotes, signatures and settings from this device. This cannot be undone.",
            confirmLabel = "Delete everything",
            destructive = true,
            onConfirm = {
                showDeleteAccount = false
                scope.launch { container.deleteAllUserData() }
            },
            onDismiss = { showDeleteAccount = false },
        )
    }

    if (showWipe) {
        ConfirmDialog(
            title = "Delete all local data?",
            message = "Every job, photo, signature, quote and setting stored on this device is erased. Export a backup first if you need one.",
            confirmLabel = "Erase local data",
            destructive = true,
            onConfirm = {
                showWipe = false
                scope.launch {
                    container.wipeLocalData()
                    snackbar.showSnackbar("Local data erased")
                }
            },
            onDismiss = { showWipe = false },
        )
    }
}

@Composable
private fun ChangePasswordDialog(
    container: AppContainer,
    onDismiss: () -> Unit,
    onMessage: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var current by remember { mutableStateOf("") }
    var next by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Change password") },
        text = {
            Column {
                FfTextField(
                    value = current,
                    onValueChange = { current = it },
                    label = "Current password",
                    visualTransformation = PasswordVisualTransformation(),
                )
                VSpace(12)
                FfTextField(
                    value = next,
                    onValueChange = { next = it },
                    label = "New password",
                    visualTransformation = PasswordVisualTransformation(),
                    supportingText = "At least 8 characters with letters and numbers.",
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy,
                onClick = {
                    busy = true
                    scope.launch {
                        val result = container.auth.changePassword(current, next)
                        busy = false
                        onMessage(
                            when (result) {
                                is AppResult.Success -> "Password updated"
                                is AppResult.Failure -> result.error.userMessage()
                            },
                        )
                        if (result is AppResult.Success) onDismiss()
                    }
                },
            ) { Text("Update") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}
