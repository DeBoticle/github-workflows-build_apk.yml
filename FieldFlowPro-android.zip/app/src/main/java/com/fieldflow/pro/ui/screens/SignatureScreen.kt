package com.fieldflow.pro.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.core.Dates
import com.fieldflow.pro.data.model.AppSettings
import com.fieldflow.pro.ui.components.BigButton
import com.fieldflow.pro.ui.components.FfButtonTone
import com.fieldflow.pro.ui.components.FfScreen
import com.fieldflow.pro.ui.components.FfTextField
import com.fieldflow.pro.ui.components.InfoBanner
import com.fieldflow.pro.ui.components.KeyValueRow
import com.fieldflow.pro.ui.components.RowButton
import com.fieldflow.pro.ui.components.SectionCard
import com.fieldflow.pro.ui.components.SignaturePad
import com.fieldflow.pro.ui.components.SignatureStroke
import com.fieldflow.pro.ui.components.VSpace
import com.fieldflow.pro.ui.components.renderSignatureBitmap
import kotlinx.coroutines.launch

@Composable
fun SignatureScreen(
    container: AppContainer,
    jobId: String,
    onBack: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val job by container.jobs.observe(jobId).collectAsState(initial = null)
    val signature by container.signatures.observeForJob(jobId).collectAsState(initial = null)
    val settings by container.settings.settings.collectAsState()

    val strokes = remember { mutableStateListOf<SignatureStroke>() }
    var signerName by remember { mutableStateOf("") }
    var signerRole by remember { mutableStateOf("Customer") }
    var accepted by remember { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }
    var replacing by remember { mutableStateOf(false) }
    var existingBitmap by remember { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(signature?.id) {
        val sig = signature
        existingBitmap = if (sig == null) null else runCatching { container.photoStore.loadSignatureBitmap(sig) }.getOrNull()
    }

    fun save() {
        if (signerName.isBlank()) {
            scope.launch { snackbar.showSnackbar("Enter the signer's name first") }
            return
        }
        if (strokes.isEmpty()) {
            scope.launch { snackbar.showSnackbar("Ask the customer to sign in the box") }
            return
        }
        saving = true
        scope.launch {
            runCatching {
                val bitmap = renderSignatureBitmap(strokes.toList())
                    ?: throw IllegalStateException("Nothing was drawn")
                val sig = container.photoStore.saveSignature(
                    bitmap = bitmap,
                    jobId = jobId,
                    signerName = signerName.trim(),
                    signerRole = signerRole.trim().ifBlank { "Customer" },
                    termsVersion = AppSettings.TERMS_VERSION,
                    acceptedTerms = accepted,
                )
                val saved = container.signatures.save(sig)
                container.jobs.attachSignature(jobId, saved.id)
                bitmap.recycle()
            }.onFailure {
                container.logger.e("Signature", "Save failed", it)
                snackbar.showSnackbar("Could not save the signature")
                saving = false
                return@launch
            }
            saving = false
            strokes.clear()
            replacing = false
            snackbar.showSnackbar("Signature captured and hashed")
        }
    }

    FfScreen(
        title = "Client signature",
        subtitle = job?.let { "${it.number} · ${it.title}" } ?: "Loading…",
        onBack = onBack,
        snackbarHostState = snackbar,
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
            if (signature != null && !replacing) {
                SectionCard(
                    title = "Already signed",
                    subtitle = "${signature?.signerName} · ${signature?.let { Dates.formatDateTime(it.signedAt) }}",
                ) {
                    existingBitmap?.let { bitmap ->
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = "Signature",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp)
                                .background(Color.White),
                        )
                        VSpace(10)
                    }
                    KeyValueRow("Role", signature?.signerRole.orEmpty())
                    KeyValueRow("Terms", "accepted (${signature?.termsVersion})")
                    KeyValueRow("SHA-256", signature?.sha256?.take(28).orEmpty() + "…")
                    KeyValueRow("Signed on", signature?.deviceModel.orEmpty())
                    VSpace(12)
                    BigButton(
                        text = "Capture a new signature",
                        subtitle = "Replaces the one stored on this job",
                        icon = Icons.Filled.Gesture,
                        tone = FfButtonTone.SECONDARY,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            replacing = true
                            signerName = signature?.signerName.orEmpty()
                        },
                    )
                }
            } else {
                SectionCard(title = "Signer") {
                    FfTextField(
                        value = signerName,
                        onValueChange = { signerName = it },
                        label = "Full name",
                        placeholder = "e.g. Dana Whitfield",
                    )
                    VSpace(12)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Customer", "Property manager", "Tenant", "Site supervisor").forEach { role ->
                            RowButton(
                                text = role,
                                modifier = Modifier.weight(1f),
                                onClick = { signerRole = role },
                            )
                        }
                    }
                    VSpace(8)
                    Text(
                        "Role: $signerRole",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                VSpace(12)

                SectionCard(
                    title = "Sign below",
                    subtitle = "Ask the customer to sign with a finger",
                ) {
                    SignaturePad(
                        strokes = strokes.toList(),
                        onStrokeFinished = { stroke -> strokes.add(stroke) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp),
                    )
                    VSpace(10)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        RowButton(
                            text = "Undo",
                            enabled = strokes.isNotEmpty(),
                            modifier = Modifier.weight(1f),
                            onClick = { if (strokes.isNotEmpty()) strokes.removeAt(strokes.size - 1) },
                        )
                        RowButton(
                            text = "Clear",
                            icon = Icons.Filled.Delete,
                            enabled = strokes.isNotEmpty(),
                            modifier = Modifier.weight(1f),
                            onClick = { strokes.clear() },
                        )
                    }
                }

                VSpace(12)

                SectionCard(title = "Terms") {
                    Text(
                        settings.defaultQuoteTerms,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    VSpace(10)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = accepted, onCheckedChange = { accepted = it })
                        Text(
                            "Customer accepts the work and terms above",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                        )
                    }
                }

                VSpace(12)
                InfoBanner("The signature image and a SHA-256 hash are stored with the job and printed on the PDF packet.")
                VSpace(14)
                BigButton(
                    text = "Save signature",
                    subtitle = if (signerName.isBlank() || strokes.isEmpty()) "Name and signature required" else null,
                    icon = Icons.Filled.Save,
                    loading = saving,
                    enabled = signerName.isNotBlank() && strokes.isNotEmpty() && accepted,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { save() },
                )
                if (signature != null) {
                    VSpace(10)
                    BigButton(
                        text = "Keep existing signature",
                        tone = FfButtonTone.SECONDARY,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { replacing = false; strokes.clear() },
                    )
                }
            }
            VSpace(30)
        }
    }
}
