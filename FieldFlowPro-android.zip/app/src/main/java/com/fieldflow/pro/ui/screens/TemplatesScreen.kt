package com.fieldflow.pro.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.fieldflow.pro.core.AppContainer
import com.fieldflow.pro.core.Money
import com.fieldflow.pro.data.model.Trade
import com.fieldflow.pro.data.model.TradeTemplate
import com.fieldflow.pro.ui.components.ConfirmDialog
import com.fieldflow.pro.ui.components.FfScreen
import com.fieldflow.pro.ui.components.HSpace
import com.fieldflow.pro.ui.components.InfoBanner
import com.fieldflow.pro.ui.components.VSpace
import com.fieldflow.pro.ui.components.icon
import kotlinx.coroutines.launch

@Composable
fun TemplatesScreen(
    container: AppContainer,
    onBack: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val settings by container.settings.settings.collectAsState()
    val custom by container.templates.custom.collectAsState()
    var expanded by remember { mutableStateOf<String?>(null) }
    var pendingDelete by remember { mutableStateOf<TradeTemplate?>(null) }

    FfScreen(
        title = "Job templates",
        subtitle = "${container.templates.all().size} templates · applied when you start a job",
        onBack = onBack,
        snackbarHostState = snackbar,
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .navigationBarsPadding(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                InfoBanner(
                    "Templates fill in labour, materials, fees and a job checklist for you. Pick one while creating a job.",
                )
            }

            Trade.entries.forEach { trade ->
                val templates = container.templates.forTrade(trade)
                if (templates.isEmpty()) return@forEach
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            trade.icon(),
                            contentDescription = null,
                            modifier = Modifier.size(22.dp),
                            tint = MaterialTheme.colorScheme.primary,
                        )
                        Text(
                            trade.displayName,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(start = 8.dp),
                        )
                    }
                }
                items(templates.size) { index ->
                    val template = templates[index]
                    val isCustom = custom.any { it.id == template.id }
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.surface,
                        shape = MaterialTheme.shapes.large,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            template.name,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                        )
                                        if (isCustom) {
                                            HSpace(8)
                                            Icon(
                                                Icons.Filled.Star,
                                                contentDescription = "Custom template",
                                                modifier = Modifier.size(16.dp),
                                                tint = MaterialTheme.colorScheme.primary,
                                            )
                                        }
                                    }
                                    Text(
                                        template.summary,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                IconButton(onClick = { expanded = if (expanded == template.id) null else template.id }) {
                                    Icon(
                                        if (expanded == template.id) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                                        contentDescription = "Show template detail",
                                    )
                                }
                                if (isCustom) {
                                    IconButton(onClick = { pendingDelete = template }) {
                                        Icon(Icons.Filled.Delete, contentDescription = "Delete template")
                                    }
                                }
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { expanded = if (expanded == template.id) null else template.id },
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    "${template.lines.size} line(s)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                Text(
                                    " · ${template.checklist.size}-point checklist",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                Text(
                                    " · ${template.labourHours}h",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                HSpace(8)
                                Text(
                                    Money.format(
                                        template.lines.sumOf { line -> Math.round(line.quantity * line.unitPriceCents.toDouble()) },
                                        settings.currencyCode,
                                    ),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }
                            if (expanded == template.id) {
                                VSpace(10)
                                template.lines.forEach { line ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 3.dp),
                                    ) {
                                        Text(
                                            "${line.kind.displayName} · ${line.description}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            modifier = Modifier.weight(1f),
                                        )
                                        Text(
                                            Money.format(
                                                Math.round(line.quantity * line.unitPriceCents.toDouble()),
                                                settings.currencyCode,
                                            ),
                                            style = MaterialTheme.typography.bodyMedium,
                                        )
                                    }
                                }
                                VSpace(10)
                                Text("Checklist", style = MaterialTheme.typography.titleSmall)
                                template.checklist.forEach { item ->
                                    Text(
                                        "• $item",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                        }
                    }
                }
            }
            item { VSpace(24) }
        }
    }

    pendingDelete?.let { template ->
        ConfirmDialog(
            title = "Delete custom template?",
            message = "\"${template.name}\" will be removed from your library.",
            confirmLabel = "Delete",
            destructive = true,
            onConfirm = {
                pendingDelete = null
                scope.launch {
                    container.templates.deleteCustom(template.id)
                    snackbar.showSnackbar("Template deleted")
                }
            },
            onDismiss = { pendingDelete = null },
        )
    }
}
