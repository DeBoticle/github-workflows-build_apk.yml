package com.fieldflow.pro.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fieldflow.pro.data.model.ThemeMode

val FieldFlowOrange = Color(0xFFFF7A1A)
val FieldFlowOrangeDeep = Color(0xFFEA580C)
val FieldFlowTeal = Color(0xFF2DD4BF)
val FieldFlowNavy = Color(0xFF0B1220)
val FieldFlowNavySoft = Color(0xFF131C2E)
val FieldFlowAmber = Color(0xFFF59E0B)
val FieldFlowGreen = Color(0xFF22C55E)
val FieldFlowRed = Color(0xFFEF4444)
val FieldFlowBlue = Color(0xFF38BDF8)

private val DarkScheme = darkColorScheme(
    primary = FieldFlowOrange,
    onPrimary = Color(0xFF241000),
    primaryContainer = Color(0xFF6B2A05),
    onPrimaryContainer = Color(0xFFFFDCC6),
    secondary = FieldFlowTeal,
    onSecondary = Color(0xFF04231F),
    secondaryContainer = Color(0xFF0F3D37),
    onSecondaryContainer = Color(0xFFB8F3EA),
    tertiary = FieldFlowBlue,
    background = FieldFlowNavy,
    onBackground = Color(0xFFE8EDF5),
    surface = Color(0xFF111A29),
    onSurface = Color(0xFFE8EDF5),
    surfaceVariant = Color(0xFF1C2739),
    onSurfaceVariant = Color(0xFFB7C2D4),
    outline = Color(0xFF41506A),
    outlineVariant = Color(0xFF29344A),
    error = Color(0xFFFF8A80),
    onError = Color(0xFF3A0906),
    errorContainer = Color(0xFF5C1710),
    onErrorContainer = Color(0xFFFFDAD6),
    inverseSurface = Color(0xFFE8EDF5),
    inverseOnSurface = Color(0xFF18202E),
)

private val LightScheme = lightColorScheme(
    primary = FieldFlowOrangeDeep,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE0CC),
    onPrimaryContainer = Color(0xFF57200A),
    secondary = Color(0xFF0F766E),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFCBFBF1),
    onSecondaryContainer = Color(0xFF042F2E),
    tertiary = Color(0xFF0369A1),
    background = Color(0xFFF5F7FB),
    onBackground = Color(0xFF111827),
    surface = Color.White,
    onSurface = Color(0xFF111827),
    surfaceVariant = Color(0xFFEDF1F7),
    onSurfaceVariant = Color(0xFF44506A),
    outline = Color(0xFF9AA6BC),
    outlineVariant = Color(0xFFD7DEE9),
    error = Color(0xFFB3261E),
    onError = Color.White,
    errorContainer = Color(0xFFF9DEDC),
    onErrorContainer = Color(0xFF410E0B),
)

data class FfDimens(
    val touchTarget: Dp,
    val buttonHeight: Dp,
    val fieldHeight: Dp,
    val iconLarge: Dp,
    val iconMedium: Dp,
    val gutter: Dp,
    val cardPadding: Dp,
    val titleText: TextUnit,
    val bodyText: TextUnit,
    val labelText: TextUnit,
    val moneyText: TextUnit,
    val isGloveMode: Boolean,
)

private val StandardDimens = FfDimens(
    touchTarget = 60.dp,
    buttonHeight = 64.dp,
    fieldHeight = 62.dp,
    iconLarge = 28.dp,
    iconMedium = 22.dp,
    gutter = 16.dp,
    cardPadding = 16.dp,
    titleText = 24.sp,
    bodyText = 17.sp,
    labelText = 13.5.sp,
    moneyText = 26.sp,
    isGloveMode = false,
)

private val GloveDimens = FfDimens(
    touchTarget = 84.dp,
    buttonHeight = 88.dp,
    fieldHeight = 84.dp,
    iconLarge = 36.dp,
    iconMedium = 28.dp,
    gutter = 20.dp,
    cardPadding = 20.dp,
    titleText = 30.sp,
    bodyText = 22.sp,
    labelText = 17.sp,
    moneyText = 34.sp,
    isGloveMode = true,
)

val LocalFfDimens = staticCompositionLocalOf { StandardDimens }
val LocalFfGloveMode = staticCompositionLocalOf { false }

fun ffDimens(gloveMode: Boolean): FfDimens = if (gloveMode) GloveDimens else StandardDimens

private fun ffTypography(dimens: FfDimens): Typography {
    val base = Typography()
    return base.copy(
        displaySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = dimens.titleText * 1.5f, lineHeight = dimens.titleText * 1.7f),
        headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = dimens.titleText * 1.25f, lineHeight = dimens.titleText * 1.5f),
        headlineSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = dimens.titleText, lineHeight = dimens.titleText * 1.25f),
        titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = dimens.bodyText * 1.25f, lineHeight = dimens.bodyText * 1.5f),
        titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = dimens.bodyText * 1.1f, lineHeight = dimens.bodyText * 1.4f),
        titleSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = dimens.bodyText, lineHeight = dimens.bodyText * 1.35f),
        bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = dimens.bodyText, lineHeight = dimens.bodyText * 1.4f),
        bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = dimens.bodyText * 0.92f, lineHeight = dimens.bodyText * 1.3f),
        bodySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = dimens.labelText, lineHeight = dimens.labelText * 1.4f),
        labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = dimens.bodyText * 0.95f, lineHeight = dimens.bodyText * 1.3f),
        labelMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = dimens.labelText, lineHeight = dimens.labelText * 1.3f),
        labelSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = dimens.labelText * 0.92f, lineHeight = dimens.labelText * 1.2f),
    )
}

private val FfShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(26.dp),
)

@Composable
fun FieldFlowTheme(
    themeMode: ThemeMode,
    gloveMode: Boolean,
    content: @Composable () -> Unit,
) {
    val systemDark = isSystemInDarkTheme()
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> systemDark
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val dimens = remember(gloveMode) { ffDimens(gloveMode) }
    val typography = remember(dimens) { ffTypography(dimens) }
    CompositionLocalProvider(
        LocalFfDimens provides dimens,
        LocalFfGloveMode provides gloveMode,
    ) {
        MaterialTheme(
            colorScheme = if (dark) DarkScheme else LightScheme,
            typography = typography,
            shapes = FfShapes,
            content = content,
        )
    }
}
