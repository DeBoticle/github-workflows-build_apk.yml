package com.fieldflow.pro

import com.fieldflow.pro.data.model.ChecklistItem
import com.fieldflow.pro.data.model.Job
import com.fieldflow.pro.data.model.JobStatus
import com.fieldflow.pro.data.model.MaterialLine
import com.fieldflow.pro.data.model.Quote
import com.fieldflow.pro.data.model.QuoteLine
import com.fieldflow.pro.data.model.QuoteLineKind
import com.fieldflow.pro.data.model.QuoteStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.roundToLong

class JobTotalsTest {

    private fun jobWith(
        materials: List<MaterialLine>,
        hours: Double,
        rate: Long,
        taxPercent: Double,
        discount: Long,
    ) = Job(
        title = "Test job",
        trade = com.fieldflow.pro.data.model.Trade.HVAC,
        status = JobStatus.SCHEDULED,
        materials = materials,
        labourHours = hours,
        labourRateCents = rate,
        taxRatePercent = taxPercent,
        discountCents = discount,
    )

    @Test
    fun `material line total multiplies quantity by unit price`() {
        val line = MaterialLine(description = "Capacitor", quantity = 3.0, unitPriceCents = 1_895)
        assertEquals(5_685L, line.lineTotalCents)
    }

    @Test
    fun `fractional quantities round to the nearest cent`() {
        val line = MaterialLine(description = "Refrigerant", quantity = 2.5, unitPriceCents = 4_200)
        assertEquals(10_500L, line.lineTotalCents)

        val thirds = MaterialLine(description = "Tape", quantity = 1.0 / 3.0, unitPriceCents = 1_000)
        assertEquals((1_000.0 / 3.0).roundToLong(), thirds.lineTotalCents)
    }

    @Test
    fun `job totals combine materials labour discount and tax`() {
        val job = jobWith(
            materials = listOf(
                MaterialLine(quantity = 1.0, unitPriceCents = 10_000),
                MaterialLine(quantity = 2.0, unitPriceCents = 5_000),
            ),
            hours = 3.0,
            rate = 9_500,
            taxPercent = 8.25,
            discount = 5_000,
        )

        assertEquals(20_000L, job.materialsTotalCents)
        assertEquals(28_500L, job.labourTotalCents)
        assertEquals(48_500L, job.subtotalCents)
        assertEquals(43_500L, job.taxableBaseCents)
        assertEquals((43_500.0 * 0.0825).roundToLong(), job.taxCents)
        assertEquals(job.taxableBaseCents + job.taxCents, job.totalCents)
    }

    @Test
    fun `discount larger than the subtotal never produces negative tax`() {
        val job = jobWith(
            materials = listOf(MaterialLine(quantity = 1.0, unitPriceCents = 1_000)),
            hours = 0.0,
            rate = 0L,
            taxPercent = 20.0,
            discount = 5_000,
        )

        assertEquals(0L, job.taxableBaseCents)
        assertEquals(0L, job.taxCents)
        assertEquals(0L, job.totalCents)
    }

    @Test
    fun `checklist progress tracks completed items`() {
        val empty = Job()
        assertEquals(0f, empty.checklistProgress, 0.0001f)

        val half = Job(
            checklist = listOf(
                ChecklistItem(label = "A", done = true),
                ChecklistItem(label = "B", done = false),
            ),
        )
        assertEquals(0.5f, half.checklistProgress, 0.0001f)
    }

    @Test
    fun `open state excludes closed and cancelled work`() {
        assertTrue(Job(status = JobStatus.SCHEDULED).isOpen)
        assertTrue(Job(status = JobStatus.IN_PROGRESS).isOpen)
        assertFalse(Job(status = JobStatus.COMPLETE).isOpen)
        assertFalse(Job(status = JobStatus.INVOICED).isOpen)
        assertFalse(Job(status = JobStatus.CANCELLED).isOpen)
    }

    @Test
    fun `quote totals treat discounts as negative and skip taxing them`() {
        val quote = Quote(
            status = QuoteStatus.DRAFT,
            taxRatePercent = 10.0,
            lines = listOf(
                QuoteLine(kind = QuoteLineKind.LABOUR, quantity = 2.0, unitPriceCents = 10_000, taxable = true),
                QuoteLine(kind = QuoteLineKind.MATERIAL, quantity = 1.0, unitPriceCents = 5_000, taxable = true),
                QuoteLine(kind = QuoteLineKind.FEE, quantity = 1.0, unitPriceCents = 1_000, taxable = false),
                QuoteLine(kind = QuoteLineKind.DISCOUNT, quantity = 1.0, unitPriceCents = 2_000, taxable = false),
            ),
        )

        assertEquals(-2_000L, quote.lines.last().lineTotalCents)
        assertEquals(24_000L, quote.subtotalCents)
        assertEquals(2_000L, quote.discountCents)
        assertEquals(2_500L, quote.taxCents)
        assertEquals(26_500L, quote.totalCents)
        assertEquals(20_000L, quote.groupTotal(QuoteLineKind.LABOUR))
        assertEquals(-2_000L, quote.groupTotal(QuoteLineKind.DISCOUNT))
    }
}
