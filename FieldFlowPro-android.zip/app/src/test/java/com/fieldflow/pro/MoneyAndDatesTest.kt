package com.fieldflow.pro

import com.fieldflow.pro.core.Bytes
import com.fieldflow.pro.core.Dates
import com.fieldflow.pro.core.Ids
import com.fieldflow.pro.core.Money
import com.fieldflow.pro.core.initials
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MoneyAndDatesTest {

    @Test
    fun `parseToCents handles plain and formatted amounts`() {
        assertEquals(1_234L, Money.parseToCents("12.34")!!)
        assertEquals(1_234L, Money.parseToCents("$12.34")!!)
        assertEquals(120_000L, Money.parseToCents("1,200")!!)
        assertEquals(0L, Money.parseToCents("0")!!)
        assertNull(Money.parseToCents(""))
        assertNull(Money.parseToCents("abc"))
    }

    @Test
    fun `formatPlain renders two decimals and keeps the sign`() {
        assertEquals("12.34", Money.formatPlain(1_234))
        assertEquals("0.05", Money.formatPlain(5))
        assertEquals("0.00", Money.formatPlain(0))
        assertEquals("-12.34", Money.formatPlain(-1_234))
    }

    @Test
    fun `parseToCents and formatPlain round trip`() {
        listOf(0L, 5L, 999L, 12_345L, 1_000_000L).forEach { cents ->
            assertEquals(cents, Money.parseToCents(Money.formatPlain(cents))!!)
        }
    }

    @Test
    fun `parseQty accepts decimals and rejects junk`() {
        assertEquals(2.5, Money.parseQty("2.5")!!, 0.0001)
        assertEquals(1_000.0, Money.parseQty("1,000")!!, 0.0001)
        assertNull(Money.parseQty("two"))
    }

    @Test
    fun `relative time reads naturally`() {
        val now = 1_700_000_000_000L
        assertEquals("never", Dates.relative(0L, now))
        assertEquals("just now", Dates.relative(now - 30_000, now))
        assertEquals("5 min ago", Dates.relative(now - 5 * 60_000, now))
        assertEquals("3 h ago", Dates.relative(now - 3 * 3_600_000, now))
        assertEquals("2 d ago", Dates.relative(now - 2 * 86_400_000L, now))
    }

    @Test
    fun `end of day is one millisecond before the next day`() {
        val start = Dates.todayStart(1_700_000_000_000L)
        assertEquals(start + 86_400_000L - 1, Dates.endOfDay(start))
    }

    @Test
    fun `byte sizes are human readable`() {
        assertEquals("512 B", Bytes.human(512))
        assertEquals("1.0 KB", Bytes.human(1024))
        assertEquals("1.0 MB", Bytes.human(1024L * 1024))
    }

    @Test
    fun `job numbers are zero padded and unique`() {
        assertEquals("JOB-2024-0042", Ids.jobNumber(42, 2024))
        assertEquals("QTE-2024-0007", Ids.quoteNumber(7, 2024))
        val generated = List(200) { Ids.new("job") }
        assertEquals(generated.size, generated.toSet().size)
        assertTrue(generated.first().startsWith("job-"))
    }

    @Test
    fun `initials fall back safely`() {
        assertEquals("DW", "Dana Whitfield".initials())
        assertEquals("?", "".initials())
    }
}
