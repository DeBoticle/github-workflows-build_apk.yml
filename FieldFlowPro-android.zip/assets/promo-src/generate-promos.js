async ({ fs, tools, only = null, promoDir = "assets/promo", srcDir = "assets/promo-src", previewDir = "assets/promo/preview", playDir = "assets/play" }) => {
  const W = 1920, H = 1080;
  const SANS = "'Inter','SF Pro Text',system-ui,-apple-system,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif";
  const MONO = "ui-monospace,'SFMono-Regular',Menlo,Consolas,'Liberation Mono',monospace";
  const FONT = (size, weight = 400, mono = false) => `${weight} ${size}px ${mono ? MONO : SANS}`;
  const CO = {
    white: "#FFFFFF", text: "#EAF1F8", slate: "#8FA0B4", slate2: "#C6D2E0",
    orange: "#FF7A00", orangeLite: "#FFA23A", teal: "#22C1B4", tealDeep: "#0E8C84",
    amber: "#F5B13D", red: "#FF4D4F", green: "#46E0A0", ink: "#0B0F16",
    screen: "#0B0F16", screenAlt: "#101827", card: "#141C28", cardSoft: "#1A2431",
    line: "rgba(255,255,255,0.10)", lineSoft: "rgba(255,255,255,0.06)",
    field: "rgba(255,255,255,0.05)"
  };
  let P = null;
  let RND = 7;
  const rnd = () => { RND = (RND * 1664525 + 1013904223) % 4294967296; return RND / 4294967296; };
  const seedRnd = (s) => { RND = s % 4294967296; };

  const rrect = (x, y, w, h, r) => {
    r = Math.min(r, w / 2, h / 2);
    P.beginPath();
    P.moveTo(x + r, y);
    P.lineTo(x + w - r, y);
    P.arcTo(x + w, y, x + w, y + r, r);
    P.lineTo(x + w, y + h - r);
    P.arcTo(x + w, y + h, x + w - r, y + h, r);
    P.lineTo(x + r, y + h);
    P.arcTo(x, y + h, x, y + h - r, r);
    P.lineTo(x, y + r);
    P.arcTo(x, y, x + r, y, r);
    P.closePath();
  };
  const fillRR = (x, y, w, h, r, fill) => { P.fillStyle = fill; rrect(x, y, w, h, r); P.fill(); };
  const strokeRR = (x, y, w, h, r, stroke, lw = 1.5) => { P.strokeStyle = stroke; P.lineWidth = lw; rrect(x, y, w, h, r); P.stroke(); };
  const seg = (x1, y1, x2, y2, color, lw = 1, dash = null) => {
    P.save(); P.strokeStyle = color; P.lineWidth = lw; if (dash) P.setLineDash(dash);
    P.beginPath(); P.moveTo(x1, y1); P.lineTo(x2, y2); P.stroke(); P.restore();
  };
  const disc = (x, y, r, fill) => { P.fillStyle = fill; P.beginPath(); P.arc(x, y, r, 0, Math.PI * 2); P.fill(); };
  const tw = (s) => P.measureText(s).width;
  const twSp = (s, sp) => { let w = 0; for (const ch of s) w += tw(ch) + sp; return Math.max(0, w - sp); };
  const drawSp = (s, x, y, sp) => { let cx = x; for (const ch of s) { P.fillText(ch, cx, y); cx += tw(ch) + sp; } };
  const txt = (s, x, y, o = {}) => {
    let size = o.size || 24;
    const weight = o.weight || 400, mono = !!o.mono, sp = o.spacing || 0;
    const maxW = o.maxW || 0;
    P.font = FONT(size, weight, mono);
    if (maxW > 0) {
      let guard = 0;
      while (size > 8 && guard++ < 200) {
        P.font = FONT(size, weight, mono);
        const w = sp ? twSp(s, sp) : tw(s);
        if (w <= maxW) break;
        size -= 1;
      }
    }
    const w = sp ? twSp(s, sp) : tw(s);
    let px = x;
    if (o.align === "center") px = x - w / 2;
    else if (o.align === "right") px = x - w;
    P.fillStyle = o.color || CO.white;
    P.textAlign = "left";
    P.textBaseline = "alphabetic";
    if (sp) drawSp(s, px, y, sp); else P.fillText(s, px, y);
    return { x: px, w, size };
  };
  const txtMid = (s, x, cy, o = {}) => {
    const size = o.size || 24;
    return txt(s, x, cy + size * 0.35, o);
  };
  const ellipse = (s, x, y, maxW, o = {}) => {
    if (!maxW) return s;
    let size = o.size || 24;
    P.font = FONT(size, o.weight || 400, !!o.mono);
    if (tw(s) <= maxW) return s;
    while (size > 8) {
      size -= 1;
      P.font = FONT(size, o.weight || 400, !!o.mono);
      if (tw(s) <= maxW) return s;
    }
    let cut = s;
    while (cut.length > 2 && tw(cut + "\u2026") > maxW) cut = cut.slice(0, -1);
    return cut + "\u2026";
  };

  const iconChevron = (x, y, size, color, dir = "left") => {
    P.strokeStyle = color; P.lineWidth = Math.max(2, size * 0.24); P.lineCap = "round"; P.lineJoin = "round";
    P.beginPath();
    const d = dir === "left" ? 1 : -1;
    P.moveTo(x + d * size * 0.35, y - size * 0.5);
    P.lineTo(x - d * size * 0.3, y);
    P.lineTo(x + d * size * 0.35, y + size * 0.5);
    P.stroke();
  };
  const iconDots3 = (x, y, color) => { for (let i = -1; i <= 1; i++) disc(x, y + i * 8, 2.6, color); };
  const iconBolt = (x, y, s, color) => {
    P.fillStyle = color;
    P.beginPath();
    P.moveTo(x + s * 0.56, y);
    P.lineTo(x + s * 0.16, y + s * 0.56);
    P.lineTo(x + s * 0.44, y + s * 0.56);
    P.lineTo(x + s * 0.34, y + s);
    P.lineTo(x + s * 0.86, y + s * 0.4);
    P.lineTo(x + s * 0.55, y + s * 0.4);
    P.lineTo(x + s * 0.72, y);
    P.closePath();
    P.fill();
  };
  const iconCheck = (x, y, s, color, lw = 3) => {
    P.strokeStyle = color; P.lineWidth = lw; P.lineCap = "round"; P.lineJoin = "round";
    P.beginPath(); P.moveTo(x, y + s * 0.5); P.lineTo(x + s * 0.34, y + s * 0.82); P.lineTo(x + s, y); P.stroke();
  };
  const iconBars = (x, y, color) => {
    for (let i = 0; i < 4; i++) fillRR(x + i * 6, y + 12 - i * 4, 4, 4 + i * 4, 1.4, color);
  };
  const iconWifi = (x, y, color) => {
    P.strokeStyle = color; P.lineWidth = 2.4; P.lineCap = "round";
    for (let i = 0; i < 3; i++) {
      P.beginPath();
      P.arc(x, y + 10, 5 + i * 7, Math.PI * 1.18, Math.PI * 1.82);
      P.stroke();
    }
    disc(x, y + 11, 2.2, color);
  };
  const iconBattery = (x, y, color) => {
    strokeRR(x, y, 26, 14, 4, color, 1.8);
    fillRR(x + 27, y + 4, 3, 6, 1.5, color);
    fillRR(x + 3, y + 3, 15, 8, 2.4, color);
  };
  const iconCloudOff = (x, y, s, color) => {
    P.strokeStyle = color; P.lineWidth = Math.max(2, s * 0.1); P.lineCap = "round"; P.fillStyle = color;
    P.beginPath();
    P.moveTo(x, y + s * 0.72);
    P.bezierCurveTo(x - s * 0.05, y + s * 0.34, x + s * 0.3, y + s * 0.16, x + s * 0.45, y + s * 0.4);
    P.bezierCurveTo(x + s * 0.62, y + s * 0.06, x + s * 1.02, y + s * 0.2, x + s * 0.96, y + s * 0.6);
    P.stroke();
    P.beginPath(); P.moveTo(x - s * 0.06, y + s * 0.14); P.lineTo(x + s * 1.04, y + s * 0.94); P.stroke();
  };
  const iconHome = (x, y, s, color) => {
    P.strokeStyle = color; P.lineWidth = 2.4; P.lineJoin = "round"; P.lineCap = "round";
    P.beginPath();
    P.moveTo(x, y + s * 0.48); P.lineTo(x + s * 0.5, y); P.lineTo(x + s, y + s * 0.48);
    P.lineTo(x + s * 0.84, y + s * 0.48); P.lineTo(x + s * 0.84, y + s); P.lineTo(x + s * 0.16, y + s);
    P.lineTo(x + s * 0.16, y + s * 0.48);
    P.stroke();
  };
  const iconClipboard = (x, y, s, color) => {
    strokeRR(x, y + s * 0.1, s, s * 0.9, 3, color, 2.3);
    fillRR(x + s * 0.3, y, s * 0.4, s * 0.24, 3, color);
    seg(x + s * 0.24, y + s * 0.5, x + s * 0.76, y + s * 0.5, color, 2.2);
    seg(x + s * 0.24, y + s * 0.72, x + s * 0.6, y + s * 0.72, color, 2.2);
  };
  const iconPerson = (x, y, s, color) => {
    P.strokeStyle = color; P.lineWidth = 2.3; P.lineCap = "round";
    P.beginPath(); P.arc(x + s * 0.5, y + s * 0.28, s * 0.26, 0, Math.PI * 2); P.stroke();
    P.beginPath(); P.moveTo(x + s * 0.08, y + s); P.bezierCurveTo(x + s * 0.1, y + s * 0.58, x + s * 0.9, y + s * 0.58, x + s * 0.92, y + s); P.stroke();
  };
  const iconSliders = (x, y, s, color) => {
    P.strokeStyle = color; P.lineWidth = 2.3; P.lineCap = "round";
    const ys = [0.22, 0.5, 0.78], ks = [0.7, 0.34, 0.58];
    ys.forEach((yy, i) => {
      seg(x, y + s * yy, x + s, y + s * yy, color, 2.3);
      disc(x + s * ks[i], y + s * yy, 3.6, CO.screen);
      P.strokeStyle = color; P.lineWidth = 2.3;
      P.beginPath(); P.arc(x + s * ks[i], y + s * yy, 3.6, 0, Math.PI * 2); P.stroke();
    });
  };
  const iconCamera = (x, y, s, color) => {
    strokeRR(x, y + s * 0.18, s, s * 0.72, s * 0.16, color, 2.3);
    fillRR(x + s * 0.3, y + s * 0.04, s * 0.34, s * 0.2, 2, color);
    P.strokeStyle = color; P.lineWidth = 2.3;
    P.beginPath(); P.arc(x + s * 0.5, y + s * 0.55, s * 0.2, 0, Math.PI * 2); P.stroke();
  };

  const background = () => {
    let g = P.createLinearGradient(0, 0, W * 0.6, H);
    g.addColorStop(0, "#0A1119"); g.addColorStop(0.55, "#0C1622"); g.addColorStop(1, "#070A11");
    P.fillStyle = g; P.fillRect(0, 0, W, H);
    let rg = P.createRadialGradient(160, 1010, 0, 160, 1010, 820);
    rg.addColorStop(0, "rgba(34,193,180,0.20)"); rg.addColorStop(1, "rgba(34,193,180,0)");
    P.fillStyle = rg; P.fillRect(0, 0, W, H);
    rg = P.createRadialGradient(1400, 520, 40, 1400, 520, 720);
    rg.addColorStop(0, "rgba(255,122,0,0.24)"); rg.addColorStop(0.5, "rgba(255,122,0,0.08)"); rg.addColorStop(1, "rgba(255,122,0,0)");
    P.fillStyle = rg; P.fillRect(0, 0, W, H);
    P.save();
    P.strokeStyle = "rgba(255,255,255,0.035)"; P.lineWidth = 1;
    P.beginPath();
    for (let x = 24; x <= W; x += 48) { P.moveTo(x + 0.5, 0); P.lineTo(x + 0.5, H); }
    for (let y = 24; y <= H; y += 48) { P.moveTo(0, y + 0.5); P.lineTo(W, y + 0.5); }
    P.stroke();
    P.restore();
    rg = P.createRadialGradient(W / 2, H / 2, 320, W / 2, H / 2, 1180);
    rg.addColorStop(0, "rgba(0,0,0,0)"); rg.addColorStop(1, "rgba(0,0,0,0.62)");
    P.fillStyle = rg; P.fillRect(0, 0, W, H);
  };

  const logoLockup = (x, y) => {
    const s = 60;
    P.save();
    P.shadowColor = "rgba(255,122,0,0.45)"; P.shadowBlur = 26;
    const g = P.createLinearGradient(x, y, x + s, y + s);
    g.addColorStop(0, "#15303A"); g.addColorStop(1, "#0C1A22");
    fillRR(x, y, s, s, 17, g);
    P.restore();
    strokeRR(x + 0.75, y + 0.75, s - 1.5, s - 1.5, 16.5, "rgba(34,193,180,0.55)", 1.6);
    iconBolt(x + 6, y + 8, s - 12, CO.orange);
    const t = txt("FieldFlow", x + s + 20, y + s * 0.62, { size: 40, weight: 800, color: CO.white });
    txt(" Pro", x + s + 20 + t.w + 4, y + s * 0.62, { size: 40, weight: 800, color: CO.teal });
    const px = x + s + 20 + t.w + tw(" Pro") + 26;
    const label = "NO SIGNAL NEEDED";
    P.font = FONT(19, 700);
    const w = twSp(label, 2.4) + 34;
    fillRR(px, y + 14, w, 34, 17, "rgba(34,193,180,0.10)");
    strokeRR(px + 0.7, y + 14.7, w - 1.4, 32.6, 16.5, "rgba(34,193,180,0.55)", 1.4);
    txt(label, px + 17, y + 37, { size: 19, weight: 700, color: CO.teal, spacing: 2.4 });
    return y + s + 46;
  };

  const leftColumn = (kicker, lines, bullets, tagline) => {
    let y = logoLockup(120, 84);
    y += 44;
    txt(kicker, 122, y + 18, { size: 25, weight: 800, color: CO.teal, spacing: 5.5 });
    y += 78;
    for (const ln of lines) {
      txt(ln, 118, y + 62, { size: 78, weight: 800, color: CO.white, maxW: 1000 });
      y += 94;
    }
    y += 44;
    for (const b of bullets) {
      disc(130, y - 10, 8.5, CO.orange);
      txt(b, 164, y, { size: 31, weight: 500, color: CO.slate2, maxW: 950 });
      y += 60;
    }
    if (tagline) txt(tagline, 122, 1006, { size: 22, weight: 500, color: "rgba(143,160,180,0.92)" });
  };

  const phone = () => {
    const x = 1216, y = 76, w = 404, h = 932;
    P.save();
    P.fillStyle = "rgba(0,0,0,0.55)"; P.filter = "blur(2px)";
    P.beginPath(); P.ellipse(x + w / 2, y + h + 26, w * 0.5, 22, 0, 0, Math.PI * 2); P.fill();
    P.restore();
    P.save();
    P.shadowColor = "rgba(0,0,0,0.7)"; P.shadowBlur = 70; P.shadowOffsetY = 22;
    fillRR(x, y, w, h, 54, "#0D1219");
    P.restore();
    const g = P.createLinearGradient(x, y, x + w, y + h);
    g.addColorStop(0, "rgba(255,255,255,0.24)"); g.addColorStop(0.45, "rgba(255,255,255,0.05)"); g.addColorStop(1, "rgba(255,255,255,0.18)");
    strokeRR(x + 1.5, y + 1.5, w - 3, h - 3, 53, g, 3);
    const s = { x: x + 14, y: y + 14, w: w - 28, h: h - 28 };
    fillRR(s.x, s.y, s.w, s.h, 42, CO.screen);
    P.save(); rrect(s.x, s.y, s.w, s.h, 42); P.clip();
    const bg = P.createLinearGradient(0, s.y, 0, s.y + s.h);
    bg.addColorStop(0, "#0C1220"); bg.addColorStop(1, "#0A0E16");
    P.fillStyle = bg; P.fillRect(s.x, s.y, s.w, s.h);
    P.restore();
    return s;
  };

  const statusBar = (s) => {
    const y = s.y + 32;
    txt("7:42", s.x + 30, y + 6, { size: 19, weight: 700, color: "#E6ECF4" });
    let rx = s.x + s.w - 30;
    iconBattery(rx - 24, y - 8, "#E6ECF4");
    iconWifi(rx - 74, y - 15, "#E6ECF4");
    iconBars(rx - 128, y - 10, "#E6ECF4");
  };

  const appBar = (s, title, sub) => {
    const y0 = s.y + 50;
    iconChevron(s.x + 32, y0 + 22, 15, "rgba(255,255,255,0.8)");
    txt(title, s.x + 62, y0 + 30, { size: 30, weight: 800, color: CO.white, maxW: s.w - 130 });
    if (sub) txt(sub, s.x + 62, y0 + 56, { size: 15, weight: 600, color: CO.slate });
    iconDots3(s.x + s.w - 32, y0 + 22, "rgba(255,255,255,0.55)");
    seg(s.x, y0 + 78, s.x + s.w, y0 + 78, CO.lineSoft, 1);
    return y0 + 78;
  };

  const bottomNav = (s, active) => {
    const h = 84, y = s.y + s.h - h;
    P.fillStyle = "rgba(255,255,255,0.035)"; P.fillRect(s.x, y, s.w, h);
    seg(s.x, y, s.x + s.w, y, CO.line, 1);
    const items = [["Home", iconHome], ["Jobs", iconClipboard], ["Clients", iconPerson], ["Settings", iconSliders]];
    const colW = s.w / 4;
    items.forEach(([label, ico], i) => {
      const cxi = s.x + colW * (i + 0.5);
      const on = i === active;
      const col = on ? CO.teal : "rgba(255,255,255,0.4)";
      ico(cxi - 11, y + 18, 22, col);
      txt(label, cxi, y + 66, { size: 13, weight: 700, color: col, align: "center" });
    });
    return y;
  };

  const stickyBar = (s, buttons) => {
    const h = 96, y = s.y + s.h - h;
    const g = P.createLinearGradient(0, y - 22, 0, y + h);
    g.addColorStop(0, "rgba(11,15,22,0)"); g.addColorStop(0.42, "rgba(11,15,22,0.96)");
    P.fillStyle = g; P.fillRect(s.x, y - 22, s.w, h + 22);
    seg(s.x, y, s.x + s.w, y, CO.lineSoft, 1);
    const pad = 22, gap = 12;
    const n = buttons.length;
    const totalW = s.w - pad * 2 - gap * (n - 1);
    const bw = totalW / n;
    buttons.forEach((b, i) => {
      const bx = s.x + pad + i * (bw + gap);
      const by = y + 18, bh = 62;
      if (b.kind === "primary") {
        const g2 = P.createLinearGradient(bx, by, bx, by + bh);
        g2.addColorStop(0, CO.orangeLite); g2.addColorStop(1, CO.orange);
        P.save(); P.shadowColor = "rgba(255,122,0,0.5)"; P.shadowBlur = 20;
        fillRR(bx, by, bw, bh, 16, g2); P.restore();
        txt(b.label, bx + bw / 2, by + bh * 0.5 + 9, { size: 20, weight: 800, color: "#1A1206", align: "center", maxW: bw - 24 });
      } else {
        fillRR(bx, by, bw, bh, 16, CO.field);
        strokeRR(bx + 0.7, by + 0.7, bw - 1.4, bh - 1.4, 15.5, CO.line, 1.4);
        txt(b.label, bx + bw / 2, by + bh * 0.5 + 9, { size: 20, weight: 700, color: CO.slate2, align: "center", maxW: bw - 24 });
      }
    });
    return y;
  };

  const prefix = (n, p, s) => {
    if (n >= 1000000) return p + (n / 1000000).toFixed(1) + "M";
    if (n >= 1000) return p + (n / 1000).toFixed(1) + s;
    return p + n + s;
  };
  const fieldBlock = (s, y, label, value, opts = {}) => {
    txt(label, s.x + 22, y + 14, { size: 13, weight: 800, color: CO.slate, spacing: 2.2 });
    const bx = s.x + 22, bw = s.w - 44, bh = 58;
    fillRR(bx, y + 24, bw, bh, 13, CO.field);
    strokeRR(bx + 0.7, y + 24.7, bw - 1.4, bh - 1.4, 12.5, opts.active ? "rgba(255,122,0,0.6)" : CO.lineSoft, 1.4);
    txt(value, bx + 16, y + 24 + 36, { size: 20, weight: 600, color: CO.text, maxW: bw - 32 });
    if (opts.trailing) txt(opts.trailing, bx + bw - 16, y + 24 + 36, { size: 15, weight: 600, color: CO.slate, align: "right" });
    return y + 24 + bh + 20;
  };

  const chip = (x, cy, label, state = "idle", h = 42) => {
    P.font = FONT(17, 700);
    const w = tw(label) + 34;
    if (state === "on") {
      fillRR(x, cy - h / 2, w, h, h / 2, CO.orange);
      txt(label, x + w / 2, cy + 6, { size: 17, weight: 800, color: "#1A1206", align: "center" });
    } else {
      fillRR(x, cy - h / 2, w, h, h / 2, CO.field);
      strokeRR(x + 0.7, cy - h / 2 + 0.7, w - 1.4, h - 1.4, h / 2, CO.line, 1.3);
      txt(label, x + w / 2, cy + 6, { size: 17, weight: 700, color: CO.slate2, align: "center" });
    }
    return x + w + 10;
  };

  const badge = (xRight, cy, label, color, bg) => {
    P.font = FONT(15, 800);
    const w = tw(label) + 30, h = 32;
    fillRR(xRight - w, cy - h / 2, w, h, 9, bg);
    txt(label, xRight - w / 2, cy + 5.5, { size: 15, weight: 800, color, align: "center" });
    return xRight - w - 10;
  };

  const moneyRow = (s, y, name, detail, amount, o = {}) => {
    txt(name, s.x + 22, y + 8, { size: 19, weight: 600, color: CO.text, maxW: s.w - 200 });
    if (detail) txt(detail, s.x + 22, y + 30, { size: 15, weight: 500, color: CO.slate });
    txt(amount, s.x + s.w - 22, y + 12, { size: 19, weight: 700, color: o.amountColor || CO.white, align: "right" });
    return y + (detail ? 58 : 46);
  };

  const progress = (x, y, w, h, pct, color) => {
    fillRR(x, y, w, h, h / 2, "rgba(255,255,255,0.08)");
    fillRR(x, y, w * pct, h, h / 2, color);
  };

  const toggle = (xRight, cy, on) => {
    const w = 62, h = 34, x = xRight - w;
    fillRR(x, cy - h / 2, w, h, h / 2, on ? "rgba(34,193,180,0.9)" : "rgba(255,255,255,0.12)");
    disc(on ? x + w - 17 : x + 17, cy, 13, "#FFFFFF");
  };

  const card = (s, y, h, fill = CO.card, r = 18) => {
    fillRR(s.x + 20, y, s.w - 40, h, r, fill);
    strokeRR(s.x + 20.7, y + 0.7, s.w - 41.4, h - 1.4, r - 0.7, CO.lineSoft, 1.4);
    return { x: s.x + 20, y, w: s.w - 40, h };
  };

  const LETTERS = {
    n: [[0, 0], [0.5, -1], [1, 0]],
    m: [[0, 0], [0.22, -1], [0.45, -0.12], [0.7, -1], [1, 0]],
    u: [[0, -1], [0.5, 0.14], [1, -1]],
    e: [[0.06, 0.06], [0.46, -0.5], [0.95, -0.34], [0.84, 0.14], [0.28, 0.12], [0.22, -0.52], [0.8, -0.78], [1, -0.42]],
    l: [[0.02, 0.02], [0.12, -1.85], [0.54, -1.78], [0.44, -0.95], [0.4, -0.3], [0.68, 0.06], [1, -0.62]],
    i: [[0.08, 0.02], [0.34, -1], [0.6, 0.04], [1, -0.5]],
    t: [[0.12, -1.55], [0.34, 0.12], [0.5, -0.62], [1, -0.82]],
    h: [[0.02, 0], [0.14, -1.85], [0.52, -1.76], [0.42, -0.9], [0.46, -0.2], [0.7, 0.06], [1, -0.7]],
    d: [[0.94, -1.85], [0.42, -1.86], [0.2, -0.6], [0.14, 0.06], [0.5, 0.16], [0.86, -0.42], [1, -0.8]],
    f: [[0.04, 0.38], [0.34, -1.68], [0.74, -1.86], [0.58, -1.2], [0.5, 0.14], [0.76, -0.42], [1, -0.72]],
    a: [[0.05, 0.02], [0.48, -0.9], [0.9, -0.56], [0.8, 0.02], [0.44, 0.14], [0.34, -0.54], [0.76, -0.82], [1, -0.36]],
    W: [[0, -1.9], [0.26, -0.12], [0.5, -1.42], [0.74, -0.12], [1.1, -1.86]],
    D: [[0.08, -0.02], [0.0, -1.82], [0.36, -1.88], [0.82, -1.5], [0.96, -0.92], [0.8, -0.26], [0.3, 0.04], [0.06, 0.0]]
  };

  const catmull = (knots, samples = 16) => {
    const n = knots.length, out = [];
    const g = (i) => knots[Math.max(0, Math.min(n - 1, i))];
    for (let i = 0; i < n - 1; i++) {
      const p0 = g(i - 1), p1 = g(i), p2 = g(i + 1), p3 = g(i + 2);
      for (let j = 0; j < samples; j++) {
        const t = j / samples, t2 = t * t, t3 = t2 * t;
        out.push([
          0.5 * (2 * p1[0] + (-p0[0] + p2[0]) * t + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3),
          0.5 * (2 * p1[1] + (-p0[1] + p2[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3)
        ]);
      }
    }
    out.push([knots[n - 1][0], knots[n - 1][1]]);
    return out;
  };

  const ink = (pts, o = {}) => {
    const base = o.base || 2.4, color = o.color || "#12192B", seed = o.seed || 1;
    P.fillStyle = color;
    for (let i = 0; i < pts.length - 1; i++) {
      const a = pts[i], b = pts[i + 1];
      const dx = b[0] - a[0], dy = b[1] - a[1];
      const len = Math.hypot(dx, dy);
      const steps = Math.max(1, Math.ceil(len / 1.1));
      for (let k = 0; k <= steps; k++) {
        const t = k / steps;
        const x = a[0] + dx * t, y = a[1] + dy * t;
        const down = len > 0.01 ? Math.max(0, dy / len) : 0;
        const press = 0.42 + 0.58 * down + 0.16 * Math.sin(x * 0.37 + seed) + 0.08 * Math.sin(x * 0.11 + y * 0.05);
        P.beginPath();
        P.arc(x, y, base * (0.68 + press * 0.5), 0, Math.PI * 2);
        P.fill();
      }
    }
  };

  const signature = (x0, yBase, xh, seed) => {
    seedRnd(seed);
    const adv = xh * 0.8;
    const words = ["Dana", "Whitfield"];
    const pts = [];
    const dots = [];
    let penX = x0;
    words.forEach((word, wi) => {
      if (wi > 0) penX += adv * 0.6;
      for (const ch of word) {
        const isCap = ch === ch.toUpperCase();
        const shape = LETTERS[ch] || LETTERS[ch.toLowerCase()];
        if (!shape) { penX += adv; continue; }
        const wl = adv * (0.86 + rnd() * 0.3) * (isCap ? 1.16 : 1);
        const hl = xh * (0.9 + rnd() * 0.24) * (isCap ? 1.4 : 1);
        const dy = (rnd() - 0.5) * xh * 0.12 + Math.sin(penX * 0.035) * xh * 0.07;
        const knots = shape.map(k => [penX + k[0] * wl, yBase + dy + k[1] * hl]);
        for (const p of catmull(knots, 15)) pts.push(p);
        if (ch.toLowerCase() === "i") dots.push([penX + wl * 0.3, yBase + dy - hl * 1.16]);
        penX += wl;
      }
    });
    const endX = penX;
    ink(pts, { base: xh * 0.088, seed: seed });
    P.fillStyle = "#12192B";
    for (const d of dots) { P.beginPath(); P.arc(d[0], d[1], xh * 0.1, 0, Math.PI * 2); P.fill(); }
    const fl = catmull([[x0 - 4, yBase + xh * 1.28], [(x0 + endX) * 0.5, yBase + xh * 1.5], [endX + 10, yBase + xh * 1.1], [endX + 26, yBase + xh * 1.42]], 12);
    ink(fl, { base: xh * 0.055, seed: seed + 3 });
    return { endX, pts };
  };

  const photos = {};
  const loadPhoto = async (name) => {
    if (photos[name]) return photos[name];
    const bytes = await fs.readFile(srcDir + "/" + name);
    const bmp = await createImageBitmap(new Blob([bytes], { type: "image/jpeg" }));
    photos[name] = bmp;
    return bmp;
  };
  const drawCover = (img, x, y, w, h, r) => {
    P.save(); rrect(x, y, w, h, r); P.clip();
    const ir = img.width / img.height, br = w / h;
    let dw, dh;
    if (ir > br) { dh = h; dw = h * ir; } else { dw = w; dh = w / ir; }
    P.drawImage(img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
    P.restore();
  };

  const sceneJob = (s) => {
    appBar(s, "New job", "JOB-2026-0042  \u00b7  Draft");
    let y = s.y + 138;
    y = fieldBlock(s, y, "JOB TITLE", "Capacitor swap, rooftop 3");
    let cx = s.x + 22;
    const ccy = y + 8;
    cx = chip(cx, ccy, "HVAC", "on");
    cx = chip(cx, ccy, "Plumbing");
    cx = chip(cx, ccy, "Electrical");
    y += 40;
    y = fieldBlock(s, y, "CLIENT", "Dana Whitfield \u00b7 Northgate Plaza");
    y = fieldBlock(s, y, "SITE ADDRESS", "410 Northgate Rd, Unit 12");
    txt("MATERIALS & LABOUR", s.x + 22, y + 12, { size: 13, weight: 800, color: CO.slate, spacing: 2.2 });
    y += 22;
    const c = card(s, y, 186);
    let iy = c.y + 22;
    iy = moneyRow(s, iy, "Capacitor 45/5 \u00b5F", "x1  \u00b7  stock", "$76.00");
    seg(s.x + 40, iy - 12, s.x + s.w - 40, iy - 12, CO.lineSoft, 1);
    iy = moneyRow(s, iy, "Contactor 30A", "x1", "$52.00");
    seg(s.x + 40, iy - 12, s.x + s.w - 40, iy - 12, CO.lineSoft, 1);
    iy = moneyRow(s, iy, "Labour", "2.5 h @ $95.00", "$237.50");
    const t = card(s, s.y + s.h - 96 - 116, 88, "rgba(255,122,0,0.10)");
    txt("JOB TOTAL", s.x + 42, t.y + 30, { size: 16, weight: 800, color: CO.orange, spacing: 2.2, maxW: 150 });
    txt("$365.50", s.x + s.w - 42, t.y + 54, { size: 30, weight: 800, color: CO.white, align: "right" });
    txt("materials + labour, tax in the quote", s.x + 42, t.y + 78, { size: 13, weight: 600, color: "rgba(255,255,255,0.5)", maxW: s.w - 84 });
    stickyBar(s, [{ label: "Save job", kind: "primary" }, { label: "Quote", kind: "ghost" }]);
  };

  const sceneQuote = (s) => {
    appBar(s, "Quote", "Q-2026-0042  \u00b7  Dana Whitfield");
    let y = s.y + 148;
    let cx = s.x + 22;
    const cy = y + 6;
    const tabs = ["Labour", "Materials", "Fees", "Discount"];
    const tw2 = (s.w - 44) / tabs.length;
    fillRR(s.x + 22, y - 14, s.w - 44, 48, 12, CO.field);
    tabs.forEach((t, i) => {
      const bx = s.x + 22 + i * tw2;
      if (i === 0) fillRR(bx + 4, y - 10, tw2 - 8, 40, 9, "rgba(255,122,0,0.18)");
      txt(t, bx + tw2 / 2, y + 16, { size: 15, weight: 700, color: i === 0 ? CO.orange : CO.slate, align: "center" });
    });
    y += 60;
    const c = card(s, y, 308);
    let iy = c.y + 24;
    iy = moneyRow(s, iy, "Labour", "2.5 h @ $95.00", "$237.50");
    iy = moneyRow(s, iy, "Capacitor 45/5 \u00b5F", "x1", "$76.00");
    iy = moneyRow(s, iy, "Contactor 30A", "x1", "$52.00");
    iy = moneyRow(s, iy, "Diagnostic + trip fee", "callout", "$89.00");
    seg(s.x + 40, iy - 8, s.x + s.w - 40, iy - 8, CO.line, 1);
    iy += 24;
    moneyRow(s, iy, "Subtotal", "", "$454.50", { amountColor: CO.slate2 });
    y = c.y + c.h + 18;
    const c2 = card(s, y, 148, CO.cardSoft);
    let iy2 = c2.y + 30;
    txt("Discount \u00b7 loyalty", s.x + 42, iy2, { size: 18, weight: 600, color: CO.slate2 });
    txt("-$25.00", s.x + s.w - 42, iy2, { size: 18, weight: 700, color: CO.green, align: "right" });
    iy2 += 34;
    txt("Tax", s.x + 42, iy2, { size: 18, weight: 600, color: CO.slate2 });
    txt("8.25%", s.x + 90, iy2, { size: 15, weight: 600, color: CO.slate });
    txt("+$35.43", s.x + s.w - 42, iy2, { size: 18, weight: 700, color: CO.slate2, align: "right" });
    iy2 += 34;
    txt("Valid for 30 days", s.x + 42, iy2, { size: 14, weight: 500, color: CO.slate });
    const t = card(s, s.y + s.h - 96 - 116, 88, "rgba(255,122,0,0.10)");
    txt("QUOTE TOTAL", s.x + 42, t.y + 30, { size: 16, weight: 800, color: CO.orange, spacing: 2.2, maxW: 150 });
    txt("$464.93", s.x + s.w - 42, t.y + 54, { size: 30, weight: 800, color: CO.white, align: "right" });
    txt("deposit due now $139.48", s.x + 42, t.y + 78, { size: 13, weight: 600, color: "rgba(255,255,255,0.5)", maxW: s.w - 84 });
    stickyBar(s, [{ label: "Send quote", kind: "primary" }, { label: "Save", kind: "ghost" }]);
  };

  const sceneMarkup = async (s) => {
    appBar(s, "Photo markup", "IMG_2041  \u00b7  Unit 12");
    let y = s.y + 148;
    const c = card(s, y, 380, "#0E141F");
    const img = await loadPhoto("photo-hvac.jpg");
    const ph = { x: c.x + 12, y: c.y + 12, w: c.w - 24, h: c.h - 24 };
    drawCover(img, ph.x, ph.y, ph.w, ph.h, 12);
    P.save(); rrect(ph.x, ph.y, ph.w, ph.h, 12); P.clip();
    let vg = P.createLinearGradient(0, ph.y, 0, ph.y + ph.h);
    vg.addColorStop(0, "rgba(6,10,16,0.34)"); vg.addColorStop(0.45, "rgba(6,10,16,0)"); vg.addColorStop(1, "rgba(6,10,16,0.5)");
    P.fillStyle = vg; P.fillRect(ph.x, ph.y, ph.w, ph.h);
    P.restore();
    const bx = ph.x + ph.w * 0.44, by = ph.y + ph.h * 0.32, bw = ph.w * 0.34, bh = ph.h * 0.42;
    P.save();
    P.strokeStyle = CO.red; P.lineWidth = 3; P.setLineDash([9, 6]);
    rrect(bx, by, bw, bh, 8); P.stroke();
    P.restore();
    const lb = "Loose fan blade";
    P.font = FONT(15, 800);
    const lw = tw(lb) + 22;
    fillRR(bx - 4, by - 34, lw, 28, 7, CO.red);
    txt(lb, bx + 7, by - 14, { size: 15, weight: 800, color: "#FFFFFF" });
    P.save();
    P.strokeStyle = CO.red; P.lineWidth = 3; P.lineCap = "round"; P.lineJoin = "round";
    P.beginPath(); P.moveTo(bx + bw * 0.5, by - 6); P.lineTo(bx + bw * 0.5, by + 22); P.stroke();
    P.beginPath(); P.moveTo(bx + bw * 0.5 - 9, by + 12); P.lineTo(bx + bw * 0.5, by + 24); P.lineTo(bx + bw * 0.5 + 9, by + 12); P.stroke();
    P.restore();
    P.save();
    P.strokeStyle = CO.amber; P.lineWidth = 3;
    P.beginPath(); P.ellipse(ph.x + ph.w * 0.18, ph.y + ph.h * 0.72, 34, 22, -0.2, 0, Math.PI * 2); P.stroke();
    P.restore();
    P.font = FONT(14, 800);
    const l2 = "Clogged coil";
    const l2w = tw(l2) + 20;
    fillRR(ph.x + ph.w * 0.18 - l2w / 2, ph.y + ph.h * 0.72 + 30, l2w, 26, 7, "rgba(245,177,61,0.92)");
    txt(l2, ph.x + ph.w * 0.18 - l2w / 2 + 10, ph.y + ph.h * 0.72 + 48, { size: 14, weight: 800, color: "#2A1B00" });
    P.font = FONT(12, 700);
    txt("IMG_2041 \u00b7 09:14 \u00b7 Unit 12", ph.x + 12, ph.y + ph.h - 14, { size: 12, weight: 700, color: "rgba(255,255,255,0.82)", mono: true, maxW: ph.w - 150 });
    txt("3 annotations", ph.x + ph.w - 12, ph.y + ph.h - 14, { size: 12, weight: 700, color: "rgba(255,255,255,0.82)", align: "right" });
    y = c.y + c.h + 14;
    const sw = 95;
    const tgX = s.x + 22;
    fillRR(tgX, y, sw * 2 + 12, 44, 22, CO.field);
    strokeRR(tgX + 0.7, y + 0.7, sw * 2 + 10.6, 42.6, 21.3, CO.line, 1.3);
    fillRR(tgX + 6 + sw, y + 6, sw, 32, 16, CO.orange);
    txt("BEFORE", tgX + 6 + sw / 2, y + 27, { size: 15, weight: 800, color: CO.slate2, align: "center", maxW: sw - 12 });
    txt("AFTER", tgX + 6 + sw + sw / 2, y + 27, { size: 15, weight: 800, color: "#1A1206", align: "center", maxW: sw - 12 });
    txt("Side-by-side slider", s.x + s.w - 22, y + 27, { size: 13, weight: 600, color: CO.slate, align: "right", maxW: s.w - 22 - (tgX + sw * 2 + 12) - 12 });
    y += 62;
    const sws = [CO.orange, "#FF4D4F", "#F5B13D", "#46E0A0", "#4C8DFF", "#FFFFFF"];
    let sx = s.x + 30;
    sws.forEach((col, i) => {
      disc(sx + 14, y + 14, 14, col);
      if (i === 0) { P.strokeStyle = "#FFFFFF"; P.lineWidth = 2.4; P.beginPath(); P.arc(sx + 14, y + 14, 19, 0, Math.PI * 2); P.stroke(); }
      sx += 44;
    });
    seg(sx + 6, y - 4, sx + 6, y + 32, CO.line, 1.4);
    sx += 22;
    [6, 10, 14].forEach((r, i) => {
      disc(sx + 14, y + 14, r, i === 1 ? CO.white : "rgba(255,255,255,0.35)");
      sx += 40;
    });
    iconChevron(s.x + s.w - 96, y + 14, 14, "rgba(255,255,255,0.6)", "left");
    iconChevron(s.x + s.w - 44, y + 14, 14, "rgba(255,255,255,0.6)", "right");
    y += 52;
    const n = card(s, y, 84, CO.cardSoft);
    txt("Note", n.x + 20, n.y + 30, { size: 14, weight: 800, color: CO.teal, spacing: 1.6 });
    txt("Fan blade out of balance. Replaced capacitor and", n.x + 20, n.y + 54, { size: 16, weight: 600, color: CO.text, maxW: n.w - 40 });
    txt("tightened blade bolts \u2014 recheck on next visit.", n.x + 20, n.y + 74, { size: 16, weight: 600, color: CO.text, maxW: n.w - 40 });
    stickyBar(s, [{ label: "Save marked-up copy", kind: "primary" }]);
  };

  const sceneOffline = (s) => {
    appBar(s, "Jobs", "5 jobs  \u00b7  7 changes queued");
    let y = s.y + 148;
    const b = card(s, y, 62, "rgba(245,177,61,0.12)");
    iconCloudOff(b.x + 20, b.y + 18, 26, CO.amber);
    txt("Offline \u2014 everything is saved on this device", b.x + 62, b.y + 40, { size: 16, weight: 700, color: "#F7D9A0", maxW: b.w - 80 });
    y = b.y + b.h + 16;
    const c = card(s, y, 362);
    const rows = [
      ["Capacitor swap, rooftop 3", "Dana Whitfield \u00b7 09:14", "Queued", CO.amber, "rgba(245,177,61,0.16)", CO.orange, "HVAC"],
      ["Panel upgrade \u2014 Unit 12", "Northgate Plaza \u00b7 today", "Synced", CO.teal, "rgba(34,193,180,0.16)", CO.teal, "ELEC"],
      ["Kitchen P-trap leaking", "R. Okafor \u00b7 yesterday", "Synced", CO.teal, "rgba(34,193,180,0.16)", CO.teal, "PLMB"],
      ["Drywall patch + paint", "M. Trejo \u00b7 Mon", "Draft", CO.slate, "rgba(255,255,255,0.08)", CO.slate2, "HANDY"],
      ["Thermostat + filter swap", "J. Feld \u00b7 Tue 14:20", "Queued", CO.amber, "rgba(245,177,61,0.16)", CO.orange, "HVAC"]
    ];
    let ry = c.y + 12;
    rows.forEach((r, i) => {
      fillRR(c.x + 12, ry + 6, 52, 52, 14, "rgba(255,255,255,0.06)");
      txt(r[6].slice(0, 4), c.x + 38, ry + 38, { size: 13, weight: 800, color: r[5], align: "center" });
      txt(r[0], c.x + 78, ry + 30, { size: 18, weight: 700, color: CO.text, maxW: c.w - 210 });
      txt(r[1], c.x + 78, ry + 52, { size: 14, weight: 500, color: CO.slate, maxW: c.w - 210 });
      badge(c.x + c.w - 16, ry + 32, r[2], r[3], r[4]);
      ry += 70;
      if (i < rows.length - 1) seg(c.x + 78, ry - 6, c.x + c.w - 12, ry - 6, CO.lineSoft, 1);
    });
    y = c.y + c.h + 16;
    const q = card(s, y, 152, CO.cardSoft);
    txt("Change queue", q.x + 20, q.y + 34, { size: 19, weight: 800, color: CO.white });
    txt("7 waiting", q.x + q.w - 20, q.y + 34, { size: 17, weight: 700, color: CO.amber, align: "right" });
    progress(q.x + 20, q.y + 52, q.w - 40, 10, 0.42, CO.teal);
    txt("4 of 7 uploaded \u00b7 retry in 12 s", q.x + 20, q.y + 88, { size: 14, weight: 600, color: CO.slate });
    txt("Failed uploads retry with backoff", q.x + 20, q.y + 110, { size: 14, weight: 600, color: CO.slate });
    txt("Auto-sync when online", q.x + 20, q.y + 138, { size: 16, weight: 700, color: CO.text });
    toggle(q.x + q.w - 20, q.y + 131, true);
    bottomNav(s, 1);
  };

  const sceneSignature = (s) => {
    appBar(s, "Client signature", "JOB-2026-0042  \u00b7  Unit 12");
    let y = s.y + 148;
    const c = card(s, y, 108, CO.cardSoft);
    txt("SCOPE", c.x + 20, c.y + 30, { size: 13, weight: 800, color: CO.slate, spacing: 2.2 });
    txt("Capacitor swap \u00b7 rooftop unit 3", c.x + 20, c.y + 56, { size: 18, weight: 700, color: CO.text, maxW: c.w - 170 });
    txt("HVAC", c.x + 20, c.y + 84, { size: 14, weight: 700, color: CO.orange });
    txt("$464.93", c.x + c.w - 20, c.y + 66, { size: 30, weight: 800, color: CO.white, align: "right" });
    y = c.y + c.h + 16;
    txt("SIGN BELOW", s.x + 22, y + 14, { size: 13, weight: 800, color: CO.slate, spacing: 2.2 });
    y += 26;
    const pad = { x: s.x + 22, y, w: s.w - 44, h: 288 };
    P.save();
    P.shadowColor = "rgba(0,0,0,0.45)"; P.shadowBlur = 24; P.shadowOffsetY = 8;
    fillRR(pad.x, pad.y, pad.w, pad.h, 16, "#F7F9FC");
    P.restore();
    strokeRR(pad.x + 0.7, pad.y + 0.7, pad.w - 1.4, pad.h - 1.4, 15.5, "rgba(255,255,255,0.35)", 1.4);
    seg(pad.x + 20, pad.y + pad.h - 44, pad.x + pad.w - 20, pad.y + pad.h - 44, "rgba(18,25,43,0.18)", 1.4);
    const xh = 25;
    signature(pad.x + 30, pad.y + pad.h - 60, xh, 12345);
    txt("Signed by Dana Whitfield \u00b7 09:14", pad.x + 20, pad.y + pad.h - 16, { size: 13, weight: 600, color: "rgba(18,25,43,0.55)" });
    txt("GPS 43.6012, -79.4567", pad.x + pad.w - 20, pad.y + pad.h - 16, { size: 13, weight: 600, color: "rgba(18,25,43,0.55)", align: "right" });
    y = pad.y + pad.h + 18;
    const h = card(s, y, 58, CO.cardSoft);
    txt("SHA-256", h.x + 20, h.y + 36, { size: 13, weight: 800, color: CO.teal, spacing: 1.6, mono: true });
    txt("4F2A9C1E7B30D845A1C6\u20269E0F", h.x + 104, h.y + 36, { size: 14, weight: 600, color: CO.slate2, mono: true, maxW: h.w - 130 });
    y = h.y + h.h + 16;
    const t = card(s, y, 62, CO.card);
    fillRR(t.x + 20, t.y + 16, 30, 30, 9, "rgba(34,193,180,0.18)");
    iconCheck(t.x + 25, t.y + 21, 20, CO.teal, 3);
    txt("Customer accepts the quote and the work above.", t.x + 62, t.y + 38, { size: 15, weight: 600, color: CO.text, maxW: t.w - 84 });
    stickyBar(s, [{ label: "Clear", kind: "ghost" }, { label: "Save signature", kind: "primary" }]);
  };

  const drawFeatureGraphic = () => {
    const c = new OffscreenCanvas(1024, 500);
    P = c.getContext("2d");
    const w = 1024, h = 500;
    let g = P.createLinearGradient(0, 0, w, h);
    g.addColorStop(0, "#0A1119"); g.addColorStop(0.6, "#0C1622"); g.addColorStop(1, "#070A11");
    P.fillStyle = g; P.fillRect(0, 0, w, h);
    let rg = P.createRadialGradient(150, 470, 0, 150, 470, 460);
    rg.addColorStop(0, "rgba(34,193,180,0.22)"); rg.addColorStop(1, "rgba(34,193,180,0)");
    P.fillStyle = rg; P.fillRect(0, 0, w, h);
    rg = P.createRadialGradient(880, 120, 0, 880, 120, 420);
    rg.addColorStop(0, "rgba(255,122,0,0.24)"); rg.addColorStop(1, "rgba(255,122,0,0)");
    P.fillStyle = rg; P.fillRect(0, 0, w, h);
    P.strokeStyle = "rgba(255,255,255,0.04)"; P.lineWidth = 1; P.beginPath();
    for (let x = 0; x <= w; x += 32) { P.moveTo(x + 0.5, 0); P.lineTo(x + 0.5, h); }
    for (let y = 0; y <= h; y += 32) { P.moveTo(0, y + 0.5); P.lineTo(w, y + 0.5); }
    P.stroke();
    const s = 84;
    const ly = 92;
    P.font = FONT(56, 800);
    const ww = tw("FieldFlow") + tw(" Pro");
    const lx = (w - (s + 24 + ww)) / 2;
    P.save(); P.shadowColor = "rgba(255,122,0,0.45)"; P.shadowBlur = 30;
    const lg = P.createLinearGradient(lx, ly, lx + s, ly + s);
    lg.addColorStop(0, "#15303A"); lg.addColorStop(1, "#0C1A22");
    fillRR(lx, ly, s, s, 24, lg); P.restore();
    strokeRR(lx + 1, ly + 1, s - 2, s - 2, 23, "rgba(34,193,180,0.55)", 2);
    iconBolt(lx + 9, ly + 11, s - 18, CO.orange);
    txt("FieldFlow", lx + s + 24, ly + 60, { size: 56, weight: 800, color: CO.white });
    txt(" Pro", lx + s + 24 + tw("FieldFlow"), ly + 60, { size: 56, weight: 800, color: CO.teal });
    txt("Jobs, photo proof, quotes, signatures and PDF packets \u2014 works with no signal.", w / 2, 226, { size: 22, weight: 600, color: "rgba(198,210,224,0.92)", align: "center" });
    const pills = ["HVAC", "PLUMBING", "ELECTRICAL", "HANDYMAN"];
    P.font = FONT(19, 700);
    let totalW = 0;
    const ws = pills.map(p => { const pw = tw(p) + 40; totalW += pw + 14; return pw; });
    totalW -= 14;
    let px = (w - totalW) / 2;
    pills.forEach((p, i) => {
      fillRR(px, 268, ws[i], 46, 23, "rgba(255,255,255,0.06)");
      strokeRR(px + 0.7, 268.7, ws[i] - 1.4, 44.6, 22.3, CO.line, 1.3);
      txt(p, px + ws[i] / 2, 298, { size: 19, weight: 700, color: CO.slate2, align: "center" });
      px += ws[i] + 14;
    });
    txt("Offline-first \u00b7 encrypted on device \u00b7 auto-sync", w / 2, 378, { size: 19, weight: 600, color: CO.slate, align: "center" });
    const ab = P.createLinearGradient(0, 0, w, 0);
    ab.addColorStop(0, "rgba(34,193,180,0)");
    ab.addColorStop(0.35, "rgba(34,193,180,0.85)");
    ab.addColorStop(0.65, "rgba(255,122,0,0.9)");
    ab.addColorStop(1, "rgba(255,122,0,0)");
    P.fillStyle = ab; P.fillRect(0, h - 8, w, 8);
    return c;
  };

  const drawIcon = () => {
    const size = 512;
    const c = new OffscreenCanvas(size, size);
    P = c.getContext("2d");
    P.fillStyle = "#0B0F16";
    P.fillRect(0, 0, size, size);
    let rg = P.createRadialGradient(size * 0.5, size * 0.46, 0, size * 0.5, size * 0.5, size * 0.76);
    rg.addColorStop(0, "rgba(255,122,26,0.18)"); rg.addColorStop(1, "rgba(255,122,26,0)");
    P.fillStyle = rg; P.fillRect(0, 0, size, size);
    P.save();
    P.strokeStyle = "#2DD4BF"; P.lineWidth = size * 0.032;
    P.beginPath(); P.arc(size / 2, size / 2, size * 0.302, 0, Math.PI * 2); P.stroke();
    P.restore();
    P.save();
    P.shadowColor = "rgba(255,122,26,0.55)"; P.shadowBlur = size * 0.085;
    iconBolt(size * 0.335, size * 0.268, size * 0.45, "#FF7A1A");
    P.restore();
    return c;
  };

  const promos = [
    ["01-job-creation", "JOB CREATION", ["Create a job", "in under a minute"],
      ["Title, client, address, materials, cost", "Per-trade templates fill in the detail", "Totals add up as you type"],
      "Offline-first  \u00b7  encrypted on device  \u00b7  syncs itself later", sceneJob],
    ["02-quote-builder", "QUOTE BUILDER", ["Price it once.", "Send it signed."],
      ["Labour, materials, fees and discounts", "Tax and totals recalculate as you type", "Turns into a PDF packet in one tap"],
      "Quotes that look like an office made them", sceneQuote],
    ["03-photo-markup", "PHOTO PROOF", ["Mark it up.", "Prove the work."],
      ["Arrows, boxes and notes on the photo", "Before / after slider on one screen", "Every photo stored with the job"],
      "No cloud needed \u2014 photos live with the job", sceneMarkup],
    ["04-offline-mode", "OFFLINE-FIRST", ["No bars.", "No problem."],
      ["Every job writes to the phone first", "Queued changes sync when you get signal", "Failed uploads retry with backoff"],
      "Basements, plant rooms, rural calls \u2014 all covered", sceneOffline],
    ["05-signature", "SIGN ON SITE", ["Get it signed.", "Get paid faster."],
      ["Finger or stylus signature capture", "Signature + SHA-256 hash stored", "Signed page lands in the PDF packet"],
      "Proof of acceptance before you leave the driveway", sceneSignature]
  ];

  const written = [];
  const wantPromos = !only || only.includes("promos");
  if (wantPromos) {
    for (const [file, kicker, lines, bullets, tagline, fn] of promos) {
      const c = new OffscreenCanvas(W, H);
      P = c.getContext("2d");
      background();
      leftColumn(kicker, lines, bullets, tagline);
      const s = phone();
      P.save(); rrect(s.x, s.y, s.w, s.h, 42); P.clip();
      statusBar(s);
      await fn(s);
      P.restore();
      const blob = await c.convertToBlob({ type: "image/png" });
      const buf = new Uint8Array(await blob.arrayBuffer());
      await fs.writeFile(promoDir + "/" + file + ".png", buf);
      const pc = new OffscreenCanvas(960, 540);
      const px = pc.getContext("2d");
      px.imageSmoothingQuality = "high";
      px.drawImage(c, 0, 0, 960, 540);
      const pb = await pc.convertToBlob({ type: "image/jpeg", quality: 0.62 });
      await fs.writeFile(previewDir + "/" + file + ".jpg", new Uint8Array(await pb.arrayBuffer()));
      written.push(file + ".png " + buf.length);
    }
  }
  if (!only || only.includes("play")) {
    for (const [name, c] of [["icon-512", drawIcon()], ["feature-graphic-1024x500", drawFeatureGraphic()]]) {
      const blob = await c.convertToBlob({ type: "image/png" });
      const buf = new Uint8Array(await blob.arrayBuffer());
      await fs.writeFile(playDir + "/" + name + ".png", buf);
      written.push(name + ".png " + buf.length);
    }
  }
  if (only && only.includes("sigtest")) {
    const c = new OffscreenCanvas(1200, 520);
    P = c.getContext("2d");
    fillRR(0, 0, 1200, 520, 0, "#F7F9FC");
    seg(40, 400, 1160, 400, "rgba(18,25,43,0.16)", 1.5);
    signature(90, 390, 46, 12345);
    const blob = await c.convertToBlob({ type: "image/png" });
    await fs.writeFile("scratch/promo-src/sig-test.png", new Uint8Array(await blob.arrayBuffer()));
    written.push("sig-test.png");
  }
  return written;
}
