#!/usr/bin/env node
/**
 * FieldFlow Pro — reference sync server.
 *
 * Implements the two endpoints described in API_CONTRACT.md:
 *   POST /v1/sync/push   → { accepted[], rejected[], cursor, serverTime }
 *   GET  /v1/sync/pull?cursor=<n>&limit=<n> → { changes[], cursor, hasMore, serverTime }
 *
 * Zero dependencies (Node 18+). Records are namespaced per API key, so two keys never
 * see each other's jobs. State is a single JSON file, written atomically.
 *
 * Run:
 *   FIELDFLOW_API_KEY=long-random-secret FIELDFLOW_DATA=./data.json node server/reference-server.js
 *   PORT=8080 FIELDFLOW_API_KEY=... node server/reference-server.js
 *
 * Then in the Android project's local.properties:
 *   SYNC_BASE_URL=http://10.0.2.2:8080     # emulator → host machine
 *   SYNC_API_KEY=long-random-secret
 *
 * Production notes: terminate TLS in front of this (nginx/Caddy/ALB), back the JSON file with a
 * real database when you outgrow it, and rate-limit per key. The Android client retries 5xx and
 * network errors with exponential backoff, so short restarts are harmless.
 */

const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PORT = Number(process.env.PORT || 8080);
const API_KEY = process.env.FIELDFLOW_API_KEY || "";
const DATA_FILE = process.env.FIELDFLOW_DATA || path.join(process.cwd(), "fieldflow-data.json");
const MAX_BODY_BYTES = 32 * 1024 * 1024;

function loadDb() {
  try {
    const raw = fs.readFileSync(DATA_FILE, "utf8");
    const parsed = JSON.parse(raw);
    return {
      seq: Number(parsed.seq || 0),
      workspaces: parsed.workspaces && typeof parsed.workspaces === "object" ? parsed.workspaces : {},
    };
  } catch (_) {
    return { seq: 0, workspaces: {} };
  }
}

let db = loadDb();

function saveDb() {
  const tmp = DATA_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(db));
  fs.renameSync(tmp, DATA_FILE);
}

function workspaceFor(key) {
  const id = crypto.createHash("sha256").update(String(key)).digest("hex").slice(0, 16);
  if (!db.workspaces[id]) db.workspaces[id] = { records: {} };
  return db.workspaces[id];
}

function send(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
    "Cache-Control": "no-store",
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(new Error("payload_too_large"));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

function authorized(req) {
  if (!API_KEY) return true; // open server: only fine for local testing
  const header = req.headers["authorization"] || "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  if (!token || token.length !== API_KEY.length) return false;
  return crypto.timingSafeEqual(Buffer.from(token), Buffer.from(API_KEY));
}

function push(workspace, request) {
  const changes = Array.isArray(request.changes) ? request.changes : [];
  const accepted = [];
  const rejected = [];

  for (const change of changes) {
    if (!change || !change.entityType || !change.entityId) continue;
    const key = `${change.entityType}:${change.entityId}`;
    const existing = workspace.records[key];
    const incomingUpdatedAt = Number(change.updatedAt || 0);

    if (existing && Number(existing.updatedAt || 0) > incomingUpdatedAt) {
      rejected.push(key);
      continue;
    }

    db.seq += 1;
    workspace.records[key] = {
      key,
      entityType: change.entityType,
      entityId: change.entityId,
      op: change.op === "delete" ? "delete" : "upsert",
      payload: typeof change.payload === "string" ? change.payload : JSON.stringify(change.payload || {}),
      updatedAt: incomingUpdatedAt,
      version: Number(change.version || 1),
      seq: db.seq,
      deviceId: String(request.deviceId || ""),
      receivedAt: Date.now(),
    };
    accepted.push(key);
  }

  saveDb();
  return { accepted, rejected, cursor: String(db.seq), serverTime: Date.now() };
}

function pull(workspace, cursor, limit) {
  const from = Number.parseInt(cursor, 10);
  const after = Number.isFinite(from) ? from : 0;
  const all = Object.values(workspace.records)
    .filter((record) => Number(record.seq) > after)
    .sort((a, b) => Number(a.seq) - Number(b.seq));
  const page = all.slice(0, limit);
  return {
    changes: page.map((record) => ({
      entityType: record.entityType,
      entityId: record.entityId,
      op: record.op,
      payload: record.payload,
      updatedAt: record.updatedAt,
      version: record.version,
    })),
    cursor: page.length ? String(page[page.length - 1].seq) : String(after),
    hasMore: all.length > page.length,
    serverTime: Date.now(),
  };
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);

  if (req.method === "GET" && url.pathname === "/health") {
    return send(res, 200, { ok: true, records: Object.values(db.workspaces).reduce((n, w) => n + Object.keys(w.records).length, 0), cursor: db.seq });
  }

  if (!authorized(req)) {
    return send(res, 401, { error: "unauthorized", message: "Missing or invalid bearer token." });
  }

  const workspace = workspaceFor(req.headers["authorization"] || "anonymous");

  try {
    if (req.method === "POST" && url.pathname === "/v1/sync/push") {
      const raw = await readBody(req);
      const parsed = raw ? JSON.parse(raw) : {};
      return send(res, 200, push(workspace, parsed));
    }

    if (req.method === "GET" && url.pathname === "/v1/sync/pull") {
      const cursor = url.searchParams.get("cursor") || "0";
      const limit = Math.min(Math.max(Number.parseInt(url.searchParams.get("limit") || "200", 10) || 200, 1), 1000);
      return send(res, 200, pull(workspace, cursor, limit));
    }

    return send(res, 404, { error: "not_found" });
  } catch (error) {
    if (error && error.message === "payload_too_large") {
      return send(res, 413, { error: "payload_too_large" });
    }
    if (error instanceof SyntaxError) {
      return send(res, 400, { error: "bad_json", message: error.message });
    }
    console.error("unhandled", error);
    return send(res, 500, { error: "internal_error" });
  }
});

server.listen(PORT, () => {
  console.log(`FieldFlow sync server listening on :${PORT}`);
  console.log(`  data file : ${DATA_FILE}`);
  console.log(API_KEY ? "  auth      : bearer token required" : "  auth      : DISABLED (set FIELDFLOW_API_KEY)");
});
